package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.BorderLayout;
import com.googlecode.lanterna.gui2.Component;

/**
 * Conteneur à cinq zones, équivalent de {@code javafx.scene.layout.BorderPane}.
 */
public final class BorderPane extends FluentPanel {
    private final SpacedBorderLayout layoutManager;

    private BorderPane() {
        layoutManager = new SpacedBorderLayout();
        setLayoutManager(layoutManager);
    }

    public static BorderPane create() {
        return new BorderPane();
    }

    /** Espacement horizontal et vertical entre les zones adjacentes. */
    public BorderPane spacing(Spacing spacing) {
        layoutManager.setSpacing(spacing);
        return this;
    }

    public BorderPane padding(Insets insets) {
        layoutManager.setPadding(insets);
        return this;
    }

    /**
     * Alignement du composant central dans la bande centrale (hauteur préférée, sans étirement vertical).
     * Sans appel à cette méthode, le centre occupe toute la bande disponible (comportement {@link BorderLayout}).
     */
    public BorderPane centerAlign(Pos alignment) {
        layoutManager.setCenterAlign(alignment);
        return this;
    }

    public BorderPane top(Component node) {
        node.setLayoutData(BorderLayout.Location.TOP);
        addComponent(node);
        return this;
    }

    public BorderPane bottom(Component node) {
        node.setLayoutData(BorderLayout.Location.BOTTOM);
        addComponent(node);
        return this;
    }

    public BorderPane left(Component node) {
        node.setLayoutData(BorderLayout.Location.LEFT);
        addComponent(node);
        return this;
    }

    public BorderPane right(Component node) {
        node.setLayoutData(BorderLayout.Location.RIGHT);
        addComponent(node);
        return this;
    }

    public BorderPane center(Component node) {
        node.setLayoutData(BorderLayout.Location.CENTER);
        addComponent(node);
        return this;
    }
}
