package tgpr.framework.ui.component;

import com.googlecode.lanterna.gui2.Button;
import com.googlecode.lanterna.gui2.Label;
import com.googlecode.lanterna.gui2.Window;
import tgpr.framework.ui.layout.HBox;
import tgpr.framework.ui.layout.Pos;

/**
 * Barre de navigation par pages (première, précédente, suivante, dernière).
 * <p>
 * Appelle {@link PageChangeListener#onPageChanged(int)} à chaque changement de page
 * (indexation à partir de zéro).
 */
public final class Paginator extends HBox {
    @FunctionalInterface
    public interface PageChangeListener {
        void onPageChanged(int page);
    }

    private final PageChangeListener listener;
    private final Label statusLabel;
    private int pageSize = 1;
    private int count;
    private int currentPage;

    public Paginator(Window window, int pageSize, PageChangeListener listener) {
        this.listener = listener;
        this.pageSize = Math.max(1, pageSize);
        spacing(1);
        statusLabel = new Label("");
        add(
                button("<<", this::firstPage),
                button("<", this::previousPage),
                statusLabel,
                button(">", this::nextPage),
                button(">>", this::lastPage)
        );
        alignInParent(Pos.CENTER);
        updateDisplay();
    }

    public void setCount(int count) {
        this.count = Math.max(0, count);
        currentPage = 0;
        updateDisplay();
        firePageChanged();
    }

    public int getCount() {
        return count;
    }

    public int getPageSize() {
        return pageSize;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public int getPageCount() {
        if (count == 0) {
            return 0;
        }
        return (count + pageSize - 1) / pageSize;
    }

    private Button button(String caption, Runnable action) {
        return new Button(caption, action);
    }

    private void firstPage() {
        goToPage(0);
    }

    private void previousPage() {
        goToPage(currentPage - 1);
    }

    private void nextPage() {
        goToPage(currentPage + 1);
    }

    private void lastPage() {
        goToPage(getPageCount() - 1);
    }

    private void goToPage(int page) {
        int maxPage = Math.max(0, getPageCount() - 1);
        int target = Math.max(0, Math.min(page, maxPage));
        if (target == currentPage) {
            return;
        }
        currentPage = target;
        updateDisplay();
        firePageChanged();
    }

    private void firePageChanged() {
        if (listener != null) {
            listener.onPageChanged(currentPage);
        }
    }

    private void updateDisplay() {
        int pages = getPageCount();
        if (pages == 0) {
            statusLabel.setText("Page 0/0");
        } else {
            statusLabel.setText("Page " + (currentPage + 1) + "/" + pages);
        }
        invalidate();
    }
}
