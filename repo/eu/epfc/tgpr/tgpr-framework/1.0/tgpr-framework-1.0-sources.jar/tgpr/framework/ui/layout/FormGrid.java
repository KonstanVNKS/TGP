package tgpr.framework.ui.layout;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.GridLayout;
import com.googlecode.lanterna.gui2.Label;
import tgpr.framework.validation.ErrorList;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Grille spécialisée pour les formulaires : label + champ (+ message d'erreur optionnel).
 * <p>
 * Les composants sont ajoutés dans l'ordre séquentiel attendu par {@link GridLayout},
 * ce qui garantit un placement correct dans une grille à 2 colonnes.
 * <p>
 * Défaut : {@link Spacing#getDefault()} = horizontal 1, vertical 0 — les lignes d'erreur
 * réservées par {@link #row(String, Component, Enum)} restent collées au champ.
 * Un espacement vertical peut être demandé explicitement via {@link #spacing(Spacing)}
 * ou {@link #withRowSpacing(int)} (affichage sans lignes d'erreur, typiquement).
 */
public final class FormGrid extends GridPane {
    private final Map<Enum<?>, Label> errorLabels = new LinkedHashMap<>();

    private FormGrid() {
        super(2);
        padding(Insets.of(0));
        spacing(Spacing.getDefault());
    }

    public static FormGrid create() {
        return new FormGrid();
    }

    /** Formulaire avec marges intérieures par défaut ({@code padding(Insets.of(1))}). */
    public static FormGrid createPadded() {
        return create().padding(Insets.of(1));
    }

    @Override
    public FormGrid spacing(Spacing spacing) {
        return (FormGrid) super.spacing(spacing);
    }

    /**
     * Définit l'espacement vertical entre lignes de grille, en conservant l'espacement horizontal courant.
     * À privilégier pour l'affichage sans {@link #row(String, Component, Enum)} (sinon l'espace
     * s'applique aussi entre le champ et son label d'erreur).
     */
    public FormGrid withRowSpacing(int vertical) {
        var layout = (GridLayout) getLayoutManager();
        return spacing(Spacing.of(layout.getHorizontalSpacing(), vertical));
    }

    @Override
    public FormGrid padding(Insets insets) {
        return (FormGrid) super.padding(insets);
    }

    public FormGrid row(String labelText, Component field) {
        return row(labelText, field, (Component) null);
    }

    /**
     * Ajoute une ligne avec un label d'erreur créé automatiquement, lié au champ enum pour {@link #applyErrors}.
     */
    public FormGrid row(String labelText, Component field, Enum<?> fieldKey) {
        var errLabel = new Label("").setForegroundColor(TextColor.ANSI.RED);
        errorLabels.put(fieldKey, errLabel);
        return row(labelText, field, errLabel);
    }

    public FormGrid row(String labelText, Component field, Component error) {
        addComponent(new Label(labelText));
        addComponent(field);
        if (error != null) {
            addEmpty();
            addComponent(error);
        }
        return this;
    }

    /**
     * Met à jour tous les labels d'erreur enregistrés via {@link #row(String, Component, Enum)}.
     */
    public FormGrid applyErrors(ErrorList errors) {
        errorLabels.forEach((field, label) ->
                label.setText(errors.getFirstErrorMessage(field)));
        return this;
    }

    @Override
    public FormGrid addEmpty() {
        return (FormGrid) super.addEmpty();
    }

    @Override
    public FormGrid alignInParent(Pos pos) {
        return (FormGrid) super.alignInParent(pos);
    }

    @Override
    public FormGrid alignInVBox(Pos pos) {
        return (FormGrid) super.alignInVBox(pos);
    }

    @Override
    public FormGrid alignInHBox(Pos pos) {
        return (FormGrid) super.alignInHBox(pos);
    }

    @Override
    public FormGrid fillInParent() {
        return (FormGrid) super.fillInParent();
    }

    @Override
    public FormGrid fillInParent(Priority grow) {
        return (FormGrid) super.fillInParent(grow);
    }
}
