package tgpr.framework.ui.layout;

import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.gui2.BorderLayout;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.LayoutManager;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;

/**
 * {@link BorderLayout} avec espacement entre les zones et alignement optionnel du centre.
 */
final class SpacedBorderLayout implements LayoutManager {
    private int horizontalGap;
    private int verticalGap;
    private int paddingLeft;
    private int paddingTop;
    private int paddingRight;
    private int paddingBottom;
    private Pos centerAlign;
    private boolean changed = true;

    void setSpacing(Spacing spacing) {
        horizontalGap = spacing.getHorizontal();
        verticalGap = spacing.getVertical();
        changed = true;
    }

    void setPadding(Insets padding) {
        paddingLeft = padding.getLeft();
        paddingTop = padding.getTop();
        paddingRight = padding.getRight();
        paddingBottom = padding.getBottom();
        changed = true;
    }

    void setCenterAlign(Pos centerAlign) {
        this.centerAlign = centerAlign;
        changed = true;
    }

    @Override
    public TerminalSize getPreferredSize(List<Component> components) {
        var layout = makeLookupMap(components);
        int middleRows = Math.max(
                rowSize(layout, BorderLayout.Location.LEFT),
                Math.max(
                        rowSize(layout, BorderLayout.Location.CENTER),
                        rowSize(layout, BorderLayout.Location.RIGHT)));

        int height = paddingTop + paddingBottom
                + rowSize(layout, BorderLayout.Location.TOP)
                + middleRows
                + rowSize(layout, BorderLayout.Location.BOTTOM)
                + verticalGaps(layout);

        int middleColumns = columnSize(layout, BorderLayout.Location.LEFT)
                + columnSize(layout, BorderLayout.Location.CENTER)
                + columnSize(layout, BorderLayout.Location.RIGHT)
                + horizontalGaps(layout);

        int width = paddingLeft + paddingRight + Math.max(
                middleColumns,
                Math.max(
                        columnSize(layout, BorderLayout.Location.TOP),
                        columnSize(layout, BorderLayout.Location.BOTTOM)));

        return new TerminalSize(width, height);
    }

    @Override
    public void doLayout(TerminalSize area, List<Component> components) {
        if (area.getColumns() <= paddingLeft + paddingRight || area.getRows() <= paddingTop + paddingBottom) {
            zeroUnassigned(components, makeLookupMap(components));
            changed = false;
            return;
        }

        var inner = area.withRelative(-paddingLeft - paddingRight, -paddingTop - paddingBottom);
        var layout = makeLookupMap(components);
        int availableHorizontalSpace = inner.getColumns();
        int availableVerticalSpace = inner.getRows();

        int topComponentHeight = 0;
        int leftComponentWidth = 0;
        int yOffset = paddingTop;

        if (layout.containsKey(BorderLayout.Location.TOP)) {
            var topComponent = layout.get(BorderLayout.Location.TOP);
            topComponentHeight = Math.min(topComponent.getPreferredSize().getRows(), availableVerticalSpace);
            topComponent.setPosition(new TerminalPosition(paddingLeft, yOffset));
            topComponent.setSize(new TerminalSize(inner.getColumns(), topComponentHeight));
            availableVerticalSpace -= topComponentHeight;
            yOffset += topComponentHeight;
            if (hasMiddleBand(layout)) {
                availableVerticalSpace -= applyVerticalGap(availableVerticalSpace);
                yOffset += verticalGap;
            }
        }

        int bottomComponentHeight = 0;
        if (layout.containsKey(BorderLayout.Location.BOTTOM)) {
            var bottomComponent = layout.get(BorderLayout.Location.BOTTOM);
            bottomComponentHeight = Math.min(bottomComponent.getPreferredSize().getRows(), availableVerticalSpace);
            if (hasMiddleBand(layout)) {
                availableVerticalSpace -= applyVerticalGap(availableVerticalSpace);
            }
            int bottomY = paddingTop + inner.getRows() - bottomComponentHeight;
            bottomComponent.setPosition(new TerminalPosition(paddingLeft, bottomY));
            bottomComponent.setSize(new TerminalSize(inner.getColumns(), bottomComponentHeight));
            availableVerticalSpace -= bottomComponentHeight;
        }

        int middleBandHeight = availableVerticalSpace;
        int xOffset = paddingLeft;

        if (layout.containsKey(BorderLayout.Location.LEFT)) {
            var leftComponent = layout.get(BorderLayout.Location.LEFT);
            leftComponentWidth = Math.min(leftComponent.getPreferredSize().getColumns(), availableHorizontalSpace);
            leftComponent.setPosition(new TerminalPosition(xOffset, yOffset));
            leftComponent.setSize(new TerminalSize(leftComponentWidth, middleBandHeight));
            availableHorizontalSpace -= leftComponentWidth;
            xOffset += leftComponentWidth;
            if (layout.containsKey(BorderLayout.Location.CENTER) || layout.containsKey(BorderLayout.Location.RIGHT)) {
                availableHorizontalSpace -= applyHorizontalGap(availableHorizontalSpace);
                xOffset += horizontalGap;
            }
        }

        if (layout.containsKey(BorderLayout.Location.RIGHT)) {
            var rightComponent = layout.get(BorderLayout.Location.RIGHT);
            int rightComponentWidth = Math.min(rightComponent.getPreferredSize().getColumns(), availableHorizontalSpace);
            if (layout.containsKey(BorderLayout.Location.CENTER)) {
                availableHorizontalSpace -= applyHorizontalGap(availableHorizontalSpace);
            }
            int rightX = paddingLeft + inner.getColumns() - rightComponentWidth;
            rightComponent.setPosition(new TerminalPosition(rightX, yOffset));
            rightComponent.setSize(new TerminalSize(rightComponentWidth, middleBandHeight));
            if (!layout.containsKey(BorderLayout.Location.CENTER)) {
                availableHorizontalSpace -= rightComponentWidth;
            } else {
                availableHorizontalSpace -= rightComponentWidth + horizontalGap;
            }
        }

        if (layout.containsKey(BorderLayout.Location.CENTER)) {
            var centerComponent = layout.get(BorderLayout.Location.CENTER);
            int centerWidth = availableHorizontalSpace;
            int centerHeight = middleBandHeight;
            int centerYOffset = yOffset;

            if (centerAlign != null) {
                centerHeight = Math.min(centerComponent.getPreferredSize().getRows(), middleBandHeight);
                centerYOffset += verticalOffsetInBand(centerAlign, middleBandHeight, centerHeight);
            }

            centerComponent.setPosition(new TerminalPosition(xOffset, centerYOffset));
            centerComponent.setSize(new TerminalSize(centerWidth, centerHeight));
        }

        zeroUnassigned(components, layout);
        changed = false;
    }

    @Override
    public boolean hasChanged() {
        return changed;
    }

    private int applyVerticalGap(int availableVerticalSpace) {
        return availableVerticalSpace > 0 ? Math.min(verticalGap, availableVerticalSpace) : 0;
    }

    private int applyHorizontalGap(int availableHorizontalSpace) {
        return availableHorizontalSpace > 0 ? Math.min(horizontalGap, availableHorizontalSpace) : 0;
    }

    private static boolean hasMiddleBand(EnumMap<BorderLayout.Location, Component> layout) {
        return layout.containsKey(BorderLayout.Location.LEFT)
                || layout.containsKey(BorderLayout.Location.CENTER)
                || layout.containsKey(BorderLayout.Location.RIGHT);
    }

    private int verticalGaps(EnumMap<BorderLayout.Location, Component> layout) {
        int gaps = 0;
        if (layout.containsKey(BorderLayout.Location.TOP) && hasMiddleBand(layout)) {
            gaps += verticalGap;
        }
        if (layout.containsKey(BorderLayout.Location.BOTTOM) && hasMiddleBand(layout)) {
            gaps += verticalGap;
        }
        return gaps;
    }

    private int horizontalGaps(EnumMap<BorderLayout.Location, Component> layout) {
        int gaps = 0;
        if (layout.containsKey(BorderLayout.Location.LEFT)
                && (layout.containsKey(BorderLayout.Location.CENTER) || layout.containsKey(BorderLayout.Location.RIGHT))) {
            gaps += horizontalGap;
        }
        if (layout.containsKey(BorderLayout.Location.CENTER) && layout.containsKey(BorderLayout.Location.RIGHT)) {
            gaps += horizontalGap;
        }
        return gaps;
    }

    private static int rowSize(EnumMap<BorderLayout.Location, Component> layout, BorderLayout.Location location) {
        return layout.containsKey(location) ? layout.get(location).getPreferredSize().getRows() : 0;
    }

    private static int columnSize(EnumMap<BorderLayout.Location, Component> layout, BorderLayout.Location location) {
        return layout.containsKey(location) ? layout.get(location).getPreferredSize().getColumns() : 0;
    }

    private static int verticalOffsetInBand(Pos align, int bandHeight, int componentHeight) {
        int extra = bandHeight - componentHeight;
        if (extra <= 0) {
            return 0;
        }
        return switch (align.toVerticalGridAlignment()) {
            case BEGINNING -> 0;
            case CENTER -> extra / 2;
            case END -> extra;
            default -> 0;
        };
    }

    private static void zeroUnassigned(List<Component> components, EnumMap<BorderLayout.Location, Component> layout) {
        for (var component : components) {
            if (component.isVisible() && !layout.containsValue(component)) {
                component.setPosition(TerminalPosition.TOP_LEFT_CORNER);
                component.setSize(TerminalSize.ZERO);
            }
        }
    }

    private static EnumMap<BorderLayout.Location, Component> makeLookupMap(List<Component> components) {
        var map = new EnumMap<BorderLayout.Location, Component>(BorderLayout.Location.class);
        var unassigned = new ArrayList<Component>();
        for (var component : components) {
            if (!component.isVisible()) {
                continue;
            }
            if (component.getLayoutData() instanceof BorderLayout.Location location) {
                map.put(location, component);
            } else {
                unassigned.add(component);
            }
        }
        for (var location : List.of(
                BorderLayout.Location.CENTER,
                BorderLayout.Location.TOP,
                BorderLayout.Location.BOTTOM,
                BorderLayout.Location.LEFT,
                BorderLayout.Location.RIGHT)) {
            for (var component : unassigned) {
                if (!map.containsKey(location)) {
                    map.put(location, component);
                    break;
                }
            }
        }
        return map;
    }
}
