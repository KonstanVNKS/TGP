package tgpr.framework.mvc;

import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.gui2.*;
import com.googlecode.lanterna.gui2.Window;
import com.googlecode.lanterna.gui2.dialogs.DialogWindow;
import com.googlecode.lanterna.gui2.dialogs.MessageDialog;
import com.googlecode.lanterna.gui2.dialogs.MessageDialogButton;
import tgpr.framework.util.Configuration;
import tgpr.framework.ui.MessageBox;
import tgpr.framework.util.OSType;
import tgpr.framework.validation.Error;
import com.googlecode.lanterna.gui2.table.Table;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.MouseAction;
import com.googlecode.lanterna.input.MouseActionType;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.swing.SwingTerminal;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFontConfiguration;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import tgpr.framework.ui.component.DatePicker;

public class ViewManager {
    private static MultiWindowTextGUI gui;
    private static Window currentWindow;
    private static final boolean mouseEnabled =
            Boolean.parseBoolean(Configuration.get("mouse.enabled", "true"));
    /** Molette/trackpad : windows=true, mac/linux=false par défaut (surcharge via config). */
    private static final boolean mouseWheelEnabled = resolveMouseWheelEnabled();
    /** Accumulateur molette/trackpad (partagé pour pouvoir le vider en butée). */
    private static double wheelAccumulator;
    /** Gain trackpad : macOS (momentum) plus agressif → plus amorti ; Windows quasi 1:1. */
    private static final double TRACKPAD_GAIN =
            OSType.DETECTED == OSType.MacOS ? 0.35 : 1.0;
    /** Seuil (après gain) pour émettre une ligne en mode trackpad. */
    private static final double TRACKPAD_STEP =
            OSType.DETECTED == OSType.MacOS ? 2.0 : 1.0;

    static {
        try {
            DefaultTerminalFactory factory = new DefaultTerminalFactory();

            // Ces deux lignes sont nécessaires depuis JDK 22+ sinon lanterna réclame javaw au lieu de java
            factory.setForceTextTerminal(false);      // Ne force PAS le terminal texte natif
            factory.setPreferTerminalEmulator(true);  // Préfère l'émulateur graphique

            factory.setInitialTerminalSize(new TerminalSize(Configuration.getInt("terminal.width"),
                    Configuration.getInt("terminal.height")));
            factory.setTerminalEmulatorFontConfiguration(
                    SwingTerminalFontConfiguration.newInstance(new Font(getFontName(), Font.PLAIN,
                            Configuration.getInt("fontsize"))));
            SwingTerminalFrame terminal = (SwingTerminalFrame) factory.createTerminal();
            if (mouseEnabled) {
                // Lanterna 3.1.5 n'envoie pas les clics souris Swing vers le GUI : on les injecte manuellement
                enableSwingMouseSupport(terminal);
            }
            terminal.setResizable(false);
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            terminal.setLocation((screenSize.width - terminal.getWidth()) / 2,
                    (screenSize.height - terminal.getHeight()) / 2);
            terminal.setTitle(Configuration.get("title"));
            Screen screen = new TerminalScreen(terminal);
            screen.startScreen();
            // Sous-classe : focus souris + toggle ComboBox (si mouse.enabled)
            gui = new MultiWindowTextGUI(screen, new DefaultWindowManager(),
                    new EmptySpace(TextColor.ANSI.valueOf(Configuration.get("backgroundColor")))) {
                @Override
                public synchronized WindowBasedTextGUI addWindow(Window window) {
                    ensureDialogKeepsModal(window);
                    if (mouseEnabled) {
                        installMouseFocusOnClick(window);
                    }
                    return super.addWindow(window);
                }

                /**
                 * Remplace le comportement Lanterna qui appelle {@code setActiveWindow} sur <b>chaque</b>
                 * fenêtre contenant le clic (du fond vers le haut). Chaque appel fait {@code moveToTop} :
                 * un clic sur un {@link DatePicker} qui dépasse sous un dialog active d’abord l’agenda
                 * plein écran → le dialog passe derrière (semble fermé) alors que le popup reste ouvert.
                 * <p>
                 * Ici : seule la fenêtre la plus haute sous le curseur est activée ; les dialogs
                 * ({@link DialogWindow} / {@link Window.Hint#MODAL}) ne sont pas enfouis sous le fond ;
                 * fermeture {@link Window.Hint#MENU_POPUP} hors popup restaure le dialog propriétaire.
                 */
                @Override
                protected synchronized void ifMouseDownPossiblyChangeActiveWindow(KeyStroke keyStroke) {
                    if (!(keyStroke instanceof MouseAction mouse) || !mouse.isMouseDown()) {
                        return;
                    }

                    Window prior = getActiveWindow();
                    List<Window> windows = new ArrayList<>(getWindows());
                    Window hit = topmostWindowAt(windows, mouse.getPosition());
                    Window blockingDialog = topmostBlockingDialog(windows);

                    // Clic hors dialog (et hors son MENU_POPUP) : ne pas activer le fond
                    if (blockingDialog != null
                            && hit != blockingDialog
                            && (hit == null || !hit.getHints().contains(Window.Hint.MENU_POPUP))) {
                        if (prior != null && prior.getHints().contains(Window.Hint.MENU_POPUP)) {
                            closeMenuPopupRestoringOwner(prior, blockingDialog);
                        }
                        return;
                    }

                    if (hit != null) {
                        setActiveWindow(hit);
                    }

                    if (prior != null
                            && prior.getHints().contains(Window.Hint.MENU_POPUP)
                            && (prior != getActiveWindow() || hit == null)) {
                        closeMenuPopupRestoringOwner(prior, blockingDialog);
                    }
                }

                /** Toggle ComboBox : consommer le clic pour ne pas rouvrir le popup. */
                @Override
                public synchronized boolean handleInput(KeyStroke keyStroke) {
                    if (mouseEnabled
                            && keyStroke instanceof MouseAction mouse && mouse.isMouseDown()
                            && ListMouseInterceptor.tryToggleClosePopup(this, mouse)) {
                        return true;
                    }
                    return super.handleInput(keyStroke);
                }
            };
        } catch (IOException e) {
            System.err.println(e);
            System.exit(1);
        }
    }

    private static String getFontName() {
        String fontName = null;
        switch (OSType.DETECTED) {
            case Windows:
                fontName = Configuration.get("fontname.windows");
                break;
            case Linux:
                fontName = Configuration.get("fontname.linux");
                break;
            case MacOS:
                fontName = Configuration.get("fontname.mac");
                break;
            case Other:
                fontName = Configuration.get("fontname.other");
                break;
            default:
                throw new RuntimeException("Unsupported OS");
        }
        return fontName;
    }

    // Lanterna 3.1.5 : le terminal Swing n'émet pas de MouseAction, on les injecte depuis AWT
    private static void enableSwingMouseSupport(SwingTerminalFrame terminal) {
        int fontWidth = terminal.getFontConfiguration().getFontWidth();
        int fontHeight = terminal.getFontConfiguration().getFontHeight();
        SwingTerminal swingTerminal = (SwingTerminal) terminal.getContentPane().getComponent(0);
        swingTerminal.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                terminal.addInput(new MouseAction(
                        MouseActionType.CLICK_DOWN,
                        toLanternaMouseButton(e.getButton()),
                        toTerminalPosition(e, fontWidth, fontHeight)));
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                terminal.addInput(new MouseAction(
                        MouseActionType.CLICK_RELEASE,
                        toLanternaMouseButton(e.getButton()),
                        toTerminalPosition(e, fontWidth, fontHeight)));
            }
        });
        if (!mouseWheelEnabled) {
            return;
        }
        // Accumulateur : molette (±1) = 1 ligne ; trackpad amorti (seuil + gain)
        swingTerminal.addMouseWheelListener(e -> {
            double precise = e.getPreciseWheelRotation();
            if (Math.abs(precise) < 1e-4) {
                return;
            }
            // Molette = cran entier (precise ≈ wheel) : sens AWT historique
            // Trackpad = fractions / wheel==0 : inverser (scroll naturel)
            int wheel = e.getWheelRotation();
            boolean mouseNotch = wheel != 0 && Math.abs(precise - wheel) < 1e-6;
            double delta = mouseNotch ? precise : -precise * TRACKPAD_GAIN;
            if (wheelAccumulator != 0.0 && Math.signum(delta) != Math.signum(wheelAccumulator)) {
                wheelAccumulator = 0.0;
            }
            wheelAccumulator += delta;
            double stepSize = mouseNotch ? 1.0 : TRACKPAD_STEP;
            int steps = (int) (wheelAccumulator / stepSize); // troncature vers 0
            if (steps == 0) {
                return;
            }
            wheelAccumulator -= steps * stepSize;
            MouseActionType type = steps < 0
                    ? MouseActionType.SCROLL_UP
                    : MouseActionType.SCROLL_DOWN;
            TerminalPosition pos = toTerminalPosition(e, fontWidth, fontHeight);
            for (int i = 0, n = Math.abs(steps); i < n; i++) {
                terminal.addInput(new MouseAction(type, 0, pos));
            }
        });
    }

    /**
     * {@code mouse.wheel.enabled.<os>} puis {@code mouse.wheel.enabled},
     * sinon Windows=true / mac·linux·other=false.
     */
    private static boolean resolveMouseWheelEnabled() {
        String osKey = switch (OSType.DETECTED) {
            case Windows -> "windows";
            case MacOS -> "mac";
            case Linux -> "linux";
            case Other -> "other";
        };
        String specific = Configuration.get("mouse.wheel.enabled." + osKey, null);
        if (specific != null && !specific.isBlank()) {
            return Boolean.parseBoolean(specific.trim());
        }
        String global = Configuration.get("mouse.wheel.enabled", null);
        if (global != null && !global.isBlank()) {
            return Boolean.parseBoolean(global.trim());
        }
        return OSType.DETECTED == OSType.Windows;
    }

    /** Vide le reste d'accumulateur (butée haut/bas : évite un micro-saut au rebond). */
    static void clearWheelAccumulator() {
        wheelAccumulator = 0.0;
    }

    private static TerminalPosition toTerminalPosition(MouseEvent e, int fontWidth, int fontHeight) {
        return new TerminalPosition(e.getX() / fontWidth, e.getY() / fontHeight);
    }

    private static int toLanternaMouseButton(int awtButton) {
        return switch (awtButton) {
            case MouseEvent.BUTTON1 -> 1; // gauche
            case MouseEvent.BUTTON2 -> 2; // milieu
            case MouseEvent.BUTTON3 -> 3; // droit
            default -> 0;
        };
    }

    // Focus au clic ; Table/ActionListBox : clic = sélection, double-clic = action ; molette Table
    private static void installMouseFocusOnClick(Window window) {
        window.addWindowListener(new WindowListenerAdapter() {
            @Override
            public void onInput(Window basePane, KeyStroke keyStroke, AtomicBoolean deliverEvent) {
                if (!(keyStroke instanceof MouseAction mouse)) {
                    return;
                }
                // Ne pas voler le focus tant qu'une autre fenêtre MODAL / MENU_POPUP est active
                Window active = gui.getActiveWindow();
                if (active != null && active != window
                        && (active.getHints().contains(Window.Hint.MODAL)
                        || active.getHints().contains(Window.Hint.MENU_POPUP)
                        || active instanceof DialogWindow)) {
                    return;
                }
                // Molette : Table (custom) ; ListBox/TextBox laissés à Lanterna
                if (mouse.getActionType() == MouseActionType.SCROLL_UP
                        || mouse.getActionType() == MouseActionType.SCROLL_DOWN) {
                    Interactable target = findInteractableAt(window.getMenuBar(), mouse.getPosition());
                    if (target == null) {
                        target = findInteractableAt(window.getComponent(), mouse.getPosition());
                    }
                    if (target instanceof Table<?> table
                            && ListMouseInterceptor.tryHandleTableWheel(table, mouse)) {
                        deliverEvent.set(false);
                        try {
                            gui.updateScreen();
                        } catch (IOException ignored) {
                        }
                    }
                    return;
                }
                if (!mouse.isMouseDown()) {
                    return;
                }
                Interactable target = findInteractableAt(window.getMenuBar(), mouse.getPosition());
                if (target == null) {
                    target = findInteractableAt(window.getComponent(), mouse.getPosition());
                }
                if (target == null) {
                    return;
                }
                if (ListMouseInterceptor.tryHandle(target, mouse, deliverEvent)) {
                    try {
                        gui.updateScreen();
                    } catch (IOException ignored) {
                    }
                    return;
                }
                target.takeFocus();
                try {
                    gui.updateScreen();
                } catch (IOException ignored) {
                }
            }
        });
    }

    private static Interactable findInteractableAt(Component root, TerminalPosition global) {
        if (root == null || global == null || !root.isVisible()) {
            return null;
        }
        if (root instanceof Container container) {
            for (Component child : container.getChildrenList()) {
                Interactable found = findInteractableAt(child, global);
                if (found != null) {
                    return found;
                }
            }
        }
        if (!(root instanceof Interactable interactable)
                || !interactable.isEnabled()
                || !interactable.isFocusable()) {
            return null;
        }
        TerminalPosition topLeft = root.toGlobal(TerminalPosition.TOP_LEFT_CORNER);
        if (topLeft == null) {
            return null;
        }
        TerminalSize size = root.getSize();
        if (global.getColumn() >= topLeft.getColumn()
                && global.getColumn() < topLeft.getColumn() + size.getColumns()
                && global.getRow() >= topLeft.getRow()
                && global.getRow() < topLeft.getRow() + size.getRows()) {
            return interactable;
        }
        return null;
    }

    /**
     * {@link DialogWindow} pose {@link Window.Hint#MODAL}, mais un {@code setHints(CENTERED)}
     * seul l’efface. Rétabli à l’ajout de toute fenêtre dialog — transparent pour les vues métier.
     */
    private static void ensureDialogKeepsModal(Window window) {
        if (!(window instanceof DialogWindow)) {
            return;
        }
        if (window.getHints().contains(Window.Hint.MODAL)) {
            return;
        }
        var hints = new LinkedHashSet<>(window.getHints());
        hints.add(Window.Hint.MODAL);
        window.setHints(hints);
    }

    /** Fenêtre la plus haute (fin de liste Lanterna) contenant {@code position}. */
    private static Window topmostWindowAt(List<Window> windows, TerminalPosition position) {
        for (int i = windows.size() - 1; i >= 0; i--) {
            Window w = windows.get(i);
            AtomicBoolean inside = new AtomicBoolean(false);
            w.getBounds().whenContains(position, () -> inside.set(true));
            if (inside.get()) {
                return w;
            }
        }
        return null;
    }

    /**
     * Dialog / modale la plus haute (hors {@link Window.Hint#MENU_POPUP}).
     * Beaucoup de vues remplacent les hints et perdent {@code MODAL} → on reconnaît aussi {@link DialogWindow}.
     */
    private static Window topmostBlockingDialog(List<Window> windows) {
        for (int i = windows.size() - 1; i >= 0; i--) {
            Window w = windows.get(i);
            if (w.getHints().contains(Window.Hint.MENU_POPUP)) {
                continue;
            }
            if (w instanceof DialogWindow || w.getHints().contains(Window.Hint.MODAL)) {
                return w;
            }
        }
        return null;
    }

    /**
     * Ferme un {@link Window.Hint#MENU_POPUP} et réactive le dialog propriétaire
     * (ancre DatePicker / fallback {@code ownerFallback}) pour ne pas laisser l’agenda au premier plan.
     */
    private static void closeMenuPopupRestoringOwner(Window popup, Window ownerFallback) {
        Window owner = null;
        if (popup instanceof DatePicker datePicker) {
            Component anchor = datePicker.getAnchor();
            if (anchor != null) {
                BasePane pane = anchor.getBasePane();
                if (pane instanceof Window window) {
                    owner = window;
                }
            }
        }
        if (owner == null) {
            owner = ownerFallback;
        }
        popup.close();
        if (owner != null && gui.getWindows().contains(owner)) {
            gui.setActiveWindow(owner);
        }
    }

    public static TerminalSize getTerminalSize() {
        return gui.getScreen().getTerminalSize();
    }

    public static int getTerminalColumns() {
        return getTerminalSize().getColumns();
    }

    public static int getTerminalRows() {
        return getTerminalSize().getRows();
    }

    /**
     * Permet d'afficher une boîte de dialogue modale présentant les erreurs reçues en paramètre.
     * Les erreurs sont représentées par des instances de {@link Error}.
     *
     * @param errors la liste des erreurs à afficher
     */
    static void showErrors(List<Error> errors) {
        showErrors(errors, "Error");
    }

    /**
     * Permet d'afficher une boîte de dialogue modale présentant une erreur reçue en paramètre.
     * L'erreur est représentée par une instances de {@link Error}.
     *
     * @param error l'erreur à afficher
     */
    static void showError(Error error) {
        showErrors(List.of(error));
    }

    static void showErrors(List<Error> errors, String title) {
        var errorsText = errors.stream().map(Error::getMessage).collect(Collectors.toList());
        if (!errors.isEmpty())
            MessageDialog.showMessageDialog(gui, title, String.join("\n", errorsText), MessageDialogButton.OK);
    }

    static MessageDialogButton showMessage(String message, String title, MessageDialogButton... buttons) {
        return MessageDialog.showMessageDialog(gui, title, message, buttons);
    }

    static String showMessage(String message, String title, String[] buttons) {
        var dialog = new MessageBox(message, title, buttons);
        showModal(dialog);
        return dialog.getClickedButton();
    }

    public static void navigateTo(Window window) {
        if (window == null)
            return;
        // Ferme tout (y compris MenuPopup inactif) — sinon le menu flottant reste après Déconnexion à la souris
        for (Window w : List.copyOf(gui.getWindows())) {
            w.close();
        }
        currentWindow = window;
        gui.addWindowAndWait(window);
    }

    /**
     * Ferme la fenêtre modale au premier plan si ce n’est pas l’accueil ({@link #currentWindow}).
     */
    public static void closeActiveModalIfNotHome() {
        Window active = gui.getActiveWindow();
        if (active != null && active != currentWindow) {
            active.close();
        }
    }

    /** Ferme toutes les fenêtres empilées au-dessus de l’accueil courant (modales et menus popup). */
    public static void closeAllModalsAboveHome() {
        for (Window w : List.copyOf(gui.getWindows())) {
            if (w != currentWindow) {
                w.close();
            }
        }
    }

    /**
     * Indique si au moins une fenêtre du type donné est actuellement ouverte
     * (accueil ou dialog empilé).
     */
    public static boolean hasOpenWindow(Class<? extends Window> type) {
        return !getOpenWindows(type).isEmpty();
    }

    /**
     * Fenêtres ouvertes du type donné (copie défensive), dans l’ordre de la pile GUI.
     */
    public static List<Window> getOpenWindows(Class<? extends Window> type) {
        if (gui == null || type == null)
            return List.of();
        return List.copyOf(gui.getWindows()).stream()
                .filter(type::isInstance)
                .collect(Collectors.toList());
    }

    /**
     * Affiche une fenêtre dialog modale.
     * Ferme d'abord les {@link Window.Hint#MENU_POPUP} encore ouverts (menu Lanterna,
     * DatePicker, TimePicker) pour éviter qu'un menu flottant reste cliquable et
     * empile d'autres dialogs pendant {@code showDialog}. N'affecte pas l'empilement
     * des {@link DialogWindow} métier.
     */
    public static void showModal(DialogWindow window) {
        closeMenuPopups();
        window.showDialog(gui);
    }

    /** Ferme les fenêtres {@link Window.Hint#MENU_POPUP} de la pile GUI. */
    private static void closeMenuPopups() {
        if (gui == null)
            return;
        for (Window w : List.copyOf(gui.getWindows())) {
            if (w.getHints().contains(Window.Hint.MENU_POPUP))
                w.close();
        }
    }
}
