package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Direction;
import com.googlecode.lanterna.gui2.LayoutData;

/**
 * Conteneur horizontal, équivalent de {@code javafx.scene.layout.HBox}.
 * <p>
 * {@link #create()} applique {@code spacing(1)} par défaut : une rangée de boutons ou de champs
 * côte à côte a presque toujours besoin d'un espace horizontal. {@link VBox#create()}, lui, part
 * de {@code spacing(0)} ; l'espacement vertical se choisit explicitement ou via
 * {@link VBox#createExpanded()} / {@link VBox#createCentered()} selon le contexte.
 * <p>
 * Alignement des enfants sur l'axe vertical : {@link Pos#TOP_LEFT} par défaut (comme JavaFX
 * {@code HBox.alignment}). Le centrage vertical se demande via {@link #childrenAlign(Pos)}
 * ({@link Pos#CENTER}) ou {@link #add(Component, Pos)}.
 */
public class HBox extends Box {
    protected HBox() {
    }

    /**
     * Conteneur horizontal avec un espace de 1 colonne entre les enfants ({@code spacing(1)}).
     * Enfants en haut ({@link Pos#TOP_LEFT}).
     */
    public static HBox create() {
        return new HBox().spacing(1);
    }

    /**
     * Rangée de boutons centrée dans le dialogue parent.
     * S'appuie sur {@link #create()} : espacement horizontal déjà inclus.
     */
    public static HBox createButtonRow(Component... buttons) {
        return create().add(buttons).alignInParent(Pos.CENTER);
    }

    public static HBox create(int spacing, Component... children) {
        return create().spacing(spacing).add(children);
    }

    @Override
    public HBox alignInParent(Pos pos) {
        return (HBox) super.alignInParent(pos);
    }

    @Override
    public HBox alignInVBox(Pos pos) {
        return (HBox) super.alignInVBox(pos);
    }

    @Override
    public HBox alignInHBox(Pos pos) {
        return (HBox) super.alignInHBox(pos);
    }

    @Override
    public HBox fillInParent() {
        return (HBox) super.fillInParent();
    }

    @Override
    public HBox fillInParent(Priority grow) {
        return (HBox) super.fillInParent(grow);
    }

    @Override
    protected Direction direction() {
        return Direction.HORIZONTAL;
    }

    @Override
    protected Pos defaultChildrenAlign() {
        return Pos.TOP_LEFT;
    }

    public static void setHgrow(Component node, Priority priority) {
        setHgrow(node, priority, Pos.CENTER);
    }

    public static void setHgrow(Component node, Priority priority, Pos alignment) {
        setHgrow(node, priority, alignment, false);
    }

    public static void setHgrow(Component node, Priority priority, Pos alignment, boolean fillCross) {
        node.setLayoutData(Constraints.linear(Direction.HORIZONTAL, alignment, priority, fillCross));
    }

    /** Remplit l'axe vertical du {@link HBox} et applique {@code priority} sur l'axe horizontal. */
    public static void setHgrowFill(Component node, Priority priority) {
        setHgrow(node, priority, Pos.CENTER, true);
    }

    @Override
    public HBox spacing(int spacing) {
        return (HBox) super.spacing(spacing);
    }

    @Override
    public HBox padding(Insets insets) {
        return (HBox) super.padding(insets);
    }

    @Override
    public HBox childrenAlign(Pos alignment) {
        return (HBox) super.childrenAlign(alignment);
    }

    @Override
    public HBox childrenFill() {
        return (HBox) super.childrenFill();
    }

    @Override
    public HBox childrenFill(boolean on) {
        return (HBox) super.childrenFill(on);
    }

    @Override
    public HBox add(Component... children) {
        return (HBox) super.add(children);
    }

    @Override
    public HBox add(Component child, Pos childAlign) {
        return (HBox) super.add(child, childAlign);
    }

    @Override
    public HBox add(Component child, Pos childAlign, Priority grow) {
        return (HBox) super.add(child, childAlign, grow);
    }

    @Override
    public HBox add(Component child, Pos childAlign, Priority grow, boolean fillCrossAxis) {
        return (HBox) super.add(child, childAlign, grow, fillCrossAxis);
    }

    @Override
    public HBox addFill(Component child, Priority mainGrow) {
        return (HBox) super.addFill(child, mainGrow);
    }

    @Override
    public HBox add(Component child, LayoutData constraints) {
        return (HBox) super.add(child, constraints);
    }

    @Override
    public HBox remove(Component child) {
        return (HBox) super.remove(child);
    }

    @Override
    public HBox clear() {
        return (HBox) super.clear();
    }
}
