package tgpr.framework.ui.component;

import com.googlecode.lanterna.SGR;
import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TerminalTextUtils;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.ThemeDefinition;
import com.googlecode.lanterna.gui2.Button;
import com.googlecode.lanterna.gui2.TextGUIGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;

/**
 * Bouton à largeur égale au libellé — sans le minimum de 8 colonnes du
 * {@link DefaultButtonRenderer}.
 * <p>
 * Par défaut : {@link FlatButtonRenderer}. Pour un glyphe type ComboBox ({@code ▼}, {@code ◀}, …)
 * en noir sans BOLD : {@link #plainGlyph(String, Runnable)}.
 */
public class CompactButton extends Button {

    public CompactButton(String label) {
        this(label, () -> {
        });
    }

    public CompactButton(String label, Runnable action) {
        super(requireLabel(label), action);
        // Le thème peut remplacer le renderer issu de createDefaultRenderer :
        // forcer Flat après construction pour rester compact.
        setRenderer(new FlatButtonRenderer());
    }

    /**
     * Glyphe compact : texte noir, sans BOLD ; focus en reverse.
     */
    public static CompactButton plainGlyph(String label, Runnable action) {
        return plainGlyph(label, action, true);
    }

    /**
     * Glyphe compact noir sans BOLD.
     *
     * @param retainFocusOnClick si {@code false}, le bouton reste focusable (Tab / Entrée) mais un
     *                           clic souris ne lui laisse pas le focus (évite le mouse-up Lanterna
     *                           qui rappellerait {@code setFocusedInteractable(this)} après l’action)
     */
    public static CompactButton plainGlyph(String label, Runnable action, boolean retainFocusOnClick) {
        var button = new CompactButton(label, action) {
            @Override
            public Result handleKeyStroke(KeyStroke keyStroke) {
                if (isActivationStroke(keyStroke)) {
                    triggerActions();
                    return Result.HANDLED;
                }
                // Mouse up / drag : ne pas reprendre le focus après un clic qui a déjà déplacé le focus
                if (!retainFocusOnClick && keyStroke.getKeyType() == KeyType.MouseEvent) {
                    return Result.HANDLED;
                }
                return super.handleKeyStroke(keyStroke);
            }

            @Override
            protected ButtonRenderer createDefaultRenderer() {
                return new PlainGlyphRenderer();
            }
        };
        button.setRenderer(new PlainGlyphRenderer());
        return button;
    }

    @Override
    protected ButtonRenderer createDefaultRenderer() {
        return new FlatButtonRenderer();
    }

    /** Dessin partagé (jours soulignés, glyphes de nav, ▼ DateField). */
    static void drawPlainGlyph(TextGUIGraphics graphics, Button button, boolean underline) {
        ThemeDefinition theme = button.getThemeDefinition();
        graphics.clearModifiers();
        graphics.setBackgroundColor(theme.getNormal().getBackground());
        graphics.setForegroundColor(TextColor.ANSI.BLACK);
        if (button.isFocused()) {
            graphics.enableModifiers(SGR.REVERSE);
        }
        if (underline) {
            graphics.enableModifiers(SGR.UNDERLINE);
        }
        graphics.fill(' ');
        graphics.putString(0, 0, button.getLabel());
    }

    /** Renderer : noir, pas de BOLD. */
    public static final class PlainGlyphRenderer implements ButtonRenderer {
        @Override
        public TerminalPosition getCursorLocation(Button button) {
            return null;
        }

        @Override
        public TerminalSize getPreferredSize(Button button) {
            return new TerminalSize(Math.max(1, TerminalTextUtils.getColumnWidth(button.getLabel())), 1);
        }

        @Override
        public void drawComponent(TextGUIGraphics graphics, Button button) {
            drawPlainGlyph(graphics, button, false);
        }
    }

    private static String requireLabel(String label) {
        if (label == null || label.isEmpty()) {
            throw new IllegalArgumentException("CompactButton: libellé non vide requis");
        }
        return label;
    }
}
