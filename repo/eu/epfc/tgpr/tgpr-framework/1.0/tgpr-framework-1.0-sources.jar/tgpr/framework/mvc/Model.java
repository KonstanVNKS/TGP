package tgpr.framework.mvc;

import net.ttddyy.dsproxy.support.ProxyDataSourceBuilder;
import org.apache.ibatis.jdbc.ScriptRunner;
import org.mariadb.jdbc.MariaDbDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tgpr.framework.util.Configuration;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static tgpr.framework.util.Tools.asString;

/**
 * Classe de base pour les classes du modèle.
 */
public abstract class Model {
    private record CacheEntry(LocalDateTime timestamp, Object object) {
    }

    private static final Logger log = LoggerFactory.getLogger(Model.class);

    private static Connection db = null;

    private static final int cacheDuration = Configuration.getInt("db.cache.duration", 60);
    private static final boolean cacheEnabled = Configuration.get("db.cache.enabled", "false").equalsIgnoreCase("true");
    private static final boolean cacheDebug = Configuration.get("db.cache.debug", "false").equalsIgnoreCase("true");
    private static final HashMap<String, CacheEntry> cache = new HashMap<>();

    private static boolean isCachedExpired(LocalDateTime ts) {
        if (ts == null)
            return false;
        return ts.plusSeconds(cacheDuration).isBefore(LocalDateTime.now());
    }

    @SuppressWarnings("unchecked")
    private static <T> T castCachedValue(Object cachedResult) {
        return (T) cachedResult;
    }

    @SuppressWarnings("unchecked")
    private static <T> List<T> castCachedList(Object cachedResult) {
        return (List<T>) cachedResult;
    }

    private static String cacheKey(String sql, Params params) {
        var sorted = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
        sorted.putAll(params.getMap());
        return sql + "|" + sorted;
    }

    private static Object getFromCache(String key) {
        if (!cacheEnabled) return null;
        var entry = cache.get(key);
        if (entry != null && isCachedExpired(entry.timestamp)) {
            cache.remove(key);
            entry = null;
            if (cacheDebug)
                System.out.println(asString(LocalDateTime.now()) + ": Cache Removal: size=" + cache.size());
        }
        if (cacheDebug && entry == null)
            System.out.println(asString(LocalDateTime.now()) + ": Cache Miss: size=" + cache.size());
        return entry == null ? null : entry.object;
    }

    private static void addToCache(String key, Object obj) {
        if (!cacheEnabled) return;
        cache.put(key, new CacheEntry(LocalDateTime.now(), obj));
    }

    private static Map<String, Object> maskSensitive(Params params) {
        if (params == null) return Map.of();
        var masked = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
        for (var entry : params.getMap().entrySet()) {
            var name = entry.getKey().toLowerCase();
            if (name.contains("password") || name.contains("pwd")) {
                masked.put(entry.getKey(), "***");
            } else {
                masked.put(entry.getKey(), entry.getValue());
            }
        }
        return masked;
    }

    private static DatabaseException handleSqlError(String operation, String sql, Params params, SQLException cause) {
        var message = operation + " failed — sql=" + sql + ", params=" + maskSensitive(params);
        log.error(message, cause);
        return new DatabaseException(message, cause);
    }

    public static void clearCache() {
        if (cacheEnabled) {
            cache.clear();
            if (cacheDebug)
                System.out.println(asString(LocalDateTime.now()) + ": Cache Clear: size=" + cache.size());
        }
    }

    /**
     * Méthode abstraite à surcharger dans chaque classe du modèle pour copier (<i>mapper</i>) les données
     * récupérées en base de données (à travers un {@link ResultSet}) dans les attributs correspondant de la classe
     * du modèle.
     *
     * @param rs le {@link ResultSet} contenant les données récupérées en base de données ; il est positionné sur
     *           l'enregistrement pour lequel on veut <i>mapper</i> les données vers l'instance courante.
     * @throws SQLException en cas d'erreur de lecture ou de confusion de format de données
     */
    protected abstract void mapper(ResultSet rs) throws SQLException;

    private static boolean checkIfDatabaseExists(String resourceName) throws SQLException {
        try {
            getDatabaseConnection();
        } catch (SQLException e) {
            if (e.getMessage().contains("Unknown database")) {
                seedData(resourceName);
                getDatabaseConnection();
            }
        }
        try {
            if (db != null)
                return db.isValid(0);
            return false;
        } finally {
            if (db != null)
                db.close();
            db = null;
        }
    }

    private static Connection getDatabaseConnection() throws SQLException {
        if (db == null) {
            var server = Configuration.get("db.server");
            var database = Configuration.get("db.database");
            var user = Configuration.get("db.user");
            var password = Configuration.get("db.password");
            MariaDbDataSource ds = new MariaDbDataSource();
            ds.setUrl("jdbc:mariadb://" + server + ":3306/" + database);
            ds.setUser(user);
            ds.setPassword(password);
            if (Configuration.get("db.debug").equals("true"))
                db = ProxyDataSourceBuilder.create(ds)
                        .logQueryToSysOut()
                        .build().getConnection();
            else
                db = ds.getConnection();
        }
        return db;
    }

    private static Connection getServerConnection() throws SQLException {
        var server = Configuration.get("db.server");
        var user = Configuration.get("db.user");
        var password = Configuration.get("db.password");
        return DriverManager.getConnection("jdbc:mariadb://" + server + ":3306" + "?user=" + user + "&password" +
                "=" + password);
    }

    private static void closeDb() throws SQLException {
        if (db != null) {
            db.close();
            db = null;
        }
    }

    /**
     * Vérifie si le gestionnaire de base de données tourne et est joignable.
     *
     * @return vrai ssi c'est le cas
     */
    public static boolean checkDb(String resourceName) {
        try {
            return checkIfDatabaseExists(resourceName);
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Exécute le script SQL se trouvant dans le fichier dont le chemin est passé en paramètre. Ce fichier doit
     * être stocké dans les ressources du projet et le chemin doit correspondre à ce fichier.
     *
     * @param resourceName le chemin vers le fichier ressource contenant le script SQL à exécuter
     */
    public static void seedData(String resourceName) {
        try {
            var res = Model.class.getResourceAsStream(resourceName);
            if (res != null) {
                db = getServerConnection();
                ScriptRunner sr = new ScriptRunner(db);
                sr.setAutoCommit(false);
                Reader reader = new BufferedReader(new InputStreamReader(res));
                sr.runScript(reader);
                closeDb();
            }
        } catch (SQLException e) {
            throw handleSqlError("seedData", resourceName, null, e);
        }
    }

    protected static <T extends Model> T newInstance(Class<T> clazz, ResultSet rs) {
        if (Modifier.isAbstract(clazz.getModifiers()))
            throw new RuntimeException("Trying to instanciate an abstract class. You should pass your own " +
                    "implementation of newInstance that creates instances of concrete classes inheriting from this " +
                    "class.");
        try {
            return clazz.getDeclaredConstructor().newInstance();
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException |
                 NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée ne retourner qu'un seul enregistrement, et
     * retourne
     * l'objet métier correspondant à l'enregistrement trouvé, en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param type   le type d'objet à retourner
     * @param sql    la requête SQL de type {@code SELECT} ; les éventuels paramètres sont représentés par {@code :name}
     *               où {@code name} représente le nom du paramètre
     * @param params la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @param <T>    la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return une instance de la classe {@code T} contenant les données lues en base données
     */
    public static <T extends Model> T queryOne(Class<T> type, String sql, Params params) {
        var key = cacheKey(sql, params);
        var cachedResult = getFromCache(key);
        if (cachedResult != null && !(cachedResult instanceof ArrayList<?>)) return castCachedValue(cachedResult);
        try (var stmt = convertToUnnamedParams(sql, params);
             var rs = stmt.executeQuery()) {
            T obj = null;
            if (rs.next()) {
                obj = newInstance(type, rs);
                assert obj != null;
                obj.mapper(rs);
            }
            addToCache(key, obj);
            return obj;
        } catch (SQLException ex) {
            throw handleSqlError("queryOne", sql, params, ex);
        }
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée ne retourner qu'un seul enregistrement, et
     * retourne
     * l'objet métier correspondant à l'enregistrement trouvé, en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param type le type d'objet à retourner
     * @param sql  la requête SQL de type {@code SELECT} ; il s'agit d'une requête sans paramètre
     * @param <T>  la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return une instance de la classe {@code T} contenant les données lues en base données
     */
    public static <T extends Model> T queryOne(Class<T> type, String sql) {
        return queryOne(type, sql, new Params());
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée ne retourner qu'un seul enregistrement, et
     * retourne
     * l'objet métier correspondant à l'enregistrement trouvé, en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param getInstance retourne une nouvelle instance d'une classe du modèle en fonction de la valeur du
     *                    discriminateur
     * @param sql         la requête SQL de type {@code SELECT} ; les éventuels paramètres sont représentés par
     *                    {@code :name}
     *                    où {@code name} représente le nom du paramètre
     * @param params      la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @param <T>         la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return une instance de la classe {@code T} ou d'une classe héritant de {@code T} contenant les données lues
     * en base données
     */
    public static <T extends Model> T queryOne(Function<ResultSet, T> getInstance, String sql, Params params) {
        var key = cacheKey(sql, params);
        var cachedResult = getFromCache(key);
        if (cachedResult != null && !(cachedResult instanceof ArrayList<?>)) return castCachedValue(cachedResult);
        try (var stmt = convertToUnnamedParams(sql, params);
             var rs = stmt.executeQuery()) {
            T obj = null;
            if (rs.next()) {
                obj = getInstance.apply(rs);
                assert obj != null;
                obj.mapper(rs);
            }
            addToCache(key, obj);
            return obj;
        } catch (SQLException ex) {
            throw handleSqlError("queryOne", sql, params, ex);
        }
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée ne retourner qu'un seul enregistrement, et
     * retourne
     * l'objet métier correspondant à l'enregistrement trouvé, en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param getInstance retourne une nouvelle instance d'une classe du modèle en fonction de la valeur du
     *                    discriminateur
     * @param sql         la requête SQL de type {@code SELECT} ; il s'agit d'une requête sans paramètre
     * @param <T>         la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return une instance de la classe {@code T} ou d'une classe héritant de {@code T} contenant les données lues
     * en base données
     */
    public static <T extends Model> T queryOne(Function<ResultSet, T> getInstance, String sql) {
        return queryOne(getInstance, sql, new Params());
    }

    /**
     * Méthode abstraite permettant de rafraîchir les données de l'objet métier courant en les récupérant à nouveau
     * depuis la base de données. Cette méthode doit être surchangée dans les classes héritantes.
     */
    public abstract void reload();

    /**
     * Permet de rafraîchir les données d'un objet métier en les récupérant à nouveau depuis la base de données.
     *
     * @param sql    la requête SQL à effectuer
     * @param params les valeurs des éventuels paramètres pour la requête
     */
    public void reload(String sql, Params params) {
        clearCache();
        try (var stmt = convertToUnnamedParams(sql, params);
             var rs = stmt.executeQuery()) {
            if (rs.next()) {
                this.mapper(rs);
            }
        } catch (SQLException ex) {
            throw handleSqlError("reload", sql, params, ex);
        }
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée retourner zéro, un ou plusieurs enregistrements,
     * et retourne une liste contenant les objets métier correspondants aux enregistrements trouvés,
     * en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param type   le type d'objet à retourner
     * @param sql    la requête SQL de type {@code SELECT} ; les éventuels paramètres sont représentés par {@code :name}
     *               où {@code name} représente le nom du paramètre
     * @param params la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @param <T>    la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return liste d'instances de la classe {@code T} contenant les données lues en base données
     */
    public static <T extends Model> List<T> queryList(Class<T> type, String sql, Params params) {
        var key = cacheKey(sql, params);
        var cachedResult = getFromCache(key);
        if (cachedResult instanceof ArrayList<?>) return castCachedList(cachedResult);
        try (var stmt = convertToUnnamedParams(sql, params);
             var rs = stmt.executeQuery()) {
            List<T> list = new ArrayList<>();
            while (rs.next()) {
                T obj = newInstance(type, rs);
                assert obj != null;
                obj.mapper(rs);
                list.add(obj);
            }
            addToCache(key, list);
            return list;
        } catch (SQLException ex) {
            throw handleSqlError("queryList", sql, params, ex);
        }
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée retourner zéro, un ou plusieurs enregistrements,
     * et retourne une liste contenant les objets métier correspondants aux enregistrements trouvés,
     * en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param type le type d'objet à retourner
     * @param sql  la requête SQL de type {@code SELECT} ; il s'agit d'une requête sans paramètre
     * @param <T>  la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return liste d'instances de la classe {@code T} contenant les données lues en base données
     */
    public static <T extends Model> List<T> queryList(Class<T> type, String sql) {
        return queryList(type, sql, new Params());
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée retourner zéro, un ou plusieurs enregistrements,
     * et retourne une liste contenant les objets métier correspondants aux enregistrements trouvés,
     * en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param getInstance retourne une nouvelle instance d'une classe du modèle en fonction de la valeur du
     *                    discriminateur
     * @param sql         la requête SQL de type {@code SELECT} ; les éventuels paramètres sont représentés par
     *                    {@code :name}
     *                    où {@code name} représente le nom du paramètre
     * @param params      la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @param <T>         la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return liste d'instances de la classe {@code T} ou de classes héritant de {@code T} contenant les données
     * lues en base données
     */
    public static <T extends Model> List<T> queryList(Function<ResultSet, T> getInstance, String sql, Params params) {
        var key = cacheKey(sql, params);
        var cachedResult = getFromCache(key);
        if (cachedResult instanceof ArrayList<?>) return castCachedList(cachedResult);
        try (var stmt = convertToUnnamedParams(sql, params);
             var rs = stmt.executeQuery()) {
            List<T> list = new ArrayList<>();
            while (rs.next()) {
                T obj = getInstance.apply(rs);
                assert obj != null;
                obj.mapper(rs);
                list.add(obj);
            }
            addToCache(key, list);
            return list;
        } catch (SQLException ex) {
            throw handleSqlError("queryList", sql, params, ex);
        }
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée retourner zéro, un ou plusieurs enregistrements,
     * et retourne une liste contenant les objets métier correspondants aux enregistrements trouvés,
     * en faisant appel à {@link #mapper(ResultSet)}.
     *
     * @param getInstance retourne une nouvelle instance d'une classe du modèle en fonction de la valeur du
     *                    discriminateur
     * @param sql         la requête SQL de type {@code SELECT} ; il s'agit d'une requête sans paramètre
     * @param <T>         la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return liste d'instances de la classe {@code T} ou de classes héritant de {@code T} contenant les données
     * lues en base données
     */
    public static <T extends Model> List<T> queryList(Function<ResultSet, T> getInstance, String sql) {
        return queryList(getInstance, sql, new Params());
    }

    /**
     * Effectue une requête SQL de lecture en base de données et retourne un {@link QueryResult}
     * contenant le {@link ResultSet} et le {@link PreparedStatement} associé.
     * <p>
     * Exemple :
     * <pre>{@code
     * try (var query = Model.queryResultSet("SELECT ...", params)) {
     *     var rs = query.getResultSet();
     *     while (rs.next()) { ... }
     * }
     * }</pre>
     *
     * @param sql    la requête SQL de type {@code SELECT} ; les éventuels paramètres sont représentés par {@code :name}
     *               où {@code name} représente le nom du paramètre
     * @param params la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @return le résultat de la requête, à fermer avec try-with-resources
     */
    public static QueryResult queryResultSet(String sql, Params params) {
        try {
            var stmt = convertToUnnamedParams(sql, params);
            return new QueryResult(stmt, stmt.executeQuery());
        } catch (SQLException ex) {
            throw handleSqlError("queryResultSet", sql, params, ex);
        }
    }

    /**
     * Effectue une requête SQL d'écriture en base de données.
     *
     * @param sql    la requête SQL de type {@code INSERT}, {@code UPDATE} ou {@code DELETE} ;
     *               les éventuels paramètres sont représentés par {@code :name} où {@code name} représente le nom du
     *               paramètre
     * @param params la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @return le nombre d'enregistrements mis à jour en base de données
     */
    public static int execute(String sql, Params params) {
        try (var stmt = convertToUnnamedParams(sql, params)) {
            int count = stmt.executeUpdate();
            clearCache();
            return count;
        } catch (SQLException ex) {
            throw handleSqlError("execute", sql, params, ex);
        }
    }

    /**
     * Effectue une requête SQL de lecture en base de données, supposée ne retourner qu'une seule valeur scalaire et
     * retourne la valeur trouvée. Typiquement, cette méthode est utile pour effectuer une requête du type
     * {@code SELECT COUNT(*) FROM ...}.
     *
     * @param type   le type de valeur à retourner (typiquement Integer, String, Float, ...)
     * @param sql    la requête SQL de type {@code SELECT AGG(...) FROM ...} ; les éventuels paramètres sont représentés
     *               par {@code :name} où {@code name} représente le nom du paramètre
     * @param params la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @param <T>    la classe correspondant au type d'objet à retourner (doit hériter de {@link Model})
     * @return la valeur scalaire trouvée
     */
    public static <T> T queryScalar(Class<T> type, String sql, Params params) {
        try (var stmt = convertToUnnamedParams(sql, params);
             var rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getObject(1, type);
            }
            return null;
        } catch (SQLException ex) {
            throw handleSqlError("queryScalar", sql, params, ex);
        }
    }

    private static int getLastInsertId(Statement st) throws SQLException {
        try (ResultSet keys = st.getGeneratedKeys()) {
            if (keys.next())
                return keys.getInt(1);
            return 0;
        }
    }

    /**
     * Effectue une requête SQL de type INSERT et retourne la clé primaire entière générée par auto-incrémentation.
     *
     * @param sql    la requête SQL de type {@code INSERT} ; les éventuels paramètres sont représentés par {@code :name}
     *               où {@code name} représente le nom du paramètre
     * @param params la liste des valeurs pour les différents paramètres de la requête (voir {@link Params})
     * @return la valeur de la clé primaire auto-générée
     */
    public static int insert(String sql, Params params) {
        try (var stmt = convertToUnnamedParams(sql, params)) {
            stmt.executeUpdate();
            int key = getLastInsertId(stmt);
            clearCache();
            return key;
        } catch (SQLException ex) {
            throw handleSqlError("insert", sql, params, ex);
        }
    }

    private static PreparedStatement convertToUnnamedParams(String sql, Params params) throws SQLException {
        List<String> fields = new ArrayList<>();
        var caseInsensitiveParams = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        caseInsensitiveParams.putAll(params.getMap());
        Pattern findParametersPattern = Pattern.compile("(?<!')(:\\w+)(?!')");
        Matcher matcher = findParametersPattern.matcher(sql);
        while (matcher.find()) {
            String name = matcher.group().substring(1).toLowerCase();
            if (name.isBlank())
                throw new RuntimeException("Invalid named parameter in sql statement " + sql);
            if (!caseInsensitiveParams.containsKey(name))
                throw new RuntimeException("No value given for parameter '" + name + "' (received: " + caseInsensitiveParams + ")");
            fields.add(name);
        }
        PreparedStatement stmt = getDatabaseConnection().prepareStatement(sql.replaceAll(findParametersPattern.pattern(), "?"),
                Statement.RETURN_GENERATED_KEYS);
        for (int i = 0; i < fields.size(); ++i)
            stmt.setObject(i + 1, caseInsensitiveParams.get(fields.get(i)));
        return stmt;
    }
}
