package tgpr.framework.ui.component;

import com.googlecode.lanterna.Symbols;
import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TerminalTextUtils;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.Theme;
import com.googlecode.lanterna.gui2.*;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import tgpr.framework.ui.Ui;
import tgpr.framework.ui.layout.Constraints;
import tgpr.framework.ui.layout.GridPane;
import tgpr.framework.ui.layout.HBox;
import tgpr.framework.ui.layout.Insets;
import tgpr.framework.ui.layout.Pos;
import tgpr.framework.ui.layout.Spacing;
import tgpr.framework.ui.layout.VBox;

import java.awt.Toolkit;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Calendrier en popup (comme une liste ComboBox) : ancré à un champ, non modal.
 * <p>
 * Hints Lanterna : {@link Hint#MENU_POPUP}, {@link Hint#FIXED_POSITION} — même cadre
 * que le popup ComboBox (pas de {@link Hint#NO_DECORATIONS}). Pas de {@link Hint#NO_FOCUS} :
 * sinon, à la fermeture du ComboBox mois/année, Lanterna réactive la fenêtre parente.
 * Clic dehors → fermeture automatique.
 */
public class DatePicker extends BasicWindow {
    private static final Locale LOCALE = Locale.FRENCH;
    /**
     * Largeur d'une cellule calendrier ({@code CompactButton} jour / en-têtes abrégés).
     * Sans le minimum de 8 du {@link Button.DefaultButtonRenderer}.
     */
    private static final int CELL_WIDTH = 2;
    private static final int MONTH_COMBO_COLUMNS = 11;
    private static final int YEAR_COMBO_COLUMNS = 6;
    private static final int GRID_SPACING = 1;
    private static final int CALENDAR_COLUMNS = 7 * CELL_WIDTH + 6 * GRID_SPACING;
    /** Plage d’années par défaut si min/max absents (naissances + RDV futurs). */
    private static final int DEFAULT_YEAR_PAST = 120;
    private static final int DEFAULT_YEAR_FUTURE = 20;
    /** Glyphe « aujourd’hui » — cercle (Home). */
    private static final String TODAY_GLYPH = String.valueOf(Symbols.WHITE_CIRCLE);
    /**
     * Navigation mois : flèches Unicode ({@link Symbols#ARROW_LEFT} / {@link Symbols#ARROW_RIGHT}).
     * Les triangles ◀/▶ (U+25C0/U+25B6) manquent souvent en Consolas ([?]) ;
     * les pointers Lanterna ◄/► (U+25C4/U+25BA) s’affichent mais paraissent écrasés.
     */
    private static final String PREV_MONTH_GLYPH = String.valueOf(Symbols.ARROW_LEFT);
    private static final String NEXT_MONTH_GLYPH = String.valueOf(Symbols.ARROW_RIGHT);
    private static final DayOfWeek[] WEEK_DAYS = {
            DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY,
            DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY
    };

    private final ComboBox<MonthItem> cboMonth = Ui.sizeTo(new ComboBox<>(), MONTH_COMBO_COLUMNS);
    private final ComboBox<Integer> cboYear = Ui.sizeTo(new ComboBox<>(), YEAR_COMBO_COLUMNS);
    private final Label lblSelection = new Label("");
    private final Label lblError = new Label("").setForegroundColor(TextColor.ANSI.RED);
    private final LocalDate[] cellDates = new LocalDate[42];
    private GridPane calendar;

    private LocalDate displayedMonth;
    private LocalDate focusedDate;
    private LocalDate selectedDate;
    private LocalDate minDate;
    private LocalDate maxDate;
    private Function<LocalDate, String> customDateValidator;
    private Supplier<LocalDate> todaySupplier = LocalDate::now;
    private String lastValidationError;
    private boolean cancelled = true;
    private int lastClickedDayIndex = -1;
    private long lastClickTimeMs;

    private Component anchor;
    private Consumer<LocalDate> onPicked;
    private Runnable onDismissed;
    private boolean closing;

    public DatePicker() {
        super();
        // Cadre comme ComboBox.PopupWindow (pas de NO_DECORATIONS) ; sans NO_FOCUS
        setHints(List.of(Hint.FIXED_POSITION, Hint.MENU_POPUP));
        setCloseWindowWithEscape(true);

        LocalDate now = today();
        displayedMonth = now.withDayOfMonth(1);
        focusedDate = now;
        selectedDate = now;

        setComponent(buildUi());
        registerKeyboardNavigation();
        refresh();
    }

    /** @deprecated le titre n’est plus utilisé pour le popup ; conservé pour compat. */
    @Deprecated
    public DatePicker(String title) {
        this();
    }

    public DatePicker withInitialDate(LocalDate initialDate) {
        if (initialDate != null) {
            LocalDate target = findNearestSelectable(initialDate);
            if (target != null) {
                focusedDate = target;
                displayedMonth = target.withDayOfMonth(1);
                selectedDate = target;
            } else {
                focusedDate = initialDate;
                displayedMonth = initialDate.withDayOfMonth(1);
                selectedDate = null;
            }
        }
        refresh();
        return this;
    }

    public DatePicker withMinDate(LocalDate minDate) {
        this.minDate = minDate;
        refreshAfterRulesChanged();
        return this;
    }

    public DatePicker withMaxDate(LocalDate maxDate) {
        this.maxDate = maxDate;
        refreshAfterRulesChanged();
        return this;
    }

    public DatePicker withAllowedRange(LocalDate minDate, LocalDate maxDate) {
        this.minDate = minDate;
        this.maxDate = maxDate;
        refreshAfterRulesChanged();
        return this;
    }

    public DatePicker withCustomDateValidator(Function<LocalDate, String> customDateValidator) {
        this.customDateValidator = customDateValidator;
        refreshAfterRulesChanged();
        return this;
    }

    /**
     * Date de référence « aujourd’hui » (soulignement, bouton {@code *}, Home).
     * Si non définie / {@code null}, utilise {@link LocalDate#now()}.
     */
    public DatePicker withToday(LocalDate today) {
        this.todaySupplier = today != null ? () -> today : LocalDate::now;
        return this;
    }

    /**
     * Fournisseur de la date de référence « aujourd’hui » (ex. horloge simulée métier).
     * Si le supplier ou sa valeur est {@code null}, repli sur {@link LocalDate#now()}.
     */
    public DatePicker withToday(Supplier<LocalDate> today) {
        this.todaySupplier = today != null ? today : LocalDate::now;
        return this;
    }

    /** Date de référence courante (jamais {@code null}). */
    public LocalDate today() {
        LocalDate value = todaySupplier != null ? todaySupplier.get() : null;
        return value != null ? value : LocalDate.now();
    }

    public LocalDate getSelectedDate() {
        return cancelled ? null : selectedDate;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public String getLastValidationError() {
        return lastValidationError;
    }

    /** Composant d’ancrage (ex. {@link DateField}) — utilisé pour le toggle clic sur ▼. */
    public Component getAnchor() {
        return anchor;
    }

    /**
     * Affiche le calendrier en popup ancré à {@code anchor} (non bloquant).
     * Position : préférée sous le champ, alignée à droite ; bascule haut/bas et gauche/droite
     * selon l’espace terminal disponible.
     *
     * @param onPicked    appelé si une date est confirmée (double-clic / Entrée)
     * @param onDismissed appelé à toute fermeture (validation, Échap, clic dehors)
     */
    public void showAsPopup(Component anchor, Consumer<LocalDate> onPicked, Runnable onDismissed) {
        if (anchor == null) {
            throw new IllegalArgumentException("DatePicker: ancre requise");
        }
        if (!(anchor.getTextGUI() instanceof WindowBasedTextGUI windowGui)) {
            throw new IllegalStateException("DatePicker: WindowBasedTextGUI requis");
        }
        this.anchor = anchor;
        this.onPicked = onPicked;
        this.onDismissed = onDismissed;

        // Thème requis avant tout calcul de taille / rendu (sinon NPE dans AbstractComponent)
        setTheme(anchor.getTheme());

        TerminalSize contentSize = preferredPopupSize();
        setFixedSize(contentSize);
        Screen screen = windowGui.getScreen();
        TerminalSize decoratedSize = windowGui.getWindowManager()
                .getWindowDecorationRenderer(this)
                .getDecoratedSize(this, contentSize);
        setPosition(computePopupPosition(anchor, decoratedSize, screen.getTerminalSize()));

        windowGui.addWindow(this);
        windowGui.setActiveWindow(this);
    }

    @Override
    public synchronized Theme getTheme() {
        if (anchor != null) {
            Theme theme = anchor.getTheme();
            if (theme != null) {
                return theme;
            }
        }
        return super.getTheme();
    }

    @Override
    public void close() {
        if (closing) {
            super.close();
            return;
        }
        closing = true;
        try {
            super.close();
        } finally {
            Runnable dismissed = onDismissed;
            onDismissed = null;
            onPicked = null;
            anchor = null;
            if (dismissed != null) {
                dismissed.run();
            }
        }
    }

    /**
     * Taille du contenu (sans décoration). Préférer {@code getPreferredSize()} une fois le thème posé.
     */
    private TerminalSize preferredPopupSize() {
        try {
            Component root = getComponent();
            if (root != null && getTheme() != null) {
                return root.getPreferredSize();
            }
        } catch (RuntimeException ignored) {
            // garder l’estimation
        }
        // pad haut + nav + grille + sélection (pas de pad bas ni ligne d’erreur vide)
        return new TerminalSize(CALENDAR_COLUMNS + 2, 1 + 1 + 1 + 8 + 1 + 1);
    }

    /**
     * Préférence : sous le champ, bord droit aligné sur le bord droit de l’ancre.
     * Sinon dessus / aligné à gauche / clamp dans le terminal.
     */
    static TerminalPosition computePopupPosition(Component anchor, TerminalSize popupSize, TerminalSize screenSize) {
        TerminalPosition anchorPos = anchor.toGlobal(TerminalPosition.TOP_LEFT_CORNER);
        if (anchorPos == null) {
            return TerminalPosition.TOP_LEFT_CORNER;
        }
        TerminalSize anchorSize = anchor.getSize();
        if (anchorSize.getColumns() <= 0 || anchorSize.getRows() <= 0) {
            anchorSize = anchor.getPreferredSize();
        }

        int popupCols = popupSize.getColumns();
        int popupRows = popupSize.getRows();
        int screenCols = screenSize.getColumns();
        int screenRows = screenSize.getRows();

        int anchorLeft = anchorPos.getColumn();
        int anchorRight = anchorLeft + Math.max(1, anchorSize.getColumns());
        int anchorTop = anchorPos.getRow();
        int anchorBottom = anchorTop + Math.max(1, anchorSize.getRows());

        // Horizontal : préférer alignement à droite
        int rightAligned = anchorRight - popupCols;
        int leftAligned = anchorLeft;
        int col;
        if (rightAligned >= 0 && rightAligned + popupCols <= screenCols) {
            col = rightAligned;
        } else if (leftAligned + popupCols <= screenCols) {
            col = Math.max(0, leftAligned);
        } else {
            col = Math.max(0, screenCols - popupCols);
        }

        // Vertical : préférer en dessous
        int spaceBelow = screenRows - anchorBottom;
        int spaceAbove = anchorTop;
        int row;
        if (spaceBelow >= popupRows || spaceBelow >= spaceAbove) {
            row = anchorBottom;
            if (row + popupRows > screenRows) {
                row = Math.max(0, screenRows - popupRows);
            }
        } else {
            row = Math.max(0, anchorTop - popupRows);
        }

        return new TerminalPosition(col, row);
    }

    private Panel buildUi() {
        cboMonth.setReadOnly(true);
        cboYear.setReadOnly(true);
        for (Month month : Month.values()) {
            cboMonth.addItem(new MonthItem(month));
        }
        cboMonth.addListener((selected, previous, byUser) -> {
            if (byUser) {
                onNavChanged();
            }
        });
        cboYear.addListener((selected, previous, byUser) -> {
            if (byUser) {
                onNavChanged();
            }
        });

        var btnPrevMonth = CompactButton.plainGlyph(PREV_MONTH_GLYPH, () -> moveMonth(-1), false);
        var btnNextMonth = CompactButton.plainGlyph(NEXT_MONTH_GLYPH, () -> moveMonth(1), false);
        var btnToday = CompactButton.plainGlyph(TODAY_GLYPH, () -> focusDate(today()), false);
        var nav = HBox.create().childrenAlign(Pos.CENTER).add(
                btnPrevMonth,
                cboMonth,
                cboYear,
                btnNextMonth,
                btnToday
        ).alignInParent(Pos.CENTER);

        calendar = GridPane.create(7).spacing(Spacing.of(GRID_SPACING, 0));

        // spacing 0 entre sélection et erreur : sinon une ligne vide quand lblError a taille 0
        var status = VBox.create().spacing(0)
                .add(lblSelection, Pos.CENTER)
                .add(lblError, Pos.CENTER);

        return VBox.create()
                .spacing(1)
                .padding(Insets.of(1, 1, 1, 0))
                .add(nav, calendar)
                .add(status, Pos.CENTER);
    }

    private void onNavChanged() {
        MonthItem monthItem = cboMonth.getSelectedItem();
        Integer year = cboYear.getSelectedItem();
        if (monthItem == null || year == null) {
            return;
        }
        goToMonth(LocalDate.of(year, monthItem.month(), 1));
    }

    private void goToMonth(LocalDate monthStart) {
        displayedMonth = monthStart.withDayOfMonth(1);
        LocalDate target = firstSelectableInMonth(displayedMonth);
        if (target == null) {
            target = findNearestSelectable(displayedMonth);
        }
        if (target != null) {
            focusedDate = target;
            selectedDate = target;
            lastValidationError = null;
            lblError.setText("");
        }
        refresh();
    }

    private void registerKeyboardNavigation() {
        addWindowListener(new WindowListenerAdapter() {
            @Override
            public void onInput(Window basePane, KeyStroke keyStroke, AtomicBoolean deliverEvent) {
                if (keyStroke.getKeyType() == KeyType.PageUp) {
                    deliverEvent.set(false);
                    moveMonth(-1);
                } else if (keyStroke.getKeyType() == KeyType.PageDown) {
                    deliverEvent.set(false);
                    moveMonth(1);
                } else if (keyStroke.getKeyType() == KeyType.Home) {
                    deliverEvent.set(false);
                    focusDate(today());
                } else if (keyStroke.getKeyType() == KeyType.Enter) {
                    Interactable focused = getFocusedInteractable();
                    if (focused instanceof Button && isDayButton((Button) focused)) {
                        deliverEvent.set(false);
                        confirmSelection();
                    }
                }
            }
        });
    }

    private void refreshAfterRulesChanged() {
        if (selectedDate != null && !isDateSelectable(selectedDate)) {
            selectedDate = null;
        }
        LocalDate target = findNearestSelectable(focusedDate != null ? focusedDate : today());
        if (target != null) {
            focusedDate = target;
            displayedMonth = target.withDayOfMonth(1);
            if (selectedDate == null) {
                selectedDate = target;
            }
        }
        refresh();
    }

    private void moveMonth(int months) {
        goToMonth(displayedMonth.plusMonths(months));
    }

    private void applySelection(LocalDate date) {
        focusedDate = date;
        selectedDate = date;
        lastValidationError = null;
        lblError.setText("");
        lblError.setPreferredSize(TerminalSize.ZERO);
        lblSelection.setText(formatSelectedDate(date));
        lblSelection.setPreferredSize(null);
    }

    private void focusDate(LocalDate date) {
        LocalDate target = findNearestSelectable(clampToRange(date));
        if (target == null) {
            return;
        }
        focusedDate = target;
        displayedMonth = target.withDayOfMonth(1);
        selectedDate = target;
        lastValidationError = null;
        lblError.setText("");
        refresh();
    }

    private void onDayClicked(int index) {
        LocalDate date = cellDates[index];
        if (date == null || !isDateSelectable(date)) {
            return;
        }
        long now = System.currentTimeMillis();
        boolean doubleClick = index == lastClickedDayIndex
                && (now - lastClickTimeMs) <= doubleClickIntervalMs();
        lastClickedDayIndex = index;
        lastClickTimeMs = now;

        applySelection(date);
        if (doubleClick) {
            confirmSelection();
            return;
        }
        refresh();
    }

    private static int doubleClickIntervalMs() {
        Object value = Toolkit.getDefaultToolkit().getDesktopProperty("awt.multiClickInterval");
        return value instanceof Integer interval ? interval : 500;
    }

    private void confirmSelection() {
        LocalDate candidate = focusedDate;
        String error = validateDate(candidate);
        if (error != null) {
            selectedDate = null;
            lastValidationError = error;
            lblError.setText(error);
            refresh();
            return;
        }
        selectedDate = candidate;
        lastValidationError = null;
        cancelled = false;
        Consumer<LocalDate> picked = onPicked;
        onPicked = null;
        if (picked != null) {
            picked.accept(selectedDate);
        }
        close();
    }

    private void refresh() {
        syncNavCombos();
        lblSelection.setText(selectedDate == null ? "" : formatSelectedDate(selectedDate));

        boolean hasError = lastValidationError != null && !lastValidationError.isBlank();
        lblError.setText(hasError ? lastValidationError : "");
        lblError.setPreferredSize(hasError ? null : TerminalSize.ZERO);
        lblSelection.setPreferredSize(lblSelection.getText().isEmpty() ? TerminalSize.ZERO : null);

        LocalDate firstCellDate = displayedMonth
                .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));

        calendar.clear();
        for (DayOfWeek day : WEEK_DAYS) {
            addCalendarCell(weekdayHeader(day));
        }
        for (int i = 0; i < WEEK_DAYS.length; i++) {
            addCalendarCell(new EmptySpace(new TerminalSize(CELL_WIDTH, 1)));
        }

        for (int i = 0; i < cellDates.length; i++) {
            LocalDate date = firstCellDate.plusDays(i);
            boolean inDisplayedMonth = date.getMonth() == displayedMonth.getMonth()
                    && date.getYear() == displayedMonth.getYear();

            if (!inDisplayedMonth) {
                cellDates[i] = null;
                addCalendarCell(new EmptySpace(new TerminalSize(CELL_WIDTH, 1)));
                continue;
            }

            cellDates[i] = date;
            int dayOfMonth = date.getDayOfMonth();
            boolean isToday = date.equals(today());
            if (!isDateSelectable(date)) {
                addCalendarCell(inactiveDayLabel(dayOfMonth));
                continue;
            }

            final int index = i;
            final LocalDate buttonDate = date;
            var btn = new DayButton(dayButtonLabel(dayOfMonth), () -> onDayClicked(index), isToday) {
                @Override
                protected void afterEnterFocus(FocusChangeDirection direction, Interactable previouslyFocused) {
                    super.afterEnterFocus(direction, previouslyFocused);
                    applySelection(buttonDate);
                }
            };
            addCalendarCell(btn);
            if (date.equals(focusedDate)) {
                btn.takeFocus();
            }
        }
        invalidate();
    }

    private void syncNavCombos() {
        rebuildYearItems();
        int monthIndex = displayedMonth.getMonthValue() - 1;
        if (cboMonth.getSelectedIndex() != monthIndex) {
            cboMonth.setSelectedIndex(monthIndex);
        }
        Integer year = displayedMonth.getYear();
        if (!year.equals(cboYear.getSelectedItem())) {
            cboYear.setSelectedItem(year);
        }
    }

    private void rebuildYearItems() {
        int from = yearRangeStart();
        int to = yearRangeEnd();
        if (cboYear.getItemCount() == to - from + 1
                && cboYear.getItemCount() > 0
                && Integer.valueOf(from).equals(cboYear.getItem(0))
                && Integer.valueOf(to).equals(cboYear.getItem(cboYear.getItemCount() - 1))) {
            return;
        }
        Integer keep = displayedMonth != null ? displayedMonth.getYear() : null;
        cboYear.clearItems();
        for (int year = from; year <= to; year++) {
            cboYear.addItem(year);
        }
        if (keep != null && keep >= from && keep <= to) {
            cboYear.setSelectedItem(keep);
        } else if (cboYear.getItemCount() > 0) {
            cboYear.setSelectedIndex(0);
        }
    }

    private int yearRangeStart() {
        int now = today().getYear();
        if (minDate != null) {
            return minDate.getYear();
        }
        if (maxDate != null) {
            return Math.min(maxDate.getYear(), now) - DEFAULT_YEAR_PAST;
        }
        return now - DEFAULT_YEAR_PAST;
    }

    private int yearRangeEnd() {
        int now = today().getYear();
        int to;
        if (maxDate != null) {
            to = maxDate.getYear();
        } else if (minDate != null) {
            to = Math.max(minDate.getYear() + DEFAULT_YEAR_FUTURE, now + DEFAULT_YEAR_FUTURE);
        } else {
            to = now + DEFAULT_YEAR_FUTURE;
        }
        return Math.max(to, yearRangeStart());
    }

    private static boolean isDayButton(Button button) {
        return button instanceof DayButton;
    }

    private static class DayButton extends CompactButton {
        private final boolean today;

        DayButton(String label, Runnable action, boolean today) {
            super(label, action);
            this.today = today;
            setRenderer(new DayButtonRenderer());
        }

        boolean isToday() {
            return today;
        }

        @Override
        protected ButtonRenderer createDefaultRenderer() {
            return new DayButtonRenderer();
        }
    }

    /** Jours sélectionnables : noir sans BOLD ; aujourd’hui souligné. */
    private static final class DayButtonRenderer implements Button.ButtonRenderer {
        @Override
        public TerminalPosition getCursorLocation(Button button) {
            return null;
        }

        @Override
        public TerminalSize getPreferredSize(Button button) {
            return new TerminalSize(Math.max(1, TerminalTextUtils.getColumnWidth(button.getLabel())), 1);
        }

        @Override
        public void drawComponent(TextGUIGraphics graphics, Button button) {
            boolean today = button instanceof DayButton dayButton && dayButton.isToday();
            CompactButton.drawPlainGlyph(graphics, button, today);
        }
    }

    private record MonthItem(Month month) {
        @Override
        public String toString() {
            return capitalize(month.getDisplayName(TextStyle.FULL_STANDALONE, LOCALE));
        }
    }

    private void addCalendarCell(Component cell) {
        cell.setPreferredSize(new TerminalSize(CELL_WIDTH, 1));
        cell.setLayoutData(Constraints.grid(Pos.CENTER));
        calendar.addComponent(cell);
    }

    private static String dayButtonLabel(int dayOfMonth) {
        return String.format("%02d", dayOfMonth);
    }

    private static Label inactiveDayLabel(int dayOfMonth) {
        var label = new Label(padCenter(String.format("%02d", dayOfMonth), CELL_WIDTH));
        label.setForegroundColor(TextColor.ANSI.BLACK_BRIGHT);
        return label;
    }

    private static Label weekdayHeader(DayOfWeek day) {
        String caption = day.getDisplayName(TextStyle.SHORT_STANDALONE, LOCALE);
        if (caption.endsWith(".")) {
            caption = caption.substring(0, caption.length() - 1);
        }
        return new Label(padCenter(caption, CELL_WIDTH));
    }

    private LocalDate firstSelectableInMonth(LocalDate monthStart) {
        LocalDate cursor = monthStart;
        LocalDate end = monthStart.with(TemporalAdjusters.lastDayOfMonth());
        while (!cursor.isAfter(end)) {
            if (isDateSelectable(cursor)) {
                return cursor;
            }
            cursor = cursor.plusDays(1);
        }
        return null;
    }

    private LocalDate findNearestSelectable(LocalDate from) {
        if (from == null) {
            return null;
        }
        LocalDate base = clampToRange(from);
        if (isDateSelectable(base)) {
            return base;
        }
        for (int distance = 1; distance <= 400; distance++) {
            LocalDate after = clampToRange(base.plusDays(distance));
            if (isDateSelectable(after)) {
                return after;
            }
            LocalDate before = clampToRange(base.minusDays(distance));
            if (isDateSelectable(before)) {
                return before;
            }
        }
        return null;
    }

    private boolean isDateSelectable(LocalDate date) {
        return validateDate(date) == null;
    }

    private String validateDate(LocalDate date) {
        if (date == null) {
            return "Aucune date sélectionnée";
        }
        if (minDate != null && date.isBefore(minDate)) {
            return "Date antérieure au minimum autorisé (" + formatDate(minDate) + ")";
        }
        if (maxDate != null && date.isAfter(maxDate)) {
            return "Date postérieure au maximum autorisé (" + formatDate(maxDate) + ")";
        }
        if (customDateValidator != null) {
            String customError = customDateValidator.apply(date);
            if (customError != null && !customError.isBlank()) {
                return customError;
            }
        }
        return null;
    }

    private LocalDate clampToRange(LocalDate date) {
        if (date == null) {
            return today();
        }
        if (minDate != null && date.isBefore(minDate)) {
            return minDate;
        }
        if (maxDate != null && date.isAfter(maxDate)) {
            return maxDate;
        }
        return date;
    }

    private static String formatDate(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    private static String formatSelectedDate(LocalDate date) {
        String dayName = date.getDayOfWeek().getDisplayName(TextStyle.FULL, LOCALE);
        return capitalize(dayName) + " " + formatDate(date);
    }

    private static String padCenter(String value, int width) {
        if (value.length() >= width) {
            return value.substring(0, width);
        }
        int diff = width - value.length();
        int left = diff / 2;
        int right = diff - left;
        return " ".repeat(left) + value + " ".repeat(right);
    }

    private static String capitalize(String value) {
        if (value == null || value.isEmpty()) {
            return value;
        }
        return value.substring(0, 1).toUpperCase(LOCALE) + value.substring(1);
    }
}
