package tgpr.framework.ui.layout;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextCharacter;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.virtual.DefaultVirtualTerminal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Dump d'un écran : glyphes lisibles + calque de styles (couleurs / SGR).
 * <p>
 * Format fichier v1 :
 * <pre>
 * # tgpr-layout 1
 * # 80x30
 * === glyphs ===
 * ...
 * === palette ===
 * . BLACK/GRAY
 * 0 BLACK/BLACK+BOLD
 * 1 BLACK/BLUE
 * 2 WHITE/GRAY+BOLD
 * === style ===
 * ...
 * </pre>
 * Les sections palette/style sont omises s'il n'y a qu'un seul style.
 * Un fichier sans en-tête {@code # tgpr-layout} est un snapshot glyphes seul (compat).
 */
public final class LayoutCapture {
    public static final String FORMAT_HEADER = "# tgpr-layout 1";
    private static final String KEYS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    private final int columns;
    private final int rows;
    private final String glyphs;
    /** Grille 1 caractère / cellule, ou {@code null} si pas de calque (fichier legacy ou mono-style). */
    private final String styleGrid;
    private final Map<Character, String> palette;

    LayoutCapture(int columns, int rows, String glyphs, String styleGrid, Map<Character, String> palette) {
        this.columns = columns;
        this.rows = rows;
        this.glyphs = glyphs;
        this.styleGrid = styleGrid;
        this.palette = copyPalette(palette);
    }

    public int columns() {
        return columns;
    }

    public int rows() {
        return rows;
    }

    public String glyphs() {
        return glyphs;
    }

    public boolean hasStyleLayer() {
        return styleGrid != null;
    }

    public static LayoutCapture from(DefaultVirtualTerminal terminal, TerminalSize size) {
        int columns = size.getColumns();
        int rows = size.getRows();
        var glyphSb = new StringBuilder(rows * (columns + 1));
        var signatures = new String[rows][columns];
        var counts = new LinkedHashMap<String, Integer>();
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                var cell = terminal.getCharacter(col, row);
                glyphSb.append(cell.getCharacterString());
                var signature = signature(cell);
                signatures[row][col] = signature;
                counts.merge(signature, 1, Integer::sum);
            }
            glyphSb.append('\n');
        }
        var palette = assignPalette(counts);
        var styleSb = new StringBuilder(rows * (columns + 1));
        var inverse = invert(palette);
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                styleSb.append(inverse.get(signatures[row][col]));
            }
            styleSb.append('\n');
        }
        boolean multi = palette.size() > 1;
        return new LayoutCapture(
                columns, rows, glyphSb.toString(),
                multi ? styleSb.toString() : null,
                multi ? palette : Map.of());
    }

    public String serialize() {
        var sb = new StringBuilder();
        sb.append(FORMAT_HEADER).append('\n');
        sb.append("# ").append(columns).append('x').append(rows).append('\n');
        sb.append("=== glyphs ===\n");
        sb.append(glyphs);
        if (!glyphs.endsWith("\n")) {
            sb.append('\n');
        }
        if (hasStyleLayer()) {
            sb.append("=== palette ===\n");
            appendPalette(sb);
            sb.append("=== style ===\n");
            sb.append(styleGrid);
            if (!styleGrid.endsWith("\n")) {
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    public static LayoutCapture parse(String text) {
        text = normalize(text);
        if (!text.startsWith(FORMAT_HEADER)) {
            return parseLegacy(text);
        }
        var lines = text.split("\n", -1);
        int i = 1;
        if (i >= lines.length || !lines[i].startsWith("# ")) {
            throw new IllegalArgumentException("Missing size header in layout snapshot");
        }
        var size = parseSize(lines[i].substring(2).trim());
        i++;
        if (i >= lines.length || !lines[i].equals("=== glyphs ===")) {
            throw new IllegalArgumentException("Missing === glyphs === section");
        }
        i++;
        int glyphsStart = i;
        while (i < lines.length && !lines[i].startsWith("=== ")) {
            i++;
        }
        var glyphs = joinLines(lines, glyphsStart, i, size.rows);
        Map<Character, String> palette = new LinkedHashMap<>();
        String styleGrid = null;
        if (i < lines.length && lines[i].equals("=== palette ===")) {
            i++;
            while (i < lines.length && !lines[i].startsWith("=== ")) {
                var line = lines[i];
                if (!line.isEmpty()) {
                    if (line.length() < 3 || line.charAt(1) != ' ') {
                        throw new IllegalArgumentException("Bad palette line: " + line);
                    }
                    palette.put(line.charAt(0), line.substring(2));
                }
                i++;
            }
        }
        if (i < lines.length && lines[i].equals("=== style ===")) {
            i++;
            styleGrid = joinLines(lines, i, lines.length, size.rows);
        }
        if (styleGrid != null && palette.isEmpty()) {
            throw new IllegalArgumentException("Style section without palette");
        }
        if (styleGrid == null) {
            palette = Map.of();
        }
        return new LayoutCapture(size.columns, size.rows, glyphs, styleGrid, palette);
    }

    /**
     * {@code null} si identique. Glyphes d'abord, puis styles si le snapshot attendu a un calque.
     */
    public String diff(LayoutCapture actual) {
        if (!glyphs.equals(actual.glyphs)) {
            return LayoutRenderer.diff(glyphs, actual.glyphs);
        }
        if (!hasStyleLayer()) {
            return null;
        }
        if (!actual.hasStyleLayer()) {
            return "expected a style layer, actual snapshot has none";
        }
        var sb = new StringBuilder();
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                var exp = signatureAt(row, col);
                var act = actual.signatureAt(row, col);
                if (exp != null && !exp.equals(act)) {
                    sb.append(String.format("cell %d,%d  - %s%n", col, row, exp));
                    sb.append(String.format("cell %d,%d  + %s%n", col, row, act));
                }
            }
        }
        return sb.isEmpty() ? null : sb.toString();
    }

    public String signatureAt(int row, int col) {
        if (styleGrid == null) {
            return null;
        }
        var line = styleGrid.split("\n", -1);
        if (row < 0 || row >= line.length) {
            return null;
        }
        var cells = line[row];
        if (col < 0 || col >= cells.length()) {
            return null;
        }
        return palette.get(cells.charAt(col));
    }

    private static LayoutCapture parseLegacy(String text) {
        var lines = text.split("\n", -1);
        int rows = lines.length;
        if (rows > 0 && lines[rows - 1].isEmpty()) {
            rows--;
        }
        int columns = 0;
        for (int i = 0; i < rows; i++) {
            columns = Math.max(columns, lines[i].length());
        }
        return new LayoutCapture(columns, rows, text, null, Map.of());
    }

    private static Size parseSize(String spec) {
        var x = spec.indexOf('x');
        if (x <= 0) {
            throw new IllegalArgumentException("Bad size header: " + spec);
        }
        return new Size(Integer.parseInt(spec.substring(0, x)), Integer.parseInt(spec.substring(x + 1)));
    }

    /** `.` (majorité) puis `0`, `1`, `2`… dans l'ordre de {@link #KEYS}. */
    private void appendPalette(StringBuilder sb) {
        var remaining = new LinkedHashMap<>(palette);
        if (remaining.containsKey('.')) {
            sb.append(". ").append(remaining.remove('.')).append('\n');
        }
        for (int i = 0; i < KEYS.length(); i++) {
            char key = KEYS.charAt(i);
            var signature = remaining.remove(key);
            if (signature != null) {
                sb.append(key).append(' ').append(signature).append('\n');
            }
        }
        remaining.forEach((key, signature) -> sb.append(key).append(' ').append(signature).append('\n'));
    }

    private static Map<Character, String> copyPalette(Map<Character, String> palette) {
        if (palette == null || palette.isEmpty()) {
            return Map.of();
        }
        return Collections.unmodifiableMap(new LinkedHashMap<>(palette));
    }

    /** Reconstruit {@code rowCount} lignes (plus le {@code \n} final), en ignorant un éventuel segment vide terminal. */
    private static String joinLines(String[] lines, int from, int to, int rowCount) {
        var sb = new StringBuilder();
        int end = to;
        if (end > from && lines[end - 1].isEmpty()) {
            end--;
        }
        int count = Math.min(rowCount, end - from);
        for (int i = 0; i < count; i++) {
            sb.append(lines[from + i]).append('\n');
        }
        return sb.toString();
    }

    static String signature(TextCharacter cell) {
        var mods = cell.getModifiers();
        boolean bold = cell.isBold();
        var base = colorName(cell.getForegroundColor(), bold)
                + "/" + colorName(cell.getBackgroundColor(), false);
        if (mods == null || mods.isEmpty()) {
            return base;
        }
        var suffix = mods.stream().map(Enum::name).sorted().collect(Collectors.joining("+"));
        return base + "+" + suffix;
    }

    /**
     * Nom tel qu'affiché par l'émulateur Swing (palette VGA 16 couleurs) :
     * {@code ANSI.WHITE} = gris #AAAAAA, {@code WHITE_BRIGHT} = blanc ;
     * BOLD sur l'avant-plan active la variante {@code *_BRIGHT}.
     */
    static String colorName(TextColor color, boolean bold) {
        if (color instanceof TextColor.ANSI ansi) {
            return vgaDisplayName(ansi, bold);
        }
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private static String vgaDisplayName(TextColor.ANSI ansi, boolean bold) {
        var shown = ansi;
        if (bold && !ansi.isBright()
                && ansi != TextColor.ANSI.BLACK
                && ansi != TextColor.ANSI.DEFAULT) {
            try {
                shown = TextColor.ANSI.valueOf(ansi.name() + "_BRIGHT");
            } catch (IllegalArgumentException ignored) {
                // DEFAULT, etc.
            }
        }
        return switch (shown) {
            case WHITE -> "GRAY";
            case WHITE_BRIGHT -> "WHITE";
            case BLACK_BRIGHT -> "DARK_GRAY";
            default -> shown.name();
        };
    }

    public static String normalize(String text) {
        return text.replace("\r\n", "\n").replace("\r", "\n");
    }

    private static Map<Character, String> assignPalette(Map<String, Integer> counts) {
        var majority = counts.entrySet().stream()
                .max(Comparator.<Map.Entry<String, Integer>>comparingInt(Map.Entry::getValue)
                        .thenComparing(Map.Entry::getKey, Comparator.reverseOrder()))
                .orElseThrow()
                .getKey();
        var palette = new LinkedHashMap<Character, String>();
        palette.put('.', majority);
        var others = new ArrayList<>(counts.keySet());
        others.remove(majority);
        others.sort(String::compareTo);
        if (others.size() > KEYS.length()) {
            throw new IllegalStateException("Too many cell styles for snapshot palette: " + others.size());
        }
        for (int i = 0; i < others.size(); i++) {
            palette.put(KEYS.charAt(i), others.get(i));
        }
        return palette;
    }

    private static Map<String, Character> invert(Map<Character, String> palette) {
        var inverse = new LinkedHashMap<String, Character>();
        palette.forEach((key, signature) -> inverse.put(signature, key));
        return inverse;
    }

    private record Size(int columns, int rows) {
    }
}
