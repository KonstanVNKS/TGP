package tgpr.framework.mvc;

import java.sql.SQLException;

/**
 * Exception levée lorsqu'une opération SQL échoue.
 */
public class DatabaseException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public DatabaseException(String message, SQLException cause) {
        super(message, cause);
    }
}
