package tgpr.framework.ui.layout;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.LayoutData;
import com.googlecode.lanterna.gui2.Panel;

/**
 * Utilitaires pour ajouter des composants à un conteneur avec une API fluide.
 */
public final class NodeUtils {
    private NodeUtils() {
    }

    public static <T extends Component> T add(Panel parent, T node) {
        parent.addComponent(node);
        return node;
    }

    public static <T extends Component> T add(Panel parent, T node, LayoutData constraints) {
        node.setLayoutData(constraints);
        parent.addComponent(node);
        return node;
    }

    public static <T extends Component> T sizeTo(T component, int columns) {
        component.setPreferredSize(new TerminalSize(columns, 1));
        return component;
    }

    /**
     * Fixe la largeur préférée en conservant la hauteur calculée depuis le contenu.
     * Contrairement à {@link #sizeTo(Component, int)}, n’écrase pas la hauteur à 1.
     */
    public static <T extends Component> T sizeWidth(T component, int columns) {
        int rows = Math.max(1, component.getPreferredSize().getRows());
        component.setPreferredSize(new TerminalSize(columns, rows));
        return component;
    }

    public static <T extends Component> T sizeTo(T component, int columns, int rows) {
        component.setPreferredSize(new TerminalSize(columns, rows));
        return component;
    }
}
