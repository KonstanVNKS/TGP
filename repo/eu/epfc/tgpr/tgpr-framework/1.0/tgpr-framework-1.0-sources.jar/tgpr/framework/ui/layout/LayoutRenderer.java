package tgpr.framework.ui.layout;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.bundle.LanternaThemes;
import com.googlecode.lanterna.gui2.AbstractComponent;
import com.googlecode.lanterna.gui2.AbstractWindow;
import com.googlecode.lanterna.gui2.BasicWindow;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.DefaultWindowManager;
import com.googlecode.lanterna.gui2.EmptySpace;
import com.googlecode.lanterna.gui2.MultiWindowTextGUI;
import com.googlecode.lanterna.gui2.Window;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.virtual.DefaultVirtualTerminal;
import tgpr.framework.util.Configuration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Rendu headless d'un composant ou d'une fenêtre Lanterna (terminal virtuel).
 * <p>
 * L'écran a la taille de {@code terminal.width}×{@code terminal.height} ({@code config.properties}),
 * comme {@code ViewManager}. Les hints de la fenêtre ({@link Window.Hint#EXPANDED},
 * {@link Window.Hint#CENTERED}, {@link Window.Hint#FIXED_SIZE}) sont laissés à Lanterna :
 * on n'impose pas de {@code setFixedSize} sur une vue déjà construite.
 * {@link #capture} enveloppe le composant dans une fenêtre {@code CENTERED} ; une taille
 * explicite sert de zone de contenu (tests grow/fill), pas d'écran.
 */
public final class LayoutRenderer {
    private LayoutRenderer() {
    }

    /** Taille du terminal applicatif ({@code config.properties}). */
    public static TerminalSize appTerminalSize() {
        return new TerminalSize(
                Configuration.getInt("terminal.width", 80),
                Configuration.getInt("terminal.height", 30));
    }

    public static String render(Component content) throws IOException {
        return capture(content).glyphs();
    }

    public static String renderWindow(Window window) throws IOException {
        return captureWindow(window).glyphs();
    }

    public static String renderWindow(Window window, TerminalSize screenSize) throws IOException {
        return captureWindow(window, screenSize).glyphs();
    }

    public static String render(Component content, TerminalSize contentSize) throws IOException {
        return capture(content, contentSize).glyphs();
    }

    public static LayoutCapture capture(Component content) throws IOException {
        return captureCentered(content, null);
    }

    public static LayoutCapture captureWindow(Window window) throws IOException {
        return captureWindow(window, appTerminalSize());
    }

    /**
     * Rend {@code window} sur un écran de {@code screenSize} (défaut : {@link #appTerminalSize()}).
     * Ne modifie pas la taille de la fenêtre.
     */
    public static LayoutCapture captureWindow(Window window, TerminalSize screenSize) throws IOException {
        applyTheme(window);
        var terminal = new DefaultVirtualTerminal(screenSize);
        var screen = new TerminalScreen(terminal);
        screen.startScreen();
        try {
            var gui = createGui(screen);
            gui.addWindow(window);
            gui.updateScreen();
            return LayoutCapture.from(terminal, screenSize);
        } finally {
            screen.stopScreen();
        }
    }

    public static LayoutCapture capture(Component content, TerminalSize contentSize) throws IOException {
        return captureCentered(content, contentSize);
    }

    private static LayoutCapture captureCentered(Component content, TerminalSize contentSize) throws IOException {
        applyTheme(content);
        var window = new BasicWindow();
        window.setHints(List.of(Window.Hint.CENTERED));
        window.setComponent(content);
        if (contentSize != null) {
            window.setFixedSize(contentSize);
        }
        return captureWindow(window);
    }

    /** Même fond que {@code ViewManager} ({@code backgroundColor} dans {@code config.properties}). */
    private static MultiWindowTextGUI createGui(TerminalScreen screen) {
        var gui = new MultiWindowTextGUI(screen, new DefaultWindowManager(screen.getTerminalSize()),
                new EmptySpace(appBackgroundColor()));
        gui.setTheme(LanternaThemes.getDefaultTheme());
        return gui;
    }

    private static TextColor appBackgroundColor() {
        try {
            return TextColor.ANSI.valueOf(Configuration.get("backgroundColor", "BLUE"));
        } catch (IllegalArgumentException e) {
            return TextColor.ANSI.BLUE;
        }
    }

    public static void save(Path path, String content) throws IOException {
        Files.createDirectories(path.getParent());
        Files.writeString(path, content);
    }

    public static String diff(String a, String b) {
        var linesA = a.split("\n", -1);
        var linesB = b.split("\n", -1);
        var sb = new StringBuilder();
        int rows = Math.max(linesA.length, linesB.length);
        for (int i = 0; i < rows; i++) {
            var la = i < linesA.length ? linesA[i] : "";
            var lb = i < linesB.length ? linesB[i] : "";
            if (!la.equals(lb)) {
                sb.append(String.format("row %2d  - %s%n", i, la));
                sb.append(String.format("row %2d  + %s%n", i, lb));
            }
        }
        return sb.toString();
    }

    private static void applyTheme(Component component) {
        if (component instanceof AbstractComponent<?> abstractComponent) {
            abstractComponent.setTheme(LanternaThemes.getDefaultTheme());
        }
    }

    private static void applyTheme(Window window) {
        if (window instanceof AbstractWindow abstractWindow) {
            abstractWindow.setTheme(LanternaThemes.getDefaultTheme());
        }
    }
}
