package tgpr.framework.ui.layout;

/**
 * Insets (padding intérieur) sur les quatre côtés d'un conteneur.
 */
public class Insets {
    private final int left;
    private final int right;
    private final int top;
    private final int bottom;

    public Insets(int all) {
        this(all, all);
    }

    public Insets(int horizontal, int vertical) {
        this(horizontal, vertical, horizontal, vertical);
    }

    public Insets(int left, int top, int right, int bottom) {
        this.left = left;
        this.right = right;
        this.top = top;
        this.bottom = bottom;
    }

    public static Insets getDefault() {
        return Insets.of(1, 0);
    }

    public static Insets of(int all) {
        return new Insets(all);
    }

    public static Insets of(int horizontal, int vertical) {
        return new Insets(horizontal, vertical);
    }

    public static Insets of(int left, int top, int right, int bottom) {
        return new Insets(left, top, right, bottom);
    }

    public int getLeft() {
        return left;
    }

    public int getRight() {
        return right;
    }

    public int getTop() {
        return top;
    }

    public int getBottom() {
        return bottom;
    }
}
