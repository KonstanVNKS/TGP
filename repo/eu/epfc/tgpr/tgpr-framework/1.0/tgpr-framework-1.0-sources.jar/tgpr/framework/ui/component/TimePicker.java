package tgpr.framework.ui.component;

import com.googlecode.lanterna.Symbols;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.Theme;
import com.googlecode.lanterna.gui2.BasicWindow;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Label;
import com.googlecode.lanterna.gui2.Panel;
import com.googlecode.lanterna.gui2.Window;
import com.googlecode.lanterna.gui2.WindowBasedTextGUI;
import com.googlecode.lanterna.gui2.WindowListenerAdapter;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import tgpr.framework.ui.layout.HBox;
import tgpr.framework.ui.layout.Insets;
import tgpr.framework.ui.layout.Pos;
import tgpr.framework.ui.layout.VBox;

import java.awt.Toolkit;
import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import static tgpr.framework.util.Tools.asString;

/**
 * Sélecteur d’heure en popup ancré (comme {@link DatePicker}) : spinners heure / minutes
 * avec pas configurable (défaut 15 min).
 * <p>
 * Hints : {@link Hint#MENU_POPUP}, {@link Hint#FIXED_POSITION}. Entrée ou double-clic
 * sur l’heure, les minutes ou le libellé {@code HH:mm} en bas confirme ; Échap / clic dehors annule.
 * Home → heure de référence ({@link #now()}).
 */
public class TimePicker extends BasicWindow {

    public static final int DEFAULT_STEP_MINUTES = 15;

    private static final String PREV_GLYPH = String.valueOf(Symbols.ARROW_LEFT);
    private static final String NEXT_GLYPH = String.valueOf(Symbols.ARROW_RIGHT);
    private static final int PART_HOUR = 0;
    private static final int PART_MINUTE = 1;
    private static final int PART_SELECTION = 2;

    private CompactButton btnHour;
    private CompactButton btnMinute;
    private CompactButton btnSelection;
    private final Label lblError = new Label("").setForegroundColor(TextColor.ANSI.RED);

    private LocalTime focusedTime;
    private LocalTime selectedTime;
    private LocalTime minTime;
    private LocalTime maxTime;
    private int stepMinutes = DEFAULT_STEP_MINUTES;
    private Function<LocalTime, String> customTimeValidator;
    private Supplier<LocalTime> nowSupplier = LocalTime::now;
    private String lastValidationError;
    private boolean cancelled = true;
    private int lastClickedPart = -1;
    private long lastClickTimeMs;

    private Component anchor;
    private Consumer<LocalTime> onPicked;
    private Runnable onDismissed;
    private boolean closing;

    public TimePicker() {
        super();
        setHints(List.of(Hint.FIXED_POSITION, Hint.MENU_POPUP));
        setCloseWindowWithEscape(true);

        LocalTime now = now();
        focusedTime = snapToStep(now);
        selectedTime = focusedTime;

        setComponent(buildUi());
        registerKeyboardNavigation();
        refresh();
    }

    public TimePicker withInitialTime(LocalTime initialTime) {
        if (initialTime != null) {
            LocalTime target = findNearestSelectable(initialTime);
            if (target != null) {
                focusedTime = target;
                selectedTime = target;
            } else {
                focusedTime = snapToStep(initialTime);
                selectedTime = null;
            }
        }
        refresh();
        return this;
    }

    public TimePicker withStepMinutes(int stepMinutes) {
        if (stepMinutes < 1 || stepMinutes > 60 || 60 % stepMinutes != 0) {
            throw new IllegalArgumentException(
                    "TimePicker: stepMinutes doit diviser 60 (reçu " + stepMinutes + ")");
        }
        this.stepMinutes = stepMinutes;
        refreshAfterRulesChanged();
        return this;
    }

    public TimePicker withMinTime(LocalTime minTime) {
        this.minTime = minTime;
        refreshAfterRulesChanged();
        return this;
    }

    public TimePicker withMaxTime(LocalTime maxTime) {
        this.maxTime = maxTime;
        refreshAfterRulesChanged();
        return this;
    }

    public TimePicker withAllowedRange(LocalTime minTime, LocalTime maxTime) {
        this.minTime = minTime;
        this.maxTime = maxTime;
        refreshAfterRulesChanged();
        return this;
    }

    public TimePicker withCustomTimeValidator(Function<LocalTime, String> customTimeValidator) {
        this.customTimeValidator = customTimeValidator;
        refreshAfterRulesChanged();
        return this;
    }

    /** Heure de référence « maintenant » (Home, valeur initiale par défaut). */
    public TimePicker withNow(LocalTime now) {
        this.nowSupplier = now != null ? () -> now : LocalTime::now;
        return this;
    }

    public TimePicker withNow(Supplier<LocalTime> now) {
        this.nowSupplier = now != null ? now : LocalTime::now;
        return this;
    }

    public LocalTime now() {
        LocalTime value = nowSupplier != null ? nowSupplier.get() : null;
        return value != null ? value : LocalTime.now();
    }

    public LocalTime getSelectedTime() {
        return cancelled ? null : selectedTime;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public String getLastValidationError() {
        return lastValidationError;
    }

    public Component getAnchor() {
        return anchor;
    }

    /**
     * Affiche le picker en popup ancré à {@code anchor} (non bloquant).
     * Position : même logique que {@link DatePicker#computePopupPosition}.
     */
    public void showAsPopup(Component anchor, Consumer<LocalTime> onPicked, Runnable onDismissed) {
        if (anchor == null) {
            throw new IllegalArgumentException("TimePicker: ancre requise");
        }
        if (!(anchor.getTextGUI() instanceof WindowBasedTextGUI windowGui)) {
            throw new IllegalStateException("TimePicker: WindowBasedTextGUI requis");
        }
        this.anchor = anchor;
        this.onPicked = onPicked;
        this.onDismissed = onDismissed;

        setTheme(anchor.getTheme());

        TerminalSize contentSize = preferredPopupSize();
        setFixedSize(contentSize);
        Screen screen = windowGui.getScreen();
        TerminalSize decoratedSize = windowGui.getWindowManager()
                .getWindowDecorationRenderer(this)
                .getDecoratedSize(this, contentSize);
        setPosition(DatePicker.computePopupPosition(anchor, decoratedSize, screen.getTerminalSize()));

        windowGui.addWindow(this);
        windowGui.setActiveWindow(this);
        focusPart(PART_HOUR);
    }

    @Override
    public synchronized Theme getTheme() {
        if (anchor != null) {
            Theme theme = anchor.getTheme();
            if (theme != null) {
                return theme;
            }
        }
        return super.getTheme();
    }

    @Override
    public void close() {
        if (closing) {
            super.close();
            return;
        }
        closing = true;
        try {
            super.close();
        } finally {
            Runnable dismissed = onDismissed;
            onDismissed = null;
            onPicked = null;
            anchor = null;
            if (dismissed != null) {
                dismissed.run();
            }
        }
    }

    private TerminalSize preferredPopupSize() {
        try {
            Component root = getComponent();
            if (root != null && getTheme() != null) {
                return root.getPreferredSize();
            }
        } catch (RuntimeException ignored) {
            // estimation
        }
        return new TerminalSize(12, 6);
    }

    private Panel buildUi() {
        var btnPrevHour = CompactButton.plainGlyph(PREV_GLYPH, () -> {
            adjustHours(-1);
            focusPart(PART_HOUR);
        }, false);
        var btnNextHour = CompactButton.plainGlyph(NEXT_GLYPH, () -> {
            adjustHours(1);
            focusPart(PART_HOUR);
        }, false);
        var btnPrevMinute = CompactButton.plainGlyph(PREV_GLYPH, () -> {
            adjustMinutes(-1);
            focusPart(PART_MINUTE);
        }, false);
        var btnNextMinute = CompactButton.plainGlyph(NEXT_GLYPH, () -> {
            adjustMinutes(1);
            focusPart(PART_MINUTE);
        }, false);
        btnHour = CompactButton.plainGlyph("00", () -> onValueClicked(PART_HOUR), false);
        btnMinute = CompactButton.plainGlyph("00", () -> onValueClicked(PART_MINUTE), false);
        btnSelection = CompactButton.plainGlyph("00:00", () -> onValueClicked(PART_SELECTION), false);

        var hourRow = HBox.create().childrenAlign(Pos.CENTER).spacing(1).add(
                btnPrevHour, btnHour, btnNextHour
        );
        var minuteRow = HBox.create().childrenAlign(Pos.CENTER).spacing(1).add(
                btnPrevMinute, btnMinute, btnNextMinute
        );

        var status = VBox.create().spacing(0)
                .add(btnSelection, Pos.CENTER)
                .add(lblError, Pos.CENTER);

        return VBox.create()
                .spacing(1)
                .padding(Insets.of(1, 1, 1, 0))
                .childrenAlign(Pos.CENTER)
                .add(hourRow, minuteRow)
                .add(status, Pos.CENTER);
    }

    private void registerKeyboardNavigation() {
        addWindowListener(new WindowListenerAdapter() {
            @Override
            public void onInput(Window basePane, KeyStroke keyStroke, AtomicBoolean deliverEvent) {
                if (keyStroke.getKeyType() == KeyType.Home) {
                    deliverEvent.set(false);
                    focusTime(now());
                    focusPart(PART_HOUR);
                } else if (keyStroke.getKeyType() == KeyType.ArrowLeft) {
                    deliverEvent.set(false);
                    adjustMinutes(-1);
                    focusPart(PART_MINUTE);
                } else if (keyStroke.getKeyType() == KeyType.ArrowRight) {
                    deliverEvent.set(false);
                    adjustMinutes(1);
                    focusPart(PART_MINUTE);
                } else if (keyStroke.getKeyType() == KeyType.ArrowUp) {
                    deliverEvent.set(false);
                    adjustHours(1);
                    focusPart(PART_HOUR);
                } else if (keyStroke.getKeyType() == KeyType.ArrowDown) {
                    deliverEvent.set(false);
                    adjustHours(-1);
                    focusPart(PART_HOUR);
                } else if (keyStroke.getKeyType() == KeyType.Enter) {
                    deliverEvent.set(false);
                    confirmSelection();
                }
            }
        });
    }

    private void refreshAfterRulesChanged() {
        if (selectedTime != null && !isTimeSelectable(selectedTime)) {
            selectedTime = null;
        }
        LocalTime target = findNearestSelectable(focusedTime != null ? focusedTime : now());
        if (target != null) {
            focusedTime = target;
            if (selectedTime == null) {
                selectedTime = target;
            }
        }
        refresh();
    }

    private void adjustHours(int delta) {
        LocalTime base = focusedTime != null ? focusedTime : snapToStep(now());
        LocalTime candidate = base.plusHours(delta);
        focusTime(candidate);
    }

    private void adjustMinutes(int delta) {
        LocalTime base = focusedTime != null ? focusedTime : snapToStep(now());
        LocalTime candidate = base.plusMinutes((long) delta * stepMinutes);
        focusTime(candidate);
    }

    private void focusTime(LocalTime time) {
        LocalTime target = findNearestSelectable(clampToRange(snapToStep(time)));
        if (target == null) {
            return;
        }
        focusedTime = target;
        selectedTime = target;
        lastValidationError = null;
        lblError.setText("");
        refresh();
    }

    /** Simple clic : rien ; double-clic : valide et ferme. */
    private void onValueClicked(int part) {
        if (part != PART_SELECTION) {
            focusPart(part);
        }
        long now = System.currentTimeMillis();
        boolean doubleClick = part == lastClickedPart
                && (now - lastClickTimeMs) <= doubleClickIntervalMs();
        lastClickedPart = part;
        lastClickTimeMs = now;
        if (doubleClick) {
            confirmSelection();
        }
    }

    private static int doubleClickIntervalMs() {
        Object value = Toolkit.getDefaultToolkit().getDesktopProperty("awt.multiClickInterval");
        return value instanceof Integer interval ? interval : 500;
    }

    private void focusPart(int part) {
        CompactButton target = part == PART_HOUR ? btnHour : btnMinute;
        if (target != null) {
            target.takeFocus();
        }
    }

    private void confirmSelection() {
        LocalTime candidate = focusedTime;
        String error = validateTime(candidate);
        if (error != null) {
            selectedTime = null;
            lastValidationError = error;
            lblError.setText(error);
            refresh();
            return;
        }
        selectedTime = candidate;
        lastValidationError = null;
        cancelled = false;
        Consumer<LocalTime> picked = onPicked;
        onPicked = null;
        if (picked != null) {
            picked.accept(selectedTime);
        }
        close();
    }

    private void refresh() {
        LocalTime display = focusedTime != null ? focusedTime : snapToStep(now());
        if (btnHour != null) {
            btnHour.setLabel(String.format("%02d", display.getHour()));
        }
        if (btnMinute != null) {
            btnMinute.setLabel(String.format("%02d", display.getMinute()));
        }
        String selectionText = selectedTime == null ? "" : asString(selectedTime);
        if (btnSelection != null) {
            btnSelection.setLabel(selectionText.isEmpty() ? " " : selectionText);
            btnSelection.setEnabled(!selectionText.isEmpty());
            btnSelection.setPreferredSize(selectionText.isEmpty() ? TerminalSize.ZERO : null);
        }

        boolean hasError = lastValidationError != null && !lastValidationError.isBlank();
        lblError.setText(hasError ? lastValidationError : "");
        lblError.setPreferredSize(hasError ? null : TerminalSize.ZERO);
    }

    private LocalTime snapToStep(LocalTime time) {
        if (time == null) {
            return LocalTime.MIDNIGHT;
        }
        int total = time.getHour() * 60 + time.getMinute();
        int snapped = Math.round((float) total / stepMinutes) * stepMinutes;
        if (snapped >= 24 * 60) {
            snapped = 24 * 60 - stepMinutes;
        }
        if (snapped < 0) {
            snapped = 0;
        }
        return LocalTime.of(snapped / 60, snapped % 60);
    }

    private LocalTime clampToRange(LocalTime time) {
        if (time == null) {
            return null;
        }
        LocalTime result = time;
        if (minTime != null && result.isBefore(minTime)) {
            result = minTime;
        }
        if (maxTime != null && result.isAfter(maxTime)) {
            result = maxTime;
        }
        return snapToStep(result);
    }

    private boolean isTimeSelectable(LocalTime time) {
        return validateTime(time) == null;
    }

    private String validateTime(LocalTime time) {
        if (time == null) {
            return "heure requise";
        }
        int minute = time.getMinute();
        if (minute % stepMinutes != 0) {
            return "pas de " + stepMinutes + " min requis";
        }
        if (minTime != null && time.isBefore(minTime)) {
            return "avant " + asString(minTime);
        }
        if (maxTime != null && time.isAfter(maxTime)) {
            return "après " + asString(maxTime);
        }
        if (customTimeValidator != null) {
            String custom = customTimeValidator.apply(time);
            if (custom != null && !custom.isBlank()) {
                return custom;
            }
        }
        return null;
    }

    private LocalTime findNearestSelectable(LocalTime preferred) {
        if (preferred == null) {
            preferred = now();
        }
        LocalTime start = clampToRange(snapToStep(preferred));
        if (isTimeSelectable(start)) {
            return start;
        }
        // balayer ± autour du pas
        for (int i = 1; i <= (24 * 60) / stepMinutes; i++) {
            LocalTime after = start.plusMinutes((long) i * stepMinutes);
            if (isTimeSelectable(after)) {
                return after;
            }
            LocalTime before = start.minusMinutes((long) i * stepMinutes);
            if (isTimeSelectable(before)) {
                return before;
            }
        }
        return null;
    }
}
