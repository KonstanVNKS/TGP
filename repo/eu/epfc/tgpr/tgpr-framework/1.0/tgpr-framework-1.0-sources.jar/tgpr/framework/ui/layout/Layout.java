package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.Border;
import com.googlecode.lanterna.gui2.Borders;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Panel;

/**
 * Helpers de composition (bordures, etc.).
 */
public final class Layout {
    private Layout() {
    }

    public static Border bordered(String title, Component content) {
        var panel = content instanceof Panel p ? p : wrap(content);
        return panel.withBorder(Borders.singleLine(title));
    }

    private static Panel wrap(Component content) {
        var panel = new Panel();
        panel.addComponent(content);
        return panel;
    }
}
