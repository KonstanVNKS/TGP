package tgpr.framework.ui.component;

import com.googlecode.lanterna.Symbols;
import com.googlecode.lanterna.gui2.TextBox;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import tgpr.framework.ui.Ui;
import tgpr.framework.ui.layout.HBox;
import tgpr.framework.ui.layout.Pos;

import java.time.LocalDate;
import java.util.function.Function;
import java.util.function.Supplier;

import static tgpr.framework.util.Tools.asString;
import static tgpr.framework.util.Tools.isValidDate;
import static tgpr.framework.util.Tools.toDate;

/**
 * Champ date : {@link TextBox} éditable + {@link CompactButton} ({@code ▼}) qui ouvre un
 * {@link DatePicker} en popup ancré (comme un ComboBox).
 * <p>
 * Raccourci clavier sur le TextBox : {@code Alt+↓}.
 * API principale : {@link #getDate()} / {@link #setDate(LocalDate)} et
 * {@link #setDateChangeListener(DateChangeListener)}.
 */
public class DateField extends HBox {

    public static final String DEFAULT_OPEN_LABEL = String.valueOf(Symbols.TRIANGLE_DOWN_POINTING_BLACK);
    public static final int DEFAULT_COLUMNS = 11;

    /**
     * Notifié à chaque changement du champ.
     * {@code date} est la valeur parsée, ou {@code null} si le texte est vide ou invalide.
     */
    @FunctionalInterface
    public interface DateChangeListener {
        void onDateChanged(LocalDate date, boolean byUser);
    }

    private final TextBox textBox;
    private final CompactButton btnOpen;

    private LocalDate minDate;
    private LocalDate maxDate;
    private Function<LocalDate, String> customDateValidator;
    private Supplier<LocalDate> todaySupplier = LocalDate::now;
    private DatePicker openPicker;
    private DateChangeListener dateChangeListener;
    /** Évite le double signal : {@link TextBox#setText} fire déjà {@code byUser=false}. */
    private boolean suppressTextBoxListener;

    public DateField() {
        this(DEFAULT_COLUMNS);
    }

    public DateField(int columns) {
        spacing(0);
        childrenAlign(Pos.CENTER);

        textBox = Ui.sizeTo(new TextBox() {
            @Override
            public Result handleKeyStroke(KeyStroke keyStroke) {
                if (keyStroke.getKeyType() == KeyType.ArrowDown && keyStroke.isAltDown()) {
                    togglePicker();
                    return Result.HANDLED;
                }
                return super.handleKeyStroke(keyStroke);
            }
        }, Math.max(1, columns));

        textBox.setTextChangeListener((txt, byUser) -> {
            if (suppressTextBoxListener) {
                return;
            }
            fireDateChanged(byUser);
        });

        btnOpen = CompactButton.plainGlyph(DEFAULT_OPEN_LABEL, this::togglePicker);
        add(textBox, btnOpen);
    }

    /** @deprecated le picker n’affiche plus de titre (popup sans décoration). */
    @Deprecated
    public DateField withPickerTitle(String title) {
        return this;
    }

    public DateField withMinDate(LocalDate minDate) {
        this.minDate = minDate;
        return this;
    }

    public DateField withMaxDate(LocalDate maxDate) {
        this.maxDate = maxDate;
        return this;
    }

    public DateField withAllowedRange(LocalDate minDate, LocalDate maxDate) {
        this.minDate = minDate;
        this.maxDate = maxDate;
        return this;
    }

    public DateField withCustomDateValidator(Function<LocalDate, String> customDateValidator) {
        this.customDateValidator = customDateValidator;
        return this;
    }

    /**
     * Date de référence « aujourd’hui » passée au {@link DatePicker}.
     * Si non définie, utilise {@link LocalDate#now()}.
     */
    public DateField withToday(LocalDate today) {
        this.todaySupplier = today != null ? () -> today : LocalDate::now;
        return this;
    }

    /**
     * Fournisseur de « aujourd’hui » (ex. {@code () -> SystemTime.now().toLocalDate()}).
     */
    public DateField withToday(Supplier<LocalDate> today) {
        this.todaySupplier = today != null ? today : LocalDate::now;
        return this;
    }

    public LocalDate today() {
        LocalDate value = todaySupplier != null ? todaySupplier.get() : null;
        return value != null ? value : LocalDate.now();
    }

    public TextBox getTextBox() {
        return textBox;
    }

    public CompactButton getOpenButton() {
        return btnOpen;
    }

    /** Texte brut du champ (format {@code jj/mm/aaaa} attendu). */
    public String getText() {
        return textBox.getText();
    }

    /** Mise à jour programmatique du texte ({@code byUser == false}). */
    public void setText(String text) {
        applyText(text == null ? "" : text, false);
    }

    /**
     * Date courante, ou {@code null} si le champ est vide ou le texte n’est pas une date valide.
     */
    public LocalDate getDate() {
        return parseDate(textBox.getText());
    }

    /**
     * Affiche {@code date} au format {@code jj/mm/aaaa}, ou vide si {@code null}.
     * Notifie le listener avec {@code byUser == false}.
     */
    public void setDate(LocalDate date) {
        applyText(asString(date), false);
    }

    /**
     * Listener dédié : reçoit un {@link LocalDate} (ou {@code null} si vide / invalide)
     * et un flag {@code byUser} (saisie clavier ou choix dans le picker).
     */
    public void setDateChangeListener(DateChangeListener listener) {
        this.dateChangeListener = listener;
    }

    public void takeFocus() {
        textBox.takeFocus();
    }

    /** Active ou désactive le TextBox et le bouton d’ouverture. */
    public void setEnabled(boolean enabled) {
        textBox.setEnabled(enabled);
        btnOpen.setEnabled(enabled);
    }

    private static LocalDate parseDate(String text) {
        if (text == null || text.isBlank() || !isValidDate(text.trim())) {
            return null;
        }
        return toDate(text.trim());
    }

    private void applyText(String value, boolean byUser) {
        String previous = textBox.getText();
        if (value.equals(previous)) {
            return;
        }
        suppressTextBoxListener = true;
        try {
            textBox.setText(value);
        } finally {
            suppressTextBoxListener = false;
        }
        fireDateChanged(byUser);
    }

    private void fireDateChanged(boolean byUser) {
        DateChangeListener listener = dateChangeListener;
        if (listener != null) {
            listener.onDateChanged(getDate(), byUser);
        }
    }

    private void togglePicker() {
        if (openPicker != null) {
            openPicker.close();
            return;
        }
        openPicker();
    }

    private void openPicker() {
        LocalDate initial = getDate();
        if (initial == null) {
            initial = today();
        }

        var picker = new DatePicker()
                .withToday(todaySupplier)
                .withInitialDate(initial);
        if (minDate != null) {
            picker.withMinDate(minDate);
        }
        if (maxDate != null) {
            picker.withMaxDate(maxDate);
        }
        if (customDateValidator != null) {
            picker.withCustomDateValidator(customDateValidator);
        }

        openPicker = picker;
        picker.showAsPopup(this, date -> applyText(asString(date), true), () -> openPicker = null);
    }
}
