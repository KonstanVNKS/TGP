package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Panel;

public class FluentPanel extends Panel {
    /**
     * Aligne ce panneau dans son parent linéaire vertical ({@link VBox}) — équivalent à
     * {@link #alignInVBox(Pos)}. Pour un enfant d'un {@link HBox}, utiliser {@link #alignInHBox(Pos)}
     * ou {@link Box#add(Component, Pos)}.
     */
    public FluentPanel alignInParent(Pos pos) {
        return alignInVBox(pos);
    }

    /** Alignement dans un parent {@link VBox} (axe horizontal de {@link Pos}). */
    public FluentPanel alignInVBox(Pos pos) {
        setLayoutData(Constraints.inVBox(pos));
        return this;
    }

    /** Alignement dans un parent {@link HBox} (axe vertical de {@link Pos}). */
    public FluentPanel alignInHBox(Pos pos) {
        setLayoutData(Constraints.inHBox(pos));
        return this;
    }

    public FluentPanel fillInParent() {
        return fillInParent(Priority.NONE);
    }

    /**
     * Remplit l'axe secondaire du parent linéaire ; {@link Priority#GROW} étend aussi l'axe principal.
     */
    public FluentPanel fillInParent(Priority grow) {
        setLayoutData(Constraints.fillInParent(grow));
        return this;
    }

    public FluentPanel center() {
        return alignInParent(Pos.CENTER);
    }

    public FluentPanel fill() {
        return fillInParent();
    }

    /** Retire un enfant de ce conteneur. */
    public FluentPanel remove(Component child) {
        removeComponent(child);
        return this;
    }

    /** Retire tous les enfants de ce conteneur. */
    public FluentPanel clear() {
        removeAllComponents();
        return this;
    }
}
