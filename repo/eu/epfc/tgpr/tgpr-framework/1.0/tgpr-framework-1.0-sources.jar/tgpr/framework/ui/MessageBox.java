package tgpr.framework.ui;

import com.googlecode.lanterna.gui2.*;
import com.googlecode.lanterna.gui2.dialogs.DialogWindow;
import tgpr.framework.ui.layout.GridPane;
import tgpr.framework.ui.layout.HBox;
import tgpr.framework.ui.layout.Insets;
import tgpr.framework.ui.layout.Pos;

import java.util.List;

public class MessageBox extends DialogWindow {
    private String clickedButton = null;

    public String getClickedButton() {
        return clickedButton;
    }

    public MessageBox(String message, String title, String... buttons) {
        super(title);

        setHints(List.of(Hint.CENTERED));
        setCloseWindowWithEscape(true);

        var buttonsPanel = HBox.create();
        int i = 0;
        for (var button : buttons) {
            var btn = new Button(button, () -> close(button));
            buttonsPanel.add(btn);
            if (i == 0) {
                btn.takeFocus();
            }
            ++i;
        }

        setComponent(GridPane.create(1)
                .padding(Insets.of(1, 1, 1, 0))
                .addSequential(new Label(message), new EmptySpace(), buttonsPanel.alignInParent(Pos.CENTER)));
    }

    private void close(String button) {
        clickedButton = button;
        close();
    }
}
