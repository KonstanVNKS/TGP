package tgpr.framework.ui;

import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Interactable;
import com.googlecode.lanterna.gui2.Window;
import com.googlecode.lanterna.gui2.WindowListenerAdapter;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import tgpr.framework.ui.layout.NodeUtils;

import java.util.concurrent.atomic.AtomicBoolean;

public final class Ui {
    private Ui() {
    }

    public static void addShortcut(Window window, Interactable component, KeyStroke shortcutKeyStroke) {
        window.addWindowListener(new WindowListenerAdapter() {
            @Override
            public void onInput(Window basePane, KeyStroke keyStroke, AtomicBoolean deliverEvent) {
                if (keyStroke.equals(shortcutKeyStroke)) {
                    deliverEvent.set(false);
                    if (component.isVisible() && component.isEnabled()) {
                        component.takeFocus();
                        component.handleInput(new KeyStroke(KeyType.Enter));
                    }
                }
            }
        });
    }

    public static <T extends Component> T sizeTo(T component, int columns) {
        return NodeUtils.sizeTo(component, columns);
    }

    /** Largeur fixe, hauteur adaptée au contenu (voir {@link NodeUtils#sizeWidth}). */
    public static <T extends Component> T sizeWidth(T component, int columns) {
        return NodeUtils.sizeWidth(component, columns);
    }

    public static <T extends Component> T sizeTo(T component, int columns, int rows) {
        return NodeUtils.sizeTo(component, columns, rows);
    }
}
