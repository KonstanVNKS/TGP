package tgpr.framework.mvc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Résultat d'une requête SQL de lecture : {@link ResultSet} et {@link PreparedStatement} associé.
 * À utiliser avec try-with-resources pour fermer les ressources JDBC.
 */
public final class QueryResult implements AutoCloseable {
    private final PreparedStatement statement;
    private final ResultSet resultSet;

    public QueryResult(PreparedStatement statement, ResultSet resultSet) {
        this.statement = statement;
        this.resultSet = resultSet;
    }

    public ResultSet getResultSet() {
        return resultSet;
    }

    @Override
    public void close() throws SQLException {
        statement.close();
    }
}
