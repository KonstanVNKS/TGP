package tgpr.framework.ui.component;

import com.googlecode.lanterna.gui2.*;
import com.googlecode.lanterna.gui2.table.Table;
import com.googlecode.lanterna.input.KeyStroke;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * Table orientée objets : chaque ligne correspond à un objet de type {@code T}.
 * Clic / double-clic souris gérés par le framework ({@code ListMouseInterceptor} via {@code ViewManager}).
 */
public class ObjectTable<T> extends Table<String> {

    private final List<ColumnSpec<T>> columnSpecs;
    private final List<T> objects = new ArrayList<>();
    private KeyStrokeHandler keyStrokeHandler;

    @FunctionalInterface
    public interface KeyStrokeHandler {
        /**
         * @return {@code true} si la touche est traitée et ne doit pas être propagée à la table Lanterna
         */
        boolean handle(KeyStroke keyStroke);
    }

    @SafeVarargs
    @SuppressWarnings("varargs")
    public ObjectTable(ColumnSpec<T>... columns) {
        super(Arrays.stream(columns).map(ColumnSpec::formattedHeader).toArray(String[]::new));
        columnSpecs = List.of(columns);
    }

    public ObjectTable<T> setKeyStrokeHandler(KeyStrokeHandler handler) {
        keyStrokeHandler = handler;
        return this;
    }

    @Override
    public Result handleKeyStroke(KeyStroke keyStroke) {
        if (keyStrokeHandler != null && keyStrokeHandler.handle(keyStroke)) {
            return Result.HANDLED;
        }
        int row = getSelectedRow();
        var res = super.handleKeyStroke(keyStroke);
        if (listener != null && getSelectedRow() != row) {
            invalidate();
            listener.onSelectionChanged(row, getSelectedRow(), true);
        }
        return res;
    }

    public interface SelectionChangeListener {
        void onSelectionChanged(int oldRow, int newRow, boolean byUser);
    }

    protected SelectionChangeListener listener;

    public synchronized ObjectTable<T> setSelectionChangedListener(SelectionChangeListener listener) {
        this.listener = listener;
        return this;
    }

    private boolean busy = false;

    @Override
    public synchronized Table<String> setSelectedRow(int selectedRow) {
        int row = getSelectedRow();
        var res = super.setSelectedRow(selectedRow);
        if (!busy && listener != null && getSelectedRow() != row) {
            busy = true;
            listener.onSelectionChanged(row, getSelectedRow(), false);
            busy = false;
            invalidate();
        }
        return res;
    }

    public void clear() {
        getTableModel().clear();
        objects.clear();
    }

    private List<String> getValues(T obj) {
        var values = new ArrayList<String>();
        for (ColumnSpec<T> spec : columnSpecs) {
            var value = spec.computeValue(String.format(spec.getFormat(), spec.getGetter().apply(obj)));
            values.add(value);
        }
        return values;
    }

    public void add(T obj) {
        objects.add(obj);
        getTableModel().addRow(getValues(obj));
    }

    public void add(List<T> objects) {
        for (var obj : objects) {
            add(obj);
        }
    }

    @SafeVarargs
    public final void add(T... objects) {
        for (var obj : objects) {
            add(obj);
        }
    }

    public void insert(int index, T obj) {
        objects.add(index, obj);
        getTableModel().insertRow(index, getValues(obj));
    }

    public T getSelected() {
        int row = getSelectedRow();
        return row >= 0 && row < objects.size() ? objects.get(row) : null;
    }

    public void setSelected(T obj) {
        int row = objects.indexOf(obj);
        if (row >= 0) {
            setSelectedRow(row);
        }
    }

    public T getItem(int row) {
        if (row < 0 || row >= objects.size()) return null;
        return objects.get(row);
    }

    public void setItem(int row, T obj) {
        if (row < 0 || row >= objects.size()) return;
        objects.set(row, obj);
    }

    public void setItems(List<T> items) {
        clear();
        add(items);
    }

    public Stream<T> stream() {
        return objects.stream();
    }

    public ObjectTable<T> addTo(Panel panel) {
        panel.addComponent(this);
        return this;
    }

    @Override
    public synchronized ObjectTable<T> setSelectAction(Runnable selectAction) {
        super.setSelectAction(selectAction);
        return this;
    }

    public void refresh() {
        for (int index = 0; index < objects.size(); index++) {
            var values = getValues(objects.get(index));
            for (int i = 0; i < values.size(); ++i) {
                getTableModel().setCell(i, index, values.get(i));
            }
        }
        invalidate();
    }

    public List<T> getItems() {
        return objects;
    }

    public void remove(T selected) {
        int index = objects.indexOf(selected);
        if (index >= 0) {
            objects.remove(index);
            getTableModel().removeRow(index);
        }
    }
}
