package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.Direction;
import com.googlecode.lanterna.gui2.GridLayout;
import com.googlecode.lanterna.gui2.LinearLayout;

/**
 * Alignement d'un composant dans son conteneur, sur le modèle de {@code javafx.geometry.Pos}.
 */
public enum Pos {
    TOP_LEFT,
    TOP_CENTER,
    TOP_RIGHT,
    CENTER_LEFT,
    CENTER,
    CENTER_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_CENTER,
    BOTTOM_RIGHT;

    public LinearLayout.Alignment toLinearAlignment(Direction direction) {
        return switch (direction) {
            case VERTICAL -> toHorizontalLinearAlignment();
            case HORIZONTAL -> toVerticalLinearAlignment();
        };
    }

    public GridLayout.Alignment toHorizontalGridAlignment() {
        return switch (this) {
            case TOP_LEFT, CENTER_LEFT, BOTTOM_LEFT -> GridLayout.Alignment.BEGINNING;
            case TOP_CENTER, CENTER, BOTTOM_CENTER -> GridLayout.Alignment.CENTER;
            case TOP_RIGHT, CENTER_RIGHT, BOTTOM_RIGHT -> GridLayout.Alignment.END;
        };
    }

    public GridLayout.Alignment toVerticalGridAlignment() {
        return switch (this) {
            case TOP_LEFT, TOP_CENTER, TOP_RIGHT -> GridLayout.Alignment.BEGINNING;
            case CENTER_LEFT, CENTER, CENTER_RIGHT -> GridLayout.Alignment.CENTER;
            case BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT -> GridLayout.Alignment.END;
        };
    }

    private LinearLayout.Alignment toHorizontalLinearAlignment() {
        return switch (this) {
            case TOP_LEFT, CENTER_LEFT, BOTTOM_LEFT -> LinearLayout.Alignment.Beginning;
            case TOP_CENTER, CENTER, BOTTOM_CENTER -> LinearLayout.Alignment.Center;
            case TOP_RIGHT, CENTER_RIGHT, BOTTOM_RIGHT -> LinearLayout.Alignment.End;
        };
    }

    private LinearLayout.Alignment toVerticalLinearAlignment() {
        return switch (this) {
            case TOP_LEFT, TOP_CENTER, TOP_RIGHT -> LinearLayout.Alignment.Beginning;
            case CENTER_LEFT, CENTER, CENTER_RIGHT -> LinearLayout.Alignment.Center;
            case BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT -> LinearLayout.Alignment.End;
        };
    }
}
