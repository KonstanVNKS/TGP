package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.BorderLayout;
import com.googlecode.lanterna.gui2.Direction;
import com.googlecode.lanterna.gui2.GridLayout;
import com.googlecode.lanterna.gui2.LayoutData;
import com.googlecode.lanterna.gui2.LinearLayout;

/**
 * Fabrique de {@link LayoutData} Lanterna avec une API unifiée.
 */
public final class Constraints {
    private Constraints() {
    }

    /**
     * Alignement de ce composant dans un parent linéaire vertical ({@link VBox}) :
     * {@link Pos} est interprété sur l'axe horizontal (gauche / centre / droite).
     */
    public static LayoutData inVBox(Pos pos) {
        return linear(Direction.VERTICAL, pos);
    }

    /**
     * Alignement de ce composant dans un parent linéaire horizontal ({@link HBox}) :
     * {@link Pos} est interprété sur l'axe vertical (haut / centre / bas).
     */
    public static LayoutData inHBox(Pos pos) {
        return linear(Direction.HORIZONTAL, pos);
    }

    /**
     * Alias de {@link #inVBox(Pos)} — alignement dans un parent vertical (dialogues).
     *
     * @see #inVBox(Pos)
     * @see #inHBox(Pos)
     */
    public static LayoutData inParent(Pos pos) {
        return inVBox(pos);
    }

    /**
     * Le composant remplit l'axe secondaire de son parent linéaire
     * (pleine largeur dans un {@link VBox}, pleine hauteur dans un {@link HBox}).
     */
    public static LayoutData fillInParent() {
        return fillInParent(Priority.NONE);
    }

    /**
     * Remplit l'axe secondaire ({@link LinearLayout.Alignment#Fill}) et, si {@code grow} est
     * {@link Priority#GROW}, s'étend aussi sur l'axe principal.
     */
    public static LayoutData fillInParent(Priority grow) {
        return LinearLayout.createLayoutData(
                LinearLayout.Alignment.Fill,
                grow.toGrowPolicy());
    }

    public static LayoutData linear(Pos pos) {
        return linear(pos, Priority.NONE);
    }

    public static LayoutData linear(Pos pos, Priority grow) {
        return linear(Direction.VERTICAL, pos, grow);
    }

    public static LayoutData linear(Direction direction, Pos pos) {
        return linear(direction, pos, Priority.NONE);
    }

    public static LayoutData linear(Direction direction, Pos pos, Priority grow) {
        return linear(direction, pos, grow, false);
    }

    /**
     * Contrainte linéaire. {@code grow} agit sur l'axe principal du parent ;
     * si {@code fillCrossAxis} est vrai, l'alignement devient {@link LinearLayout.Alignment#Fill}
     * ( {@code pos} est ignoré ).
     */
    public static LayoutData linear(Direction direction, Pos pos, Priority grow, boolean fillCrossAxis) {
        return LinearLayout.createLayoutData(
                fillCrossAxis ? LinearLayout.Alignment.Fill : pos.toLinearAlignment(direction),
                grow.toGrowPolicy());
    }

    public static LayoutData grid(Pos pos) {
        return grid(pos, 1, 1, false, false);
    }

    public static LayoutData grid(Pos pos, int colSpan, int rowSpan) {
        return grid(pos, colSpan, rowSpan, false, false);
    }

    /**
     * Contrainte de grille. Si {@code hGrow} / {@code vGrow} est vrai, l'alignement Lanterna
     * correspondant devient {@link GridLayout.Alignment#FILL} : l'espace extra est alloué
     * <em>et</em> le composant l'occupe (sinon {@link Pos#CENTER} le laisse à sa taille préférée
     * au milieu d'une cellule vide — l'expansion est invisible).
     */
    public static LayoutData grid(Pos pos, int colSpan, int rowSpan, boolean hGrow, boolean vGrow) {
        return GridLayout.createLayoutData(
                hGrow ? GridLayout.Alignment.FILL : pos.toHorizontalGridAlignment(),
                vGrow ? GridLayout.Alignment.FILL : pos.toVerticalGridAlignment(),
                hGrow,
                vGrow,
                colSpan,
                rowSpan);
    }

    public static LayoutData gridGrow(int colSpan, int rowSpan) {
        return grid(Pos.CENTER, colSpan, rowSpan, true, true);
    }

    public static LayoutData border(BorderLayout.Location location) {
        return location;
    }
}
