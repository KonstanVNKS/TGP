package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Direction;
import com.googlecode.lanterna.gui2.LayoutData;

/**
 * Conteneur vertical, équivalent de {@code javafx.scene.layout.VBox}.
 * <p>
 * Par convention du framework, {@link #create()} part de {@code spacing(0)} : l'empilement vertical
 * laisse le contrôle de l'espacement à {@link #spacing(int)}, {@link #padding(Insets)} ou aux
 * factory methods ({@link #createCentered()}, {@link #createExpanded()}). À l'inverse,
 * {@link HBox#create()} applique déjà {@code spacing(1)}, car une rangée horizontale (boutons, …)
 * a presque toujours besoin d'un espace entre les éléments.
 */
public final class VBox extends Box {
    private VBox() {
    }

    /** Conteneur vertical sans espacement entre les enfants ({@code spacing(0)}). */
    public static VBox create() {
        return new VBox();
    }

    /**
     * Conteneur vertical avec enfants centrés horizontalement ({@code childrenAlign(CENTER)}).
     * Hérite de {@link #create()} : pas d'espacement vertical par défaut ; ajouter
     * {@link #spacing(int)} si besoin (ex. {@code spacing(1)} au ch. 12 pour {@code LoginView}).
     */
    public static VBox createCentered() {
        return create().childrenAlign(Pos.CENTER);
    }

    /** Fenêtre {@code Hint.EXPANDED} : espacement vertical de 1 entre les composants empilés. */
    public static VBox createExpanded() {
        return create().spacing(1);
    }

    public static VBox create(int spacing, Component... children) {
        return create().spacing(spacing).add(children);
    }

    @Override
    protected Direction direction() {
        return Direction.VERTICAL;
    }

    @Override
    protected Pos defaultChildrenAlign() {
        return Pos.TOP_LEFT;
    }

    public static void setVgrow(Component node, Priority priority) {
        setVgrow(node, priority, Pos.CENTER);
    }

    public static void setVgrow(Component node, Priority priority, Pos alignment) {
        setVgrow(node, priority, alignment, false);
    }

    public static void setVgrow(Component node, Priority priority, Pos alignment, boolean fillCross) {
        node.setLayoutData(Constraints.linear(Direction.VERTICAL, alignment, priority, fillCross));
    }

    /** Remplit l'axe horizontal du {@link VBox} et applique {@code priority} sur l'axe vertical. */
    public static void setVgrowFill(Component node, Priority priority) {
        setVgrow(node, priority, Pos.CENTER, true);
    }

    @Override
    public VBox spacing(int spacing) {
        return (VBox) super.spacing(spacing);
    }

    @Override
    public VBox padding(Insets insets) {
        return (VBox) super.padding(insets);
    }

    @Override
    public VBox childrenAlign(Pos alignment) {
        return (VBox) super.childrenAlign(alignment);
    }

    @Override
    public VBox childrenFill() {
        return (VBox) super.childrenFill();
    }

    @Override
    public VBox childrenFill(boolean on) {
        return (VBox) super.childrenFill(on);
    }

    @Override
    public VBox add(Component... children) {
        return (VBox) super.add(children);
    }

    @Override
    public VBox add(Component child, Pos childAlign) {
        return (VBox) super.add(child, childAlign);
    }

    @Override
    public VBox add(Component child, Pos childAlign, Priority grow) {
        return (VBox) super.add(child, childAlign, grow);
    }

    @Override
    public VBox add(Component child, Pos childAlign, Priority grow, boolean fillCrossAxis) {
        return (VBox) super.add(child, childAlign, grow, fillCrossAxis);
    }

    @Override
    public VBox addFill(Component child, Priority mainGrow) {
        return (VBox) super.addFill(child, mainGrow);
    }

    @Override
    public VBox add(Component child, LayoutData constraints) {
        return (VBox) super.add(child, constraints);
    }

    @Override
    public VBox remove(Component child) {
        return (VBox) super.remove(child);
    }

    @Override
    public VBox clear() {
        return (VBox) super.clear();
    }

    @Override
    public VBox alignInParent(Pos pos) {
        return (VBox) super.alignInParent(pos);
    }

    @Override
    public VBox alignInVBox(Pos pos) {
        return (VBox) super.alignInVBox(pos);
    }

    @Override
    public VBox alignInHBox(Pos pos) {
        return (VBox) super.alignInHBox(pos);
    }

    @Override
    public VBox fillInParent() {
        return (VBox) super.fillInParent();
    }

    @Override
    public VBox fillInParent(Priority grow) {
        return (VBox) super.fillInParent(grow);
    }
}
