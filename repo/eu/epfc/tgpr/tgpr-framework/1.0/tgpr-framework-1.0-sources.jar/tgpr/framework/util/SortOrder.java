package tgpr.framework.util;

public enum SortOrder {
    Ascending, Descending;

    public SortOrder reversed() {
        return this == Ascending ? Descending : Ascending;
    }
}
