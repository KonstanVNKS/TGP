package tgpr.framework.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class LocaleFormats {
    public static final DateTimeFormatter INPUT_DATE_FORMATTER = DateTimeFormatter.ofPattern("d/M/y");
    public static final DateTimeFormatter INPUT_DATETIME_FORMATTER = DateTimeFormatter.ofPattern("d/M/y H:m[:s]");
    /** Saisie souple heure ({@code 9:30} ou {@code 09:30}). */
    public static final DateTimeFormatter INPUT_TIME_FORMATTER = DateTimeFormatter.ofPattern("H:m");
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");
    public static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    /** Affichage liste RDV / créneau : jour abrégé + date courte + heure. */
    public static final DateTimeFormatter APPOINTMENT_LIST_DATETIME_FORMATTER =
            DateTimeFormatter.ofPattern("EEE dd/MM HH:mm", Locale.FRANCE);
    /** Affichage détail RDV : jour abrégé + date complète + heure. */
    public static final DateTimeFormatter APPOINTMENT_DATETIME_FORMATTER =
            DateTimeFormatter.ofPattern("EEE dd/MM/yyyy HH:mm", Locale.FRANCE);
    /** Affichage date de consultation (sans heure). */
    public static final DateTimeFormatter APPOINTMENT_DATE_FORMATTER =
            DateTimeFormatter.ofPattern("EEE dd/MM/yyyy", Locale.FRANCE);
    /** Jour de créneau en liste (sans heure). */
    public static final DateTimeFormatter APPOINTMENT_LIST_DATE_FORMATTER =
            DateTimeFormatter.ofPattern("EEE dd/MM", Locale.FRANCE);
    public static final DateTimeFormatter ISO_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter ISO_DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final NumberFormat NUMBER_FORMAT = NumberFormat.getInstance(Locale.FRANCE);
    public static final NumberFormat CURRENCY_FORMAT = NumberFormat.getCurrencyInstance(Locale.FRANCE);
    ;
    public static final NumberFormat INTEGER_FORMAT = NumberFormat.getIntegerInstance(Locale.FRANCE);

    static {
        DecimalFormatSymbols symbols = ((DecimalFormat) CURRENCY_FORMAT).getDecimalFormatSymbols();
        symbols.setMonetaryDecimalSeparator(',');
        symbols.setMonetaryGroupingSeparator(' ');
        symbols.setCurrencySymbol("€");
        ((DecimalFormat) CURRENCY_FORMAT).applyPattern("#,##0.00 ¤");
        ((DecimalFormat) CURRENCY_FORMAT).setDecimalFormatSymbols(symbols);

        symbols = ((DecimalFormat) NUMBER_FORMAT).getDecimalFormatSymbols();
        symbols.setDecimalSeparator(',');
        symbols.setGroupingSeparator(' ');
        ((DecimalFormat) NUMBER_FORMAT).setDecimalFormatSymbols(symbols);
    }
}
