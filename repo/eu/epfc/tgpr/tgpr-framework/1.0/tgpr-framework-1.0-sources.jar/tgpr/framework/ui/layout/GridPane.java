package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.EmptySpace;
import com.googlecode.lanterna.gui2.GridLayout;
import com.googlecode.lanterna.gui2.LayoutData;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * Grille avec placement explicite {@code (col, row)}, équivalent de {@code javafx.scene.layout.GridPane}.
 */
public class GridPane extends FluentPanel {
    private final int columns;
    private int maxRow;
    private final Map<Component, CellSpan> cellSpans = new IdentityHashMap<>();

    protected GridPane(int columns) {
        this.columns = columns;
        setLayoutManager(new GridLayout(columns));
    }

    public static GridPane create(int columns) {
        return new GridPane(columns);
    }

    /**
     * Grille séquentielle avec padding et espacements par défaut (équivalent de l'ancien {@code Panel.gridPanel(columns, ...)}).
     */
    public static GridPane panel(int columns, Component... children) {
        return panel(columns, Insets.getDefault(), Spacing.getDefault(), children);
    }

    public static GridPane panel(int columns, Insets padding, Component... children) {
        return panel(columns, padding, Spacing.getDefault(), children);
    }

    public static GridPane panel(int columns, Insets padding, Spacing spacing, Component... children) {
        return create(columns).padding(padding).spacing(spacing).addSequential(children);
    }

    /**
     * Réserve une cellule vide dans la grille (équivalent de l'ancien {@code panel.addEmpty()}).
     */
    public GridPane addEmpty() {
        addComponent(new EmptySpace());
        return this;
    }

    public GridPane spacing(Spacing spacing) {
        var layout = (GridLayout) getLayoutManager();
        layout.setHorizontalSpacing(spacing.getHorizontal());
        layout.setVerticalSpacing(spacing.getVertical());
        return this;
    }

    public GridPane padding(Insets insets) {
        var layout = (GridLayout) getLayoutManager();
        layout.setLeftMarginSize(insets.getLeft());
        layout.setRightMarginSize(insets.getRight());
        layout.setTopMarginSize(insets.getTop());
        layout.setBottomMarginSize(insets.getBottom());
        return this;
    }

    /**
     * Ajoute des composants dans l'ordre séquentiel attendu par {@link GridLayout} (comme l'ancien {@code Panel.gridPanel}).
     */
    public GridPane addSequential(Component... nodes) {
        for (var node : nodes) {
            addComponent(node);
        }
        return this;
    }

    public GridPane add(Component node, int col, int row) {
        return add(node, col, row, 1, 1);
    }

    public GridPane add(Component node, int col, int row, int colSpan, int rowSpan) {
        return add(node, col, row, colSpan, rowSpan, Pos.CENTER);
    }

    public GridPane add(Component node, int col, int row, int colSpan, int rowSpan, Pos pos) {
        return add(node, col, row, colSpan, rowSpan, pos, false, false);
    }

    public GridPane add(Component node, int col, int row, int colSpan, int rowSpan,
                        Pos pos, boolean hGrow, boolean vGrow) {
        if (col < 0 || row < 0 || col + colSpan > columns) {
            throw new IllegalArgumentException(
                    "Component at (" + col + ", " + row + ") with span (" + colSpan + ", " + rowSpan
                            + ") is out of bounds for a " + columns + "-column grid");
        }
        ensureSlot(col, row);
        node.setLayoutData(Constraints.grid(pos, colSpan, rowSpan, hGrow, vGrow));
        cellSpans.put(node, new CellSpan(colSpan, rowSpan));
        addComponent(node);
        maxRow = Math.max(maxRow, row + rowSpan);
        return this;
    }

    public static void setHgrow(Component node, Priority priority) {
        applyGrow(node, true, priority.canGrow());
    }

    public static void setVgrow(Component node, Priority priority) {
        applyGrow(node, false, priority.canGrow());
    }

    /**
     * Met à jour uniquement {@code hGrow} ou {@code vGrow} en conservant span, alignement et
     * grow de l'autre axe. Sans contrainte grille existante : {@code 1×1} / {@link Pos#CENTER}.
     */
    private static void applyGrow(Component node, boolean horizontal, boolean grow) {
        var current = GridConstraint.read(node.getLayoutData());
        boolean hGrow = horizontal ? grow : current.hGrow();
        boolean vGrow = horizontal ? current.vGrow() : grow;
        node.setLayoutData(GridLayout.createLayoutData(
                hGrow ? GridLayout.Alignment.FILL : current.hAlign(),
                vGrow ? GridLayout.Alignment.FILL : current.vAlign(),
                hGrow,
                vGrow,
                current.colSpan(),
                current.rowSpan()));
    }

    /**
     * Lecture du {@code GridLayoutData} package-private de Lanterna.
     */
    private record GridConstraint(
            GridLayout.Alignment hAlign,
            GridLayout.Alignment vAlign,
            boolean hGrow,
            boolean vGrow,
            int colSpan,
            int rowSpan) {

        static final GridConstraint DEFAULT = new GridConstraint(
                GridLayout.Alignment.CENTER, GridLayout.Alignment.CENTER, false, false, 1, 1);

        static GridConstraint read(LayoutData data) {
            if (data == null || !"GridLayoutData".equals(data.getClass().getSimpleName())) {
                return DEFAULT;
            }
            try {
                var type = data.getClass();
                return new GridConstraint(
                        (GridLayout.Alignment) field(type, "horizontalAlignment").get(data),
                        (GridLayout.Alignment) field(type, "verticalAlignment").get(data),
                        field(type, "grabExtraHorizontalSpace").getBoolean(data),
                        field(type, "grabExtraVerticalSpace").getBoolean(data),
                        field(type, "horizontalSpan").getInt(data),
                        field(type, "verticalSpan").getInt(data));
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Unable to read GridLayoutData", e);
            }
        }

        private static java.lang.reflect.Field field(Class<?> type, String name) throws NoSuchFieldException {
            var field = type.getDeclaredField(name);
            field.setAccessible(true);
            return field;
        }
    }

    /**
     * Insère des espaces vides jusqu'à ce que la prochaine case libre corresponde à {@code (col, row)}.
     * Lanterna place les composants séquentiellement (comme SWT GridLayout), pas via un index {@code row * cols + col}.
     */
    private void ensureSlot(int col, int row) {
        while (true) {
            int[] next = nextFreeCell(getChildrenList(), columns, cellSpans);
            if (next[0] == col && next[1] == row) {
                return;
            }
            var placeholder = new EmptySpace();
            cellSpans.put(placeholder, CellSpan.ONE);
            addComponent(placeholder);
        }
    }

    static int[] nextFreeCell(List<Component> components, int numberOfColumns,
                              Map<Component, CellSpan> cellSpans) {
        Queue<Component> toBePlaced = new LinkedList<>(components);
        List<int[]> hspans = new ArrayList<>();
        List<int[]> vspans = new ArrayList<>();
        int rowCount = 0;
        int rowsExtent = 1;

        while (rowCount < rowsExtent || !toBePlaced.isEmpty()) {
            int[] hspan = new int[numberOfColumns];
            int[] vspan = new int[numberOfColumns];

            for (int col = 0; col < numberOfColumns; col++) {
                if (col > 0 && hspan[col - 1] > 1) {
                    hspan[col] = hspan[col - 1] - 1;
                    vspan[col] = vspan[col - 1];
                } else if (rowCount > 0 && vspans.get(rowCount - 1)[col] > 1) {
                    hspan[col] = hspans.get(rowCount - 1)[col];
                    vspan[col] = vspans.get(rowCount - 1)[col] - 1;
                } else if (!toBePlaced.isEmpty()) {
                    Component component = toBePlaced.poll();
                    CellSpan span = cellSpans.getOrDefault(component, CellSpan.ONE);
                    hspan[col] = span.horizontalSpan();
                    vspan[col] = span.verticalSpan();
                    rowsExtent = Math.max(rowsExtent, rowCount + span.verticalSpan());
                } else {
                    return new int[]{col, rowCount};
                }
            }

            hspans.add(hspan);
            vspans.add(vspan);
            rowCount++;
        }

        return new int[]{0, rowCount};
    }

    public int getColumns() {
        return columns;
    }

    public int getMaxRow() {
        return maxRow;
    }

    @Override
    public GridPane alignInParent(Pos pos) {
        return (GridPane) super.alignInParent(pos);
    }

    @Override
    public GridPane alignInVBox(Pos pos) {
        return (GridPane) super.alignInVBox(pos);
    }

    @Override
    public GridPane alignInHBox(Pos pos) {
        return (GridPane) super.alignInHBox(pos);
    }

    @Override
    public GridPane fillInParent() {
        return (GridPane) super.fillInParent();
    }

    @Override
    public GridPane fillInParent(Priority grow) {
        return (GridPane) super.fillInParent(grow);
    }

    @Override
    public GridPane remove(Component child) {
        cellSpans.remove(child);
        super.removeComponent(child);
        return this;
    }

    @Override
    public GridPane clear() {
        cellSpans.clear();
        maxRow = 0;
        removeAllComponents();
        return this;
    }

    private record CellSpan(int horizontalSpan, int verticalSpan) {
        static final CellSpan ONE = new CellSpan(1, 1);
    }
}
