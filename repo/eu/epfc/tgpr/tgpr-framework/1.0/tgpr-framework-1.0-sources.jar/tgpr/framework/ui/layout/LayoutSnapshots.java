package tgpr.framework.ui.layout;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.gui2.Window;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Snapshots texte de layouts Lanterna (sans JUnit).
 * <p>
 * Fichiers sous {@code src/test/resources/layout-expected/<name>.txt} (format {@link LayoutCapture}).
 * Les anciens snapshots glyphes seuls restent acceptés.
 * Régénérer : {@code mvn test -DwriteLayoutSnapshots=true}.
 * Les ressources sont chargées via le classloader du thread (classpath de test).
 */
public final class LayoutSnapshots {
    public static final String DEFAULT_FOLDER = "layout-expected";
    public static final String WRITE_PROPERTY = "writeLayoutSnapshots";

    private LayoutSnapshots() {
    }

    public static boolean writeMode() {
        return "true".equals(System.getProperty(WRITE_PROPERTY));
    }

    public static String normalize(String text) {
        return LayoutCapture.normalize(text);
    }

    /** Taille du terminal applicatif ({@code config.properties}). */
    public static TerminalSize appTerminalSize() {
        return LayoutRenderer.appTerminalSize();
    }

    public static void assertWindow(String name, Window window) throws IOException {
        assertMatches(name, LayoutRenderer.captureWindow(window));
    }

    public static void assertWindow(String name, Window window, TerminalSize screenSize) throws IOException {
        assertMatches(name, LayoutRenderer.captureWindow(window, screenSize));
    }

    public static void assertMatches(String name, LayoutCapture actual) throws IOException {
        assertMatches(name, actual, DEFAULT_FOLDER);
    }

    public static void assertMatches(String name, LayoutCapture actual, String folder) throws IOException {
        if (writeMode()) {
            writeExpected(name, actual.serialize(), folder);
            return;
        }
        failIfDifferent(name, LayoutCapture.parse(loadExpected(name, folder)), actual);
    }

    public static void assertMatches(String name, String actual) throws IOException {
        assertMatches(name, actual, DEFAULT_FOLDER);
    }

    public static void assertMatches(String name, String actual, String folder) throws IOException {
        actual = normalize(actual);
        if (writeMode()) {
            writeExpected(name, actual, folder);
            return;
        }
        failIfDifferent(name, LayoutCapture.parse(loadExpected(name, folder)), LayoutCapture.parse(actual));
    }

    private static void failIfDifferent(String name, LayoutCapture expected, LayoutCapture actual) throws IOException {
        var diff = expected.diff(actual);
        if (diff != null) {
            var output = Path.of("target", "screen-comparison", name + "-actual.txt");
            LayoutRenderer.save(output, actual.hasStyleLayer() || expected.hasStyleLayer()
                    ? actual.serialize()
                    : actual.glyphs());
            LayoutRenderer.save(Path.of("target", "screen-comparison", name + "-diff.txt"), diff);
            throw new AssertionError(name + ": layout differs from expected (see " + output + ")\n" + diff);
        }
    }

    public static void writeExpected(String name, String render) throws IOException {
        writeExpected(name, render, DEFAULT_FOLDER);
    }

    public static void writeExpected(String name, String render, String folder) throws IOException {
        var file = Path.of("src/test/resources", folder, name + ".txt");
        Files.createDirectories(file.getParent());
        Files.writeString(file, normalize(render));
    }

    private static String loadExpected(String name, String folder) throws IOException {
        var resource = folder + "/" + name + ".txt";
        try (InputStream in = openResource(resource)) {
            if (in == null) {
                throw new AssertionError("Missing snapshot: src/test/resources/" + resource
                        + " — run with -D" + WRITE_PROPERTY + "=true");
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static InputStream openResource(String resource) {
        var cl = Thread.currentThread().getContextClassLoader();
        if (cl != null) {
            var in = cl.getResourceAsStream(resource);
            if (in != null) {
                return in;
            }
        }
        return LayoutSnapshots.class.getResourceAsStream("/" + resource);
    }
}
