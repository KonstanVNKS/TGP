package tgpr.framework.ui.layout;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Direction;
import com.googlecode.lanterna.gui2.LayoutManager;
import com.googlecode.lanterna.gui2.LinearLayout;

import java.util.List;

/**
 * {@link LinearLayout} avec padding intérieur, sur le modèle de {@link com.googlecode.lanterna.gui2.GridLayout}.
 */
final class InsetsLinearLayout implements LayoutManager {
    private final LinearLayout delegate;
    private int left;
    private int top;
    private int right;
    private int bottom;
    private boolean changed = true;

    InsetsLinearLayout(Direction direction, int spacing, Insets padding) {
        this.delegate = new LinearLayout(direction).setSpacing(spacing);
        applyPadding(padding);
    }

    void setSpacing(int spacing) {
        delegate.setSpacing(spacing);
        changed = true;
    }

    void setPadding(Insets padding) {
        applyPadding(padding);
        changed = true;
    }

    private void applyPadding(Insets padding) {
        left = padding.getLeft();
        top = padding.getTop();
        right = padding.getRight();
        bottom = padding.getBottom();
    }

    @Override
    public TerminalSize getPreferredSize(List<Component> components) {
        var inner = delegate.getPreferredSize(components);
        return inner.withRelative(left + right, top + bottom);
    }

    @Override
    public boolean hasChanged() {
        return changed || delegate.hasChanged();
    }

    @Override
    public void doLayout(TerminalSize area, List<Component> components) {
        if (area.getColumns() <= left + right || area.getRows() <= top + bottom) {
            changed = false;
            return;
        }
        var innerArea = area.withRelative(-left - right, -top - bottom);
        delegate.doLayout(innerArea, components);
        for (var component : components) {
            if (component.isVisible()) {
                component.setPosition(component.getPosition().withRelative(left, top));
            }
        }
        changed = false;
    }
}
