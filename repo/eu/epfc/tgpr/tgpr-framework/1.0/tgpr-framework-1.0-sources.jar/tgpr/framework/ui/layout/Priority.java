package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.LinearLayout;

/**
 * Priorité d'expansion d'un composant dans un parent linéaire ou une grille.
 * <p>
 * Inspiré de {@code javafx.scene.layout.Priority}, mais Lanterna ne distingue que deux
 * comportements : pas d'expansion ({@link #NONE}) ou expansion possible ({@link #GROW}).
 * Il n'existe pas d'équivalent à {@code Priority.SOMETIMES} de JavaFX.
 */
public enum Priority {
    /** Le composant conserve sa taille préférée. */
    NONE,
    /** Le composant peut occuper l'espace supplémentaire disponible. */
    GROW;

    public boolean canGrow() {
        return this == GROW;
    }

    public LinearLayout.GrowPolicy toGrowPolicy() {
        return canGrow() ? LinearLayout.GrowPolicy.CanGrow : LinearLayout.GrowPolicy.None;
    }
}
