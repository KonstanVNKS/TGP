package tgpr.framework.mvc;

import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.gui2.AbstractListBox;
import com.googlecode.lanterna.gui2.ActionListBox;
import com.googlecode.lanterna.gui2.ComboBox;
import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Container;
import com.googlecode.lanterna.gui2.Interactable;
import com.googlecode.lanterna.gui2.ScrollBar;
import com.googlecode.lanterna.gui2.Window;
import com.googlecode.lanterna.gui2.WindowBasedTextGUI;
import com.googlecode.lanterna.gui2.table.Table;
import com.googlecode.lanterna.gui2.table.TableModel;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.MouseAction;
import com.googlecode.lanterna.input.MouseActionType;
import tgpr.framework.ui.component.DatePicker;

import java.awt.Toolkit;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Interception souris framework :
 * <ul>
 *   <li>{@link Table} / {@link ActionListBox} : clic = sélection, double-clic = action</li>
 *   <li>{@link ActionListBox} dans popup ComboBox : un clic sélectionne et ferme</li>
 *   <li>{@link ComboBox} : clic = ouvrir / fermer le popup (toggle)</li>
 *   <li>{@link DatePicker} : clic sur l’ancre ({@link tgpr.framework.ui.component.DateField}) = fermer (toggle)</li>
 *   <li>scrollbars Table / ActionListBox : flèches, piste, molette (Table)</li>
 * </ul>
 * MenuBar : comportement Lanterna standard (pas de toggle custom).
 */
final class ListMouseInterceptor {
    private static Object lastTarget;
    private static int lastIndex = -1;
    private static long lastTimeMs;

    private ListMouseInterceptor() {
    }

    /**
     * Si le clic vise le ComboBox propriétaire du popup actif, ferme le popup.
     * L'événement est entièrement consommé par l'appelant — pas besoin de suppress
     * (sinon le clic suivant serait mangé et la combo ne se rouvrirait pas).
     *
     * @return {@code true} si le clic a été traité comme toggle-fermeture
     */
    static boolean tryToggleClosePopup(WindowBasedTextGUI textGui, MouseAction mouse) {
        Window prior = textGui.getActiveWindow();
        if (prior == null || !prior.getHints().contains(Window.Hint.MENU_POPUP)) {
            return false;
        }

        Component owner = null;
        if (prior instanceof DatePicker datePicker) {
            owner = datePicker.getAnchor();
        } else if (prior.getHints().contains(Window.Hint.NO_FOCUS)) {
            owner = findComboBoxOwningPopup(textGui, prior);
        }
        if (owner == null || !containsPoint(owner, mouse.getPosition())) {
            return false;
        }

        prior.close();
        Window ownerWindow = findWindowContaining(textGui, owner);
        if (ownerWindow != null) {
            textGui.setActiveWindow(ownerWindow);
        }
        return true;
    }

    /**
     * @return {@code true} si l'événement a été consommé (ne pas le livrer au composant Lanterna)
     */
    static boolean tryHandle(Interactable target, MouseAction mouse, AtomicBoolean deliverEvent) {
        if (target instanceof ComboBox<?> combo) {
            deliverEvent.set(false);
            handleComboBox(combo, mouse);
            return true;
        }
        if (target instanceof Table<?> table) {
            deliverEvent.set(false);
            handleTable(table, mouse);
            return true;
        }
        if (target instanceof ActionListBox list) {
            deliverEvent.set(false);
            handleActionList(list, mouse);
            return true;
        }
        return false;
    }

    private static void handleComboBox(ComboBox<?> combo, MouseAction mouse) {
        combo.takeFocus();
        Window popup = getPopupWindow(combo);
        if (popup != null) {
            popup.close();
            return;
        }
        invokeShowPopup(combo, mouse);
    }

    private static void handleTable(Table<?> table, MouseAction mouse) {
        table.takeFocus();
        if (tryHandleTableScrollbar(table, mouse)) {
            clearDoubleClick();
            return;
        }
        if (isTableHeaderClick(table, mouse)) {
            clearDoubleClick();
            return;
        }
        int row = getTableRowByMouse(table, mouse);
        int column = invokeInt(Table.class, table, "getColumnByMouseAction", mouse);
        boolean doubleClick = isDoubleClick(table, row);
        table.setSelectedRow(row);
        if (table.isCellSelection()) {
            table.setSelectedColumn(column);
        }
        table.invalidate();
        if (doubleClick) {
            clearDoubleClick();
            runTableSelectAction(table);
        }
    }

    /** Molette sur une {@link Table} (Lanterna ne la gère pas nativement). */
    static boolean tryHandleTableWheel(Table<?> table, MouseAction mouse) {
        MouseActionType type = mouse.getActionType();
        if (type != MouseActionType.SCROLL_UP && type != MouseActionType.SCROLL_DOWN) {
            return false;
        }
        table.takeFocus();
        int delta = type == MouseActionType.SCROLL_UP ? -1 : 1;
        if (!scrollTableVertical(table, delta)) {
            // Butée + momentum trackpad : vider le reste pour éviter un saut inverse
            ViewManager.clearWheelAccumulator();
        }
        return true;
    }

    private static boolean tryHandleTableScrollbar(Table<?> table, MouseAction mouse) {
        TerminalPosition global = table.getGlobalPosition();
        if (global == null) {
            return false;
        }
        TerminalSize size = table.getSize();
        int localCol = mouse.getPosition().getColumn() - global.getColumn();
        int localRow = mouse.getPosition().getRow() - global.getRow();
        if (localCol < 0 || localRow < 0 || localCol >= size.getColumns() || localRow >= size.getRows()) {
            return false;
        }

        // Géométrie = ScrollBar réellement dessiné (évite le décalage header / barre H)
        ScrollBar vBar = getTableScrollBar(table, "verticalScrollBar");
        ScrollBar hBar = getTableScrollBar(table, "horizontalScrollBar");
        int bodyOrigin = getTableBodyOriginRow(table);
        boolean hasV = tableNeedsVerticalScroll(table);
        boolean hasH = tableNeedsHorizontalScroll(table);

        int vBarCol = size.getColumns() - 1;
        int vBarTop = bodyOrigin;
        int vBarRows = hasV ? Math.max(0, size.getRows() - bodyOrigin - (hasH ? 1 : 0)) : 0;
        if (vBar != null && vBar.getSize().getRows() > 0) {
            vBarCol = vBar.getPosition().getColumn();
            vBarTop = bodyOrigin + vBar.getPosition().getRow();
            vBarRows = vBar.getSize().getRows();
        }

        // Uniquement si la barre H est réellement dessinée (évite d'avaler la dernière ligne de données)
        int hBarRows = (hasH && hBar != null && hBar.getSize().getRows() > 0)
                ? hBar.getSize().getRows()
                : 0;

        if (hasV && vBarRows > 0 && localCol == vBarCol) {
            int localInBar = localRow - vBarTop;
            if (localInBar >= 0 && localInBar < vBarRows) {
                int maximum = vBar != null && vBar.getScrollMaximum() > 0
                        ? vBar.getScrollMaximum()
                        : table.getTableModel().getRowCount();
                int viewSize = vBar != null && vBar.getViewSize() > 0
                        ? vBar.getViewSize()
                        : Math.max(1, table.getRenderer().getVisibleRowsOnLastDraw());
                int position = vBar != null ? vBar.getScrollPosition() : table.getRenderer().getViewTopRow();
                int delta = scrollDeltaForHit(
                        hitScrollbar(localInBar, vBarRows, maximum, viewSize, position),
                        viewSize);
                if (delta != 0) {
                    scrollTableVertical(table, delta);
                }
                return true;
            }
        }

        if (hasH && hBarRows > 0 && localRow >= size.getRows() - hBarRows) {
            int hBarCols = size.getColumns() - (hasV ? 1 : 0);
            int hBarLeft = 0;
            if (hBar != null && hBar.getSize().getColumns() > 0) {
                hBarLeft = hBar.getPosition().getColumn();
                hBarCols = hBar.getSize().getColumns();
            }
            int localInBar = localCol - hBarLeft;
            if (localInBar >= 0 && localInBar < hBarCols) {
                int maximum = hBar != null && hBar.getScrollMaximum() > 0
                        ? hBar.getScrollMaximum()
                        : table.getTableModel().getColumnCount();
                int viewSize = hBar != null && hBar.getViewSize() > 0
                        ? hBar.getViewSize()
                        : Math.max(1, estimateVisibleColumns(table));
                int position = hBar != null ? hBar.getScrollPosition() : table.getRenderer().getViewLeftColumn();
                int delta = scrollDeltaForHit(
                        hitScrollbar(localInBar, hBarCols, maximum, viewSize, position),
                        viewSize);
                if (delta != 0) {
                    scrollTableHorizontal(table, delta);
                }
                return true;
            }
        }
        return false;
    }

    /** Origine Y du corps table (= hauteur header + bordure), alignée sur DefaultTableRenderer. */
    private static int getTableBodyOriginRow(Table<?> table) {
        try {
            Object renderer = table.getRenderer();
            Field headerField = renderer.getClass().getDeclaredField("headerSizeInRows");
            headerField.setAccessible(true);
            int headerRows = headerField.getInt(renderer);
            Field borderField = renderer.getClass().getDeclaredField("headerVerticalBorderStyle");
            borderField.setAccessible(true);
            Object borderStyle = borderField.get(renderer);
            Method getSize = borderStyle.getClass().getMethod("getSize");
            int borderRows = ((Number) getSize.invoke(borderStyle)).intValue();
            return Math.max(0, headerRows + borderRows);
        } catch (ReflectiveOperationException e) {
            return tableHeaderHeight(table);
        }
    }

    private static ScrollBar getTableScrollBar(Table<?> table, String fieldName) {
        try {
            Field field = table.getRenderer().getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(table.getRenderer());
            return value instanceof ScrollBar scrollBar ? scrollBar : null;
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    private static boolean tableNeedsVerticalScroll(Table<?> table) {
        if (table.getRenderer().isScrollBarsHidden()) {
            return false;
        }
        int visible = table.getRenderer().getVisibleRowsOnLastDraw();
        int rows = table.getTableModel().getRowCount();
        return visible > 0 && visible < rows;
    }

    private static boolean tableNeedsHorizontalScroll(Table<?> table) {
        if (table.getRenderer().isScrollBarsHidden()) {
            return false;
        }
        if (table.getRenderer().getViewLeftColumn() > 0) {
            return true;
        }
        int configured = table.getVisibleColumns();
        if (configured > 0) {
            return configured < table.getTableModel().getColumnCount();
        }
        // visibleColumns == 0 : Lanterna affiche autant de colonnes que possible.
        // Ne pas utiliser preferredSize > size (faux positif : réserve scrollbar V +
        // espace entre colonnes) — sinon la dernière ligne de données est mangée.
        ScrollBar hBar = getTableScrollBar(table, "horizontalScrollBar");
        return hBar != null
                && hBar.getSize().getRows() > 0
                && hBar.getViewSize() > 0
                && hBar.getScrollMaximum() > hBar.getViewSize();
    }

    private static int estimateVisibleColumns(Table<?> table) {
        int configured = table.getVisibleColumns();
        if (configured > 0) {
            return configured;
        }
        int remaining = table.getTableModel().getColumnCount() - table.getRenderer().getViewLeftColumn();
        return Math.max(1, remaining);
    }

    /**
     * Scroll vertical Table. Le {@code delta} s'applique d'abord au viewport
     * (flèche = ±1, piste = ±page) ; la sélection suit pour rester visible.
     *
     * @return {@code false} si déjà en butée (aucun déplacement)
     */
    private static boolean scrollTableVertical(Table<?> table, int delta) {
        int rowCount = table.getTableModel().getRowCount();
        if (rowCount <= 0 || delta == 0) {
            return false;
        }
        var renderer = table.getRenderer();
        int visible = Math.max(1, renderer.getVisibleRowsOnLastDraw());
        int maxTop = Math.max(0, rowCount - visible);
        int sel = table.getSelectedRow();
        int top = renderer.getViewTopRow();

        int newTop = clamp(top + delta, 0, maxTop);
        int newSel = clamp(sel + delta, 0, rowCount - 1);
        // La sélection doit rester dans la fenêtre (sinon Lanterna recentre / annule le scroll)
        if (newSel < newTop) {
            newSel = newTop;
        } else if (newSel > newTop + visible - 1) {
            newSel = Math.min(rowCount - 1, newTop + visible - 1);
        }

        if (newTop == top && newSel == sel) {
            return false;
        }
        renderer.setViewTopRow(newTop);
        table.setSelectedRow(newSel);
        table.invalidate();
        return true;
    }

    private static void scrollTableHorizontal(Table<?> table, int delta) {
        var renderer = table.getRenderer();
        int colCount = table.getTableModel().getColumnCount();
        if (colCount <= 0 || delta == 0) {
            return;
        }
        int visible = Math.max(1, estimateVisibleColumns(table));
        int maxLeft = Math.max(0, colCount - visible);
        int left = renderer.getViewLeftColumn();
        int newLeft = clamp(left + delta, 0, maxLeft);
        renderer.setViewLeftColumn(newLeft);
        if (table.isCellSelection()) {
            int col = table.getSelectedColumn();
            int newCol = clamp(col + delta, 0, colCount - 1);
            if (newCol < newLeft) {
                newCol = newLeft;
            } else if (newCol > newLeft + visible - 1) {
                newCol = Math.min(colCount - 1, newLeft + visible - 1);
            }
            table.setSelectedColumn(newCol);
        }
        table.invalidate();
    }

    private enum ScrollHit {
        NONE, ARROW_MIN, ARROW_MAX, TRACK_BEFORE, TRACK_AFTER
    }

    /**
     * Géométrie alignée sur {@code ScrollBar.DefaultScrollBarRenderer}.
     * Flèches = extrémités ; le reste (piste + curseur) = page avant/après selon le curseur.
     */
    private static ScrollHit hitScrollbar(int local, int barLength, int maximum, int viewSize, int position) {
        if (barLength <= 0 || maximum <= 0) {
            return ScrollHit.NONE;
        }
        if (barLength == 1) {
            return ScrollHit.TRACK_AFTER;
        }
        if (barLength == 2) {
            return local <= 0 ? ScrollHit.ARROW_MIN : ScrollHit.ARROW_MAX;
        }
        if (local <= 0) {
            return ScrollHit.ARROW_MIN;
        }
        if (local >= barLength - 1) {
            return ScrollHit.ARROW_MAX;
        }
        // Piste / curseur : page haut si au-dessus du milieu du curseur, sinon page bas
        int scrollableArea = barLength - 2;
        float viewRatio = clampRatio((float) viewSize / (float) maximum);
        int trackerSize = Math.max(1, (int) (viewRatio * scrollableArea));
        int maxPos = Math.max(1, maximum - viewSize);
        float posRatio = clampRatio((float) position / (float) maxPos);
        int trackerPos = (int) (posRatio * (float) (scrollableArea - trackerSize)) + 1;
        int trackerMid = trackerPos + trackerSize / 2;
        return local < trackerMid ? ScrollHit.TRACK_BEFORE : ScrollHit.TRACK_AFTER;
    }

    /** Flèche = ±1 ligne ; piste (hors flèches) = ±1 page. */
    private static int scrollDeltaForHit(ScrollHit hit, int page) {
        int pageSize = Math.max(1, page);
        return switch (hit) {
            case ARROW_MIN -> -1;
            case ARROW_MAX -> 1;
            case TRACK_BEFORE -> -pageSize;
            case TRACK_AFTER -> pageSize;
            default -> 0;
        };
    }

    private static float clampRatio(float value) {
        if (value < 0f) {
            return 0f;
        }
        if (value > 1f) {
            return 1f;
        }
        return value;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    /**
     * Mapping clic → index modèle en tenant compte des cellules multi-lignes ({@code \n} / Wrap).
     * Lanterna {@code getRowByMouseAction} suppose 1 ligne écran = 1 ligne modèle.
     */
    private static int getTableRowByMouse(Table<?> table, MouseAction mouse) {
        TerminalPosition global = table.getGlobalPosition();
        if (global == null) {
            return invokeInt(Table.class, table, "getRowByMouseAction", mouse);
        }
        int y = mouse.getPosition().getRow() - global.getRow() - tableHeaderHeight(table);
        if (y < 0) {
            return table.getFirstViewedRowIndex();
        }
        int first = table.getFirstViewedRowIndex();
        int last = table.getLastViewedRowIndex();
        if (last < first) {
            return Math.max(0, table.getTableModel().getRowCount() - 1);
        }
        int offset = 0;
        for (int row = first; row <= last; row++) {
            int height = tableRowHeight(table, row);
            if (y < offset + height) {
                return row;
            }
            offset += height;
        }
        return last;
    }

    private static boolean isTableHeaderClick(Table<?> table, MouseAction mouse) {
        TerminalPosition global = table.getGlobalPosition();
        if (global == null) {
            return false;
        }
        return mouse.getPosition().getRow() - global.getRow() < tableHeaderHeight(table);
    }

    private static int tableHeaderHeight(Table<?> table) {
        TableModel<?> model = table.getTableModel();
        int max = 1;
        for (int c = 0; c < model.getColumnCount(); c++) {
            max = Math.max(max, lineCount(model.getColumnLabel(c)));
        }
        return max;
    }

    private static int tableRowHeight(Table<?> table, int row) {
        TableModel<?> model = table.getTableModel();
        int max = 1;
        for (int c = 0; c < model.getColumnCount(); c++) {
            max = Math.max(max, lineCount(model.getCell(c, row)));
        }
        return max;
    }

    private static int lineCount(Object cell) {
        if (cell == null) {
            return 1;
        }
        String text = cell.toString();
        if (text.isEmpty()) {
            return 1;
        }
        int lines = 1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                lines++;
            }
        }
        return lines;
    }

    private static void handleActionList(ActionListBox list, MouseAction mouse) {
        list.takeFocus();
        if (tryHandleListScrollbar(list, mouse)) {
            clearDoubleClick();
            return;
        }
        int index = invokeInt(AbstractListBox.class, list, "getIndexByMouseAction", mouse);
        list.setSelectedIndex(index);
        if (isComboBoxDropDown(list)) {
            clearDoubleClick();
            list.runSelectedItem();
            return;
        }
        boolean doubleClick = isDoubleClick(list, index);
        if (doubleClick) {
            clearDoubleClick();
            list.runSelectedItem();
        }
    }

    private static boolean tryHandleListScrollbar(ActionListBox list, MouseAction mouse) {
        if (isComboBoxDropDown(list)) {
            return false;
        }
        TerminalPosition global = list.getGlobalPosition();
        TerminalSize size = list.getSize();
        if (global == null || size.getRows() <= 0) {
            return false;
        }
        int itemCount = list.getItemCount();
        if (itemCount <= size.getRows()) {
            return false;
        }
        int localCol = mouse.getPosition().getColumn() - global.getColumn();
        int localRow = mouse.getPosition().getRow() - global.getRow();
        if (localCol != size.getColumns() - 1 || localRow < 0 || localRow >= size.getRows()) {
            return false;
        }
        int viewSize = size.getRows();
        int maxTop = itemCount - viewSize;
        int scrollTop = getListScrollTop(list, maxTop);
        int delta = scrollDeltaForHit(
                hitScrollbar(localRow, size.getRows(), itemCount, viewSize, scrollTop),
                viewSize);
        if (delta == 0) {
            return true;
        }
        int newTop = clamp(scrollTop + delta, 0, maxTop);
        int newSel = clamp(list.getSelectedIndex() + delta, 0, itemCount - 1);
        if (newSel < newTop) {
            newSel = newTop;
        } else if (newSel > newTop + viewSize - 1) {
            newSel = newTop + viewSize - 1;
        }
        if (newTop == scrollTop && newSel == list.getSelectedIndex()) {
            return true;
        }
        setListScrollTop(list, newTop);
        list.setSelectedIndex(newSel);
        list.invalidate();
        return true;
    }

    private static int getListScrollTop(ActionListBox list, int maxTop) {
        try {
            Field field = list.getRenderer().getClass().getDeclaredField("scrollTopIndex");
            field.setAccessible(true);
            return clamp(field.getInt(list.getRenderer()), 0, maxTop);
        } catch (ReflectiveOperationException e) {
            return clamp(list.getSelectedIndex(), 0, maxTop);
        }
    }

    private static void setListScrollTop(ActionListBox list, int scrollTop) {
        try {
            Field field = list.getRenderer().getClass().getDeclaredField("scrollTopIndex");
            field.setAccessible(true);
            field.setInt(list.getRenderer(), scrollTop);
        } catch (ReflectiveOperationException ignored) {
            // setSelectedIndex recentrera au prochain dessin
        }
    }

    private static boolean isComboBoxDropDown(ActionListBox list) {
        var pane = list.getBasePane();
        return pane instanceof Window window && window.getHints().contains(Window.Hint.MENU_POPUP);
    }

    private static boolean isDoubleClick(Object target, int index) {
        long now = System.currentTimeMillis();
        boolean doubleClick = target == lastTarget && index == lastIndex && (now - lastTimeMs) <= doubleClickIntervalMs();
        lastTarget = target;
        lastIndex = index;
        lastTimeMs = now;
        return doubleClick;
    }

    private static void clearDoubleClick() {
        lastTarget = null;
        lastIndex = -1;
        lastTimeMs = 0;
    }

    private static int doubleClickIntervalMs() {
        Object value = Toolkit.getDefaultToolkit().getDesktopProperty("awt.multiClickInterval");
        return value instanceof Integer interval ? interval : 500;
    }

    private static void runTableSelectAction(Table<?> table) {
        try {
            Field field = Table.class.getDeclaredField("selectAction");
            field.setAccessible(true);
            Object action = field.get(table);
            if (action instanceof Runnable runnable) {
                runnable.run();
            }
        } catch (ReflectiveOperationException ignored) {
        }
    }

    private static Window getPopupWindow(ComboBox<?> combo) {
        try {
            Field field = ComboBox.class.getDeclaredField("popupWindow");
            field.setAccessible(true);
            Object value = field.get(combo);
            return value instanceof Window window ? window : null;
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    private static void invokeShowPopup(ComboBox<?> combo, MouseAction mouse) {
        try {
            Method method = ComboBox.class.getDeclaredMethod("showPopup", KeyStroke.class);
            method.setAccessible(true);
            method.invoke(combo, mouse);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Impossible d'ouvrir le popup ComboBox", e);
        }
    }

    private static ComboBox<?> findComboBoxOwningPopup(WindowBasedTextGUI textGui, Window popup) {
        for (Window window : textGui.getWindows()) {
            ComboBox<?> found = findComboBoxOwningPopup(window.getComponent(), popup);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    private static ComboBox<?> findComboBoxOwningPopup(Component root, Window popup) {
        if (root == null) {
            return null;
        }
        if (root instanceof ComboBox<?> combo && getPopupWindow(combo) == popup) {
            return combo;
        }
        if (root instanceof Container container) {
            for (Component child : container.getChildrenList()) {
                ComboBox<?> found = findComboBoxOwningPopup(child, popup);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    private static Window findWindowContaining(WindowBasedTextGUI textGui, Component component) {
        for (Window window : textGui.getWindows()) {
            if (containsComponent(window.getComponent(), component)) {
                return window;
            }
        }
        return null;
    }

    private static boolean containsComponent(Component root, Component target) {
        if (root == null) {
            return false;
        }
        if (root == target) {
            return true;
        }
        if (root instanceof Container container) {
            for (Component child : container.getChildrenList()) {
                if (containsComponent(child, target)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean containsPoint(Component component, TerminalPosition global) {
        TerminalPosition topLeft = component.toGlobal(TerminalPosition.TOP_LEFT_CORNER);
        if (topLeft == null) {
            return false;
        }
        TerminalSize size = component.getSize();
        if (size.getColumns() <= 0 || size.getRows() <= 0) {
            size = component.getPreferredSize();
        }
        return global.getColumn() >= topLeft.getColumn()
                && global.getColumn() < topLeft.getColumn() + Math.max(1, size.getColumns())
                && global.getRow() >= topLeft.getRow()
                && global.getRow() < topLeft.getRow() + Math.max(1, size.getRows());
    }

    private static int invokeInt(Class<?> type, Object instance, String methodName, MouseAction mouse) {
        try {
            Method method = type.getDeclaredMethod(methodName, MouseAction.class);
            method.setAccessible(true);
            return (int) method.invoke(instance, mouse);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Impossible d'appeler " + type.getSimpleName() + "." + methodName, e);
        }
    }
}
