package tgpr.framework.ui.component;

import com.googlecode.lanterna.Symbols;
import com.googlecode.lanterna.gui2.TextBox;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import tgpr.framework.ui.Ui;
import tgpr.framework.ui.layout.HBox;
import tgpr.framework.ui.layout.Pos;

import java.time.LocalTime;
import java.util.function.Function;
import java.util.function.Supplier;

import static tgpr.framework.util.Tools.asString;
import static tgpr.framework.util.Tools.isValidTime;
import static tgpr.framework.util.Tools.toTime;

/**
 * Champ heure : {@link TextBox} éditable + {@link CompactButton} ({@code ▼}) qui ouvre un
 * {@link TimePicker} en popup ancré (comme un ComboBox).
 * <p>
 * Raccourci clavier sur le TextBox : {@code Alt+↓}.
 * API principale : {@link #getTime()} / {@link #setTime(LocalTime)} et
 * {@link #setTimeChangeListener(TimeChangeListener)}.
 */
public class TimeField extends HBox {

    public static final String DEFAULT_OPEN_LABEL = String.valueOf(Symbols.TRIANGLE_DOWN_POINTING_BLACK);
    /** {@code HH:mm} + 1 pour éviter le scroll horizontal en fin de saisie. */
    public static final int DEFAULT_COLUMNS = 6;

    /**
     * Notifié à chaque changement du champ.
     * {@code time} est la valeur parsée, ou {@code null} si le texte est vide ou invalide.
     */
    @FunctionalInterface
    public interface TimeChangeListener {
        void onTimeChanged(LocalTime time, boolean byUser);
    }

    private final TextBox textBox;
    private final CompactButton btnOpen;

    private LocalTime minTime;
    private LocalTime maxTime;
    private int stepMinutes = TimePicker.DEFAULT_STEP_MINUTES;
    private Function<LocalTime, String> customTimeValidator;
    private Supplier<LocalTime> nowSupplier = LocalTime::now;
    private TimePicker openPicker;
    private TimeChangeListener timeChangeListener;
    /** Évite le double signal : {@link TextBox#setText} fire déjà {@code byUser=false}. */
    private boolean suppressTextBoxListener;

    public TimeField() {
        this(DEFAULT_COLUMNS);
    }

    public TimeField(int columns) {
        spacing(0);
        childrenAlign(Pos.CENTER);

        textBox = Ui.sizeTo(new TextBox() {
            @Override
            public Result handleKeyStroke(KeyStroke keyStroke) {
                if (keyStroke.getKeyType() == KeyType.ArrowDown && keyStroke.isAltDown()) {
                    togglePicker();
                    return Result.HANDLED;
                }
                return super.handleKeyStroke(keyStroke);
            }
        }, Math.max(1, columns));

        textBox.setTextChangeListener((txt, byUser) -> {
            if (suppressTextBoxListener) {
                return;
            }
            fireTimeChanged(byUser);
        });

        btnOpen = CompactButton.plainGlyph(DEFAULT_OPEN_LABEL, this::togglePicker);
        add(textBox, btnOpen);
    }

    public TimeField withStepMinutes(int stepMinutes) {
        this.stepMinutes = stepMinutes;
        return this;
    }

    public TimeField withMinTime(LocalTime minTime) {
        this.minTime = minTime;
        return this;
    }

    public TimeField withMaxTime(LocalTime maxTime) {
        this.maxTime = maxTime;
        return this;
    }

    public TimeField withAllowedRange(LocalTime minTime, LocalTime maxTime) {
        this.minTime = minTime;
        this.maxTime = maxTime;
        return this;
    }

    public TimeField withCustomTimeValidator(Function<LocalTime, String> customTimeValidator) {
        this.customTimeValidator = customTimeValidator;
        return this;
    }

    /**
     * Heure de référence « maintenant » passée au {@link TimePicker}.
     * Si non définie, utilise {@link LocalTime#now()}.
     */
    public TimeField withNow(LocalTime now) {
        this.nowSupplier = now != null ? () -> now : LocalTime::now;
        return this;
    }

    /**
     * Fournisseur de « maintenant » (ex. {@code () -> SystemTime.now().toLocalTime()}).
     */
    public TimeField withNow(Supplier<LocalTime> now) {
        this.nowSupplier = now != null ? now : LocalTime::now;
        return this;
    }

    public LocalTime now() {
        LocalTime value = nowSupplier != null ? nowSupplier.get() : null;
        return value != null ? value : LocalTime.now();
    }

    public TextBox getTextBox() {
        return textBox;
    }

    public CompactButton getOpenButton() {
        return btnOpen;
    }

    /** Texte brut du champ (format {@code HH:mm} attendu). */
    public String getText() {
        return textBox.getText();
    }

    /** Mise à jour programmatique du texte ({@code byUser == false}). */
    public void setText(String text) {
        applyText(text == null ? "" : text, false);
    }

    /**
     * Heure courante, ou {@code null} si le champ est vide ou le texte n’est pas une heure valide.
     */
    public LocalTime getTime() {
        return parseTime(textBox.getText());
    }

    /**
     * Affiche {@code time} au format {@code HH:mm}, ou vide si {@code null}.
     * Notifie le listener avec {@code byUser == false}.
     */
    public void setTime(LocalTime time) {
        applyText(asString(time), false);
    }

    /**
     * Listener dédié : reçoit un {@link LocalTime} (ou {@code null} si vide / invalide)
     * et un flag {@code byUser} (saisie clavier ou choix dans le picker).
     */
    public void setTimeChangeListener(TimeChangeListener listener) {
        this.timeChangeListener = listener;
    }

    public void takeFocus() {
        textBox.takeFocus();
    }

    /** Active ou désactive le TextBox et le bouton d’ouverture. */
    public void setEnabled(boolean enabled) {
        textBox.setEnabled(enabled);
        btnOpen.setEnabled(enabled);
    }

    private static LocalTime parseTime(String text) {
        if (text == null || text.isBlank() || !isValidTime(text.trim())) {
            return null;
        }
        return toTime(text.trim());
    }

    private void applyText(String value, boolean byUser) {
        String previous = textBox.getText();
        if (value.equals(previous)) {
            return;
        }
        suppressTextBoxListener = true;
        try {
            textBox.setText(value);
        } finally {
            suppressTextBoxListener = false;
        }
        fireTimeChanged(byUser);
    }

    private void fireTimeChanged(boolean byUser) {
        TimeChangeListener listener = timeChangeListener;
        if (listener != null) {
            listener.onTimeChanged(getTime(), byUser);
        }
    }

    private void togglePicker() {
        if (openPicker != null) {
            openPicker.close();
            return;
        }
        openPicker();
    }

    private void openPicker() {
        LocalTime initial = getTime();
        if (initial == null) {
            initial = now();
        }

        var picker = new TimePicker()
                .withNow(nowSupplier)
                .withStepMinutes(stepMinutes)
                .withInitialTime(initial);
        if (minTime != null) {
            picker.withMinTime(minTime);
        }
        if (maxTime != null) {
            picker.withMaxTime(maxTime);
        }
        if (customTimeValidator != null) {
            picker.withCustomTimeValidator(customTimeValidator);
        }

        openPicker = picker;
        picker.showAsPopup(this, time -> applyText(asString(time), true), () -> openPicker = null);
    }
}
