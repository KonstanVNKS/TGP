package tgpr.framework.ui.layout;

import com.googlecode.lanterna.gui2.Component;
import com.googlecode.lanterna.gui2.Direction;
import com.googlecode.lanterna.gui2.LayoutData;
import com.googlecode.lanterna.gui2.LinearLayout;

import java.util.HashMap;
import java.util.Map;

/**
 * Base commune pour {@link VBox} et {@link HBox}.
 */
public abstract class Box extends FluentPanel {
    private Pos childrenAlign;
    private boolean childrenFill;
    private int spacing;
    private Insets padding = Insets.of(0);
    /** Enfants dont le {@link LayoutData} a été posé par {@link #add(Component...)}. */
    private final Map<Component, LayoutData> managedChildLayouts = new HashMap<>();

    protected Box() {
        this.childrenAlign = defaultChildrenAlign();
        applyLayoutManager();
    }

    protected abstract Direction direction();

    /** Alignement par défaut des enfants sur l'axe secondaire. */
    protected abstract Pos defaultChildrenAlign();

    protected void applyLayoutManager() {
        if (padding.getLeft() == 0 && padding.getTop() == 0
                && padding.getRight() == 0 && padding.getBottom() == 0) {
            setLayoutManager(new LinearLayout(direction()).setSpacing(spacing));
        } else {
            setLayoutManager(new InsetsLinearLayout(direction(), spacing, padding));
        }
    }

    public Box spacing(int spacing) {
        this.spacing = spacing;
        applyLayoutManager();
        return this;
    }

    /** Padding intérieur du conteneur. */
    public Box padding(Insets insets) {
        this.padding = insets;
        applyLayoutManager();
        return this;
    }

    /**
     * Alignement des enfants sur l'axe secondaire (gauche/centre/droite dans un {@link VBox},
     * haut/centre/bas dans un {@link HBox}).
     * <p>
     * Peut être appelé avant ou après {@link #add(Component...)} : les enfants déjà ajoutés via
     * {@code add(...)} sans contrainte explicite sont mis à jour. Les enfants ajoutés via
     * {@link #add(Component, Pos)}, {@link #add(Component, Pos, Priority)},
     * {@link #addFill(Component, Priority)}, {@link #add(Component, LayoutData)}, ou dont le
     * {@link LayoutData} a été modifié ensuite (ex. {@link VBox#setVgrow}), ne sont pas modifiés.
     * Ignoré pour les enfants gérés si {@link #childrenFill()} est actif.
     */
    public Box childrenAlign(Pos alignment) {
        this.childrenAlign = alignment;
        propagateManagedChildLayouts();
        return this;
    }

    /**
     * Les enfants ajoutés via {@link #add(Component...)} remplissent l'axe secondaire
     * ({@link LinearLayout.Alignment#Fill}), sans grow sur l'axe principal.
     */
    public Box childrenFill() {
        return childrenFill(true);
    }

    /**
     * Active ou désactive le remplissage de l'axe secondaire pour les enfants gérés.
     * Quand {@code on} est vrai, {@link #childrenAlign(Pos)} est ignoré pour ces enfants.
     */
    public Box childrenFill(boolean on) {
        this.childrenFill = on;
        propagateManagedChildLayouts();
        return this;
    }

    public Box add(Component... children) {
        LayoutData layoutData = managedChildLayoutData();
        for (var child : children) {
            if (child.getLayoutData() == null) {
                child.setLayoutData(layoutData);
                managedChildLayouts.put(child, layoutData);
            }
            addComponent(child);
        }
        return this;
    }

    public Box add(Component child, Pos childAlign) {
        return add(child, childAlign, Priority.NONE);
    }

    /**
     * Ajoute un enfant avec alignement explicite et priorité d'expansion sur l'axe principal
     * ({@link Priority#GROW} dans un {@link VBox} = expansion verticale ; dans un {@link HBox} = horizontale).
     */
    public Box add(Component child, Pos childAlign, Priority grow) {
        return add(child, childAlign, grow, false);
    }

    /**
     * @param fillCrossAxis si vrai, l'enfant remplit l'axe secondaire ({@code childAlign} est ignoré)
     */
    public Box add(Component child, Pos childAlign, Priority grow, boolean fillCrossAxis) {
        managedChildLayouts.remove(child);
        child.setLayoutData(Constraints.linear(direction(), childAlign, grow, fillCrossAxis));
        addComponent(child);
        return this;
    }

    /**
     * Remplit l'axe secondaire et, si {@code mainGrow} est {@link Priority#GROW}, s'étend sur l'axe principal.
     */
    public Box addFill(Component child, Priority mainGrow) {
        return add(child, Pos.CENTER, mainGrow, true);
    }

    public Box add(Component child, LayoutData constraints) {
        managedChildLayouts.remove(child);
        child.setLayoutData(constraints);
        addComponent(child);
        return this;
    }

    @Override
    public Box remove(Component child) {
        managedChildLayouts.remove(child);
        super.removeComponent(child);
        return this;
    }

    @Override
    public Box clear() {
        managedChildLayouts.clear();
        removeAllComponents();
        return this;
    }

    private LayoutData managedChildLayoutData() {
        return Constraints.linear(direction(), childrenAlign, Priority.NONE, childrenFill);
    }

    private void propagateManagedChildLayouts() {
        LayoutData layoutData = managedChildLayoutData();
        for (var child : getChildren()) {
            LayoutData tracked = managedChildLayouts.get(child);
            if (tracked != null && child.getLayoutData() == tracked) {
                child.setLayoutData(layoutData);
                managedChildLayouts.put(child, layoutData);
            } else if (tracked != null) {
                managedChildLayouts.remove(child);
            }
        }
    }

    @Override
    public Box alignInParent(Pos pos) {
        super.alignInParent(pos);
        return this;
    }

    @Override
    public Box alignInVBox(Pos pos) {
        super.alignInVBox(pos);
        return this;
    }

    @Override
    public Box alignInHBox(Pos pos) {
        super.alignInHBox(pos);
        return this;
    }

    @Override
    public Box fillInParent() {
        super.fillInParent();
        return this;
    }

    @Override
    public Box fillInParent(Priority grow) {
        super.fillInParent(grow);
        return this;
    }
}
